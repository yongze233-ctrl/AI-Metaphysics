import { createClient } from "@/utils/supabase/server";
import { HeroCarousel } from "@/components/home/HeroCarousel";
import { DestinySection } from "@/components/home/DestinySection";
import { StoreShowcase } from "@/components/home/StoreShowcase";

export default async function Home() {
  const supabase = await createClient();

  // Fetch featured products from database
  const { data: products } = await supabase
    .from("products")
    .select("*")
    .eq("status", "active")
    .order("created_at", { ascending: false })
    .limit(4);

  return (
    <main className="min-h-screen bg-black">
      {/* Full Screen Hero Carousel */}
      <HeroCarousel />

      {/* Destiny Guide Section */}
      <DestinySection />

      {/* Store Showcase Section */}
      <StoreShowcase products={products || []} />
    </main>
  );
}
