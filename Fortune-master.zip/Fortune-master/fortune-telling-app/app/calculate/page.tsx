import { BaziForm } from "@/components/bazi-form";

export default function CalculatePage() {
  return (
    <main className="min-h-screen bg-rice-paper-texture flex items-center justify-center p-4 pt-24 relative overflow-hidden">
      {/* Ink wash gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-rice-paper via-transparent to-stone-200/30 pointer-events-none" />

      {/* Decorative elements */}
      <div className="absolute inset-0 opacity-3 pointer-events-none">
        <div className="absolute top-20 left-20 font-brush text-9xl text-ink-light">天</div>
        <div className="absolute bottom-20 right-20 font-brush text-9xl text-ink-light">地</div>
      </div>

      <div className="relative z-10">
        <BaziForm />
      </div>
    </main>
  );
}
