"use client";

import { useCartStore } from "@/lib/cart-store";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function CartPage() {
  const { items, removeItem, updateQuantity, getTotal, clearCart } = useCartStore();
  const [loading, setLoading] = useState(false);

  const handleCheckout = async () => {
    if (items.length === 0) return;

    setLoading(true);
    try {
      const response = await fetch("/api/shop-checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.map((item) => ({
            product_id: item.product.id,
            title: item.product.title,
            price: item.product.price,
            quantity: item.quantity,
            image: item.product.images[0] || "",
          })),
        }),
      });

      const data = await response.json();

      if (data.url) {
        window.location.href = data.url;
      } else {
        alert(data.error || "Failed to create checkout session");
      }
    } catch (error) {
      console.error("Checkout error:", error);
      alert("Failed to proceed to checkout");
    }
    setLoading(false);
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-shop-parchment">
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <h1 className="font-serif text-3xl text-shop-charcoal mb-6">
            Your Cart is Empty
          </h1>
          <p className="text-gray-500 mb-8">
            Discover our sacred treasures and add items to your cart.
          </p>
          <Link href="/shop">
            <Button className="bg-shop-dark hover:bg-shop-charcoal text-white rounded-none px-8 py-3">
              CONTINUE SHOPPING
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-shop-parchment">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="font-serif text-3xl text-shop-charcoal mb-8">
          Shopping Cart
        </h1>

        <div className="bg-white p-6 mb-6">
          {items.map((item) => (
            <div
              key={item.product.id}
              className="flex items-center gap-6 py-6 border-b last:border-b-0"
            >
              {/* Image */}
              <div className="w-24 h-24 flex-shrink-0">
                {item.product.images[0] ? (
                  <img
                    src={item.product.images[0]}
                    alt={item.product.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gray-200" />
                )}
              </div>

              {/* Info */}
              <div className="flex-grow">
                <Link
                  href={`/shop/${item.product.id}`}
                  className="font-serif text-lg text-shop-charcoal hover:text-shop-gold"
                >
                  {item.product.title}
                </Link>
                <p className="text-shop-gold mt-1">
                  ${item.product.price.toFixed(2)}
                </p>
              </div>

              {/* Quantity */}
              <div className="flex items-center border border-gray-300">
                <button
                  onClick={() =>
                    updateQuantity(item.product.id, item.quantity - 1)
                  }
                  className="px-3 py-1 text-gray-600 hover:bg-gray-100"
                >
                  -
                </button>
                <span className="px-4 py-1 border-x border-gray-300">
                  {item.quantity}
                </span>
                <button
                  onClick={() =>
                    updateQuantity(item.product.id, item.quantity + 1)
                  }
                  className="px-3 py-1 text-gray-600 hover:bg-gray-100"
                >
                  +
                </button>
              </div>

              {/* Subtotal */}
              <div className="w-24 text-right">
                <p className="font-semibold text-shop-charcoal">
                  ${(item.product.price * item.quantity).toFixed(2)}
                </p>
              </div>

              {/* Remove */}
              <button
                onClick={() => removeItem(item.product.id)}
                className="text-gray-400 hover:text-red-500"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-5 h-5"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="bg-white p-6">
          <div className="flex justify-between items-center mb-6">
            <span className="text-lg text-gray-600">Subtotal</span>
            <span className="text-2xl font-serif text-shop-charcoal">
              ${getTotal().toFixed(2)}
            </span>
          </div>

          <p className="text-sm text-gray-500 mb-6">
            Shipping and taxes calculated at checkout.
          </p>

          <Button
            onClick={handleCheckout}
            disabled={loading}
            className="w-full py-4 bg-shop-dark hover:bg-shop-charcoal text-white text-sm tracking-widest rounded-none"
          >
            {loading ? "PROCESSING..." : "PROCEED TO CHECKOUT"}
          </Button>

          <div className="mt-4 text-center">
            <Link
              href="/shop"
              className="text-sm text-gray-500 hover:text-shop-gold"
            >
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
