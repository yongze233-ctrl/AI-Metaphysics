# Phase 1 PRD: AI Fortune Telling MVP (Volcengine Ark Edition)

## 1. 项目概述 (Overview)

我们要开发一个算命网站的最小可行性版本 (MVP)。
**核心流程**：用户输入生辰信息 -> 系统计算八字排盘 -> 调用火山方舟 (Doubao) 大模型进行流式解读 -> 前端展示结果。

## 2. 技术栈约束 (Tech Stack)

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **UI Components**: Shadcn UI
- **Logic Library**: `lunar-javascript` (用于将阳历转换为干支八字)
- **AI Provider**: **Volcengine Ark (火山方舟)**
  - **Connection Method**: 使用 OpenAI SDK (也就是 `openai` npm 包)，通过修改 `baseURL` 兼容火山方舟的接口。
  - **Model**: Doubao-pro-32k (或其他你在控制台部署的模型端点)。

## 3. 页面结构与 UI 规范

### 3.1 首页 (Home / Input Page)

- **布局**: 居中卡片式设计，背景使用深紫色/黑色渐变，营造神秘感。
- **表单字段**:
  - **姓名** (Input)
  - **性别** (Select: 男/女)
  - **出生日期** (DatePicker: 年/月/日)
  - **出生时辰** (Select: 00:00 - 23:00, or 子丑寅卯...)
- **提交按钮**: "立即测算" (带 Loading 状态)。

### 3.2 结果页 (Result Page)

- **八字排盘区**:
  - 展示四柱：年柱、月柱、日柱、时柱（例如：甲子年 丙寅月...）。
  - 展示五行强弱（金木水火土的个数或分数）。
- **大师解读区 (AI)**:
  - 这是一个流式文本区域 (Streaming Text)。
  - 必须支持 Markdown 渲染（加粗、列表）。
  - 字体要使用衬线体 (Serif) 或仿宋风格，增加传统感。

## 4. 核心逻辑 (Business Logic)

### 4.1 八字计算 (Server Side)

使用 `lunar-javascript` 库：

1.  接收用户输入的公历时间。
2.  转换为农历对象 (`Lunar`).
3.  提取八字：`getYearInGanZhi()`, `getMonthInGanZhi()`, `getDayInGanZhi()`, `getTimeInGanZhi()`.
4.  提取五行：计算八字中金木水火土的数量。

### 4.2 AI 接入配置 (Volcengine Integration)

**重要：不要使用原生的 Volcengine SDK，直接使用 OpenAI SDK 进行兼容调用。**

- **Base URL**: `https://ark.cn-beijing.volces.com/api/v3`

- **Environment Variables**:

  - `VOLCENGINE_API_KEY`: 你的 API Key
  - `VOLCENGINE_ENDPOINT_ID`: 你的模型端点 ID (形如 `ep-20240604...`)

- **System Prompt (提示词策略)**:

  > "你是一位精通《三命通会》与《渊海子平》的命理大师，拥有30年经验。请根据用户的八字，进行性格和运势的简批。
  > 风格要求：语言半文半白，既有专业术语（如伤官见官、身弱财旺）又要用白话文解释清楚。
  > 输出格式：使用 Markdown，分点论述。"

## 5. 开发步骤 (Step-by-Step Instructions)

请 AI 辅助按以下步骤执行：

**
**

- 初始化 Next.js 15 项目。
- 安装依赖: `npm install lucide-react class-variance-authority clsx tailwind-merge lunar-javascript openai ai`
- 初始化 Shadcn UI: `npx shadcn@latest init`
- 配置 `.env.local` 文件，填入火山方舟的 Key 和 Endpoint ID。

**Step 2: 构建工具类 (Utils)**

- 创建 `lib/bazi.ts`: 封装 `lunar-javascript`，传入日期，返回结构化的八字数据对象。

**Step 3: 构建 UI 组件**

- 使用 Shadcn 创建 Form 组件（首页）和 Card 组件（结果展示）。

**Step 4: 实现 AI 接口 (Server Action / API)**

- 创建 `app/api/chat/route.ts`。

- 使用 `openai` 库构建 client:

  ```typescript
  const client = new OpenAI({
    apiKey: process.env.VOLCENGINE_API_KEY,
    baseURL: 'https://ark.cn-beijing.volces.com/api/v3',
  });
  ```