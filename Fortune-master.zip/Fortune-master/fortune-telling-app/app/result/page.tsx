"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { useChat } from "ai/react";
import ReactMarkdown from "react-markdown";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { calculateBazi, type BaziData } from "@/lib/bazi";
import { CompassLoading } from "@/components/compass-loading";
import { motion } from "framer-motion";

function ResultPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [baziData, setBaziData] = useState<BaziData | null>(null);
  const [saved, setSaved] = useState(false);

  const { messages, isLoading, error, append } = useChat({
    api: "/api/chat",
    body: {
      baziData: baziData,
    },
  });

  useEffect(() => {
    const name = searchParams.get("name");
    const gender = searchParams.get("gender");
    const year = searchParams.get("year");
    const month = searchParams.get("month");
    const day = searchParams.get("day");
    const hour = searchParams.get("hour");

    if (!name || !gender || !year || !month || !day || !hour) {
      router.push("/");
      return;
    }

    const data = calculateBazi({
      name,
      gender,
      year: parseInt(year),
      month: parseInt(month),
      day: parseInt(day),
      hour: parseInt(hour),
    });

    setBaziData(data);
  }, [searchParams, router]);

  useEffect(() => {
    if (baziData && messages.length === 0) {
      append({
        role: "user",
        content: "请为我解读八字",
      });
    }
  }, [baziData, append, messages.length]);

  // 保存记录到数据库
  useEffect(() => {
    const aiResponse = messages.find((m) => m.role === "assistant")?.content || "";

    if (aiResponse && !isLoading && !saved && baziData) {
      const saveReading = async () => {
        try {
          const response = await fetch("/api/save-reading", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              name: baziData.name,
              birthDate: `${baziData.birthDate} ${baziData.birthTime}`,
              gender: baziData.gender,
              baziData: baziData,
              aiResult: aiResponse,
            }),
          });

          const result = await response.json();
          if (result.success) {
            setSaved(true);
          }
        } catch (err) {
          console.error("保存记录失败：", err);
        }
      };

      saveReading();
    }
  }, [messages, isLoading, saved, baziData]);

  if (!baziData) {
    return <CompassLoading />;
  }

  const aiResponse = messages.find((m) => m.role === "assistant")?.content || "";

  return (
    <main className="min-h-screen bg-rice-paper-texture pt-24 pb-12 px-4 md:px-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => router.push("/")}
          className="font-chinese text-ink-soot hover:text-cinnabar hover:bg-cinnabar/5 ink-dot-hover"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回首页
        </Button>

        {/* Bazi Display - Vertical Layout (庚帖 Style) */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          {/* Red Paper Background */}
          <div className="relative bg-gradient-to-br from-cinnabar via-cinnabar-dark to-cinnabar p-8 md:p-12 rounded-sm border-4 border-cinnabar-dark scroll-shadow overflow-hidden">
            {/* Corner decorations */}
            <div className="absolute top-2 left-2 w-12 h-12 border-t-4 border-l-4 border-gold opacity-60" />
            <div className="absolute top-2 right-2 w-12 h-12 border-t-4 border-r-4 border-gold opacity-60" />
            <div className="absolute bottom-2 left-2 w-12 h-12 border-b-4 border-l-4 border-gold opacity-60" />
            <div className="absolute bottom-2 right-2 w-12 h-12 border-b-4 border-r-4 border-gold opacity-60" />

            {/* Title Seal */}
            <div className="text-center mb-8">
              <div className="inline-block bg-rice-paper border-2 border-gold px-6 py-3 rounded-sm">
                <h2 className="font-brush text-3xl text-cinnabar">命书</h2>
              </div>
              <p className="font-chinese text-rice-paper/80 mt-3 tracking-widest">
                {baziData.name} · {baziData.gender} · {baziData.birthDate} {baziData.birthTime}
              </p>
            </div>

            {/* Four Pillars - Vertical Display */}
            <div className="flex justify-center gap-4 md:gap-8 mb-8">
              {[
                { label: "年柱", value: baziData.yearPillar },
                { label: "月柱", value: baziData.monthPillar },
                { label: "日柱", value: baziData.dayPillar },
                { label: "时柱", value: baziData.timePillar },
              ].map((pillar, index) => (
                <motion.div
                  key={pillar.label}
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="relative"
                >
                  {/* Vertical Pillar */}
                  <div className="bg-rice-paper border-2 border-gold rounded-sm p-4 md:p-6 flex flex-col items-center min-w-[80px] md:min-w-[100px]">
                    {/* Label */}
                    <div className="font-chinese text-xs md:text-sm text-ink-light mb-3 border-b border-ink-light/20 pb-2 w-full text-center">
                      {pillar.label}
                    </div>

                    {/* Characters - Vertical */}
                    <div className="space-y-2">
                      {pillar.value.split("").map((char, i) => (
                        <div
                          key={i}
                          className="font-brush text-4xl md:text-5xl text-ink-soot text-center"
                        >
                          {char}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Decorative stamp on first and last pillar */}
                  {(index === 0 || index === 3) && (
                    <div className="absolute -top-3 -right-3 w-8 h-8 seal-stamp text-xs flex items-center justify-center">
                      {index === 0 ? "天" : "地"}
                    </div>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Five Elements */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="bg-rice-paper/90 rounded-sm p-6 border-2 border-gold"
            >
              <div className="font-chinese text-sm text-ink-soot mb-4 text-center border-b border-ink-light/20 pb-2">
                五行分布
              </div>
              <div className="grid grid-cols-5 gap-4">
                {Object.entries(baziData.wuxing).map(([element, count]) => (
                  <div key={element} className="text-center">
                    <div className="font-chinese text-base text-ink-soot">{element}</div>
                    <div className="font-brush text-3xl text-cinnabar font-bold">{count}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* AI Interpretation - Ancient Book Style */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="relative"
        >
          <div className="relative bg-rice-paper-texture border-lattice text-gold scroll-shadow rounded-sm overflow-hidden">
            {/* Corner decorations */}
            <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-cinnabar opacity-20" />
            <div className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-cinnabar opacity-20" />
            <div className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-cinnabar opacity-20" />
            <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-cinnabar opacity-20" />

            {/* Header */}
            <div className="relative text-center pt-10 pb-6 px-8 border-b-2 border-gold/20">
              <div className="inline-block seal-stamp w-12 h-12 text-lg mb-3">批</div>
              <h2 className="font-brush text-3xl md:text-4xl text-cinnabar mb-2">命理详批</h2>
              <p className="font-chinese text-ink-light text-sm">基于传统命理学与AI智能分析</p>
            </div>

            {/* Content */}
            <div className="relative p-8 md:p-12">
              {isLoading && !aiResponse && <CompassLoading />}

              {error && (
                <div className="bg-cinnabar/10 border-2 border-cinnabar rounded-sm p-6 font-chinese text-cinnabar text-center">
                  解读失败，请稍后重试：{error.message}
                </div>
              )}

              {aiResponse && (
                <div className="prose prose-lg max-w-none">
                  <div className="font-chinese text-ink-soot leading-loose space-y-6 text-base md:text-lg">
                    <ReactMarkdown
                      components={{
                        h1: ({ children }) => (
                          <h1 className="font-brush text-3xl text-cinnabar mb-4 mt-8 text-center border-b-2 border-gold/20 pb-3">
                            『{children}』
                          </h1>
                        ),
                        h2: ({ children }) => (
                          <h2 className="font-brush text-2xl text-cinnabar mb-3 mt-6 border-l-4 border-cinnabar pl-4">
                            【{children}】
                          </h2>
                        ),
                        h3: ({ children }) => (
                          <h3 className="font-chinese text-xl text-ink-soot mb-2 mt-4 font-semibold">
                            · {children}
                          </h3>
                        ),
                        p: ({ children }) => (
                          <p className="font-chinese text-ink-soot leading-loose mb-4 indent-8">
                            {children}
                          </p>
                        ),
                        ul: ({ children }) => (
                          <ul className="space-y-2 my-4 ml-8">{children}</ul>
                        ),
                        li: ({ children }) => (
                          <li className="font-chinese text-ink-soot flex items-start gap-3">
                            <span className="text-cinnabar mt-1">•</span>
                            <span>{children}</span>
                          </li>
                        ),
                      }}
                    >
                      {aiResponse}
                    </ReactMarkdown>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom decoration */}
            <div className="px-8 pb-6">
              <div className="wave-divider w-full text-gold opacity-30" />
            </div>
          </div>
        </motion.div>
      </div>
    </main>
  );
}

export default function ResultPage() {
  return (
    <Suspense fallback={<CompassLoading />}>
      <ResultPageContent />
    </Suspense>
  );
}
