import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import OpenAI from "openai";
import { generateBaziPrompt, type BaziData } from "@/lib/bazi";
import { Resend } from "resend";

const paidSystemPrompt = `你是一位精通《三命通会》与《渊海子平》的命理大师，拥有30年经验。请根据用户的八字给出 **3000字** 的深度解析。

必须包含以下内容：
1. **性格详批**：深入分析性格优缺点、适合的发展方向
2. **未来10年大运**：每个大运的具体影响和建议
3. **今年流年运势**：今年的机遇与挑战
4. **事业运势**：适合的行业、发展建议、贵人方位
5. **感情婚姻**：桃花运、婚姻走向、配偶特征
6. **财运分析**：正财偏财、投资建议、财运旺月

风格要求：
1. 语言半文半白，既有专业术语（如伤官见官、身弱财旺、食神生财等）又要用白话文解释清楚
2. 分析要有理有据，结合天干地支的生克制化关系
3. 语气要庄重又不失亲切，让人感受到专业性
4. 内容要详实丰富，对得起"深度解析"的定位

输出格式：使用 Markdown，层次分明，每个方面单独成段并加粗标题。`;

// 处理商城订单
async function handleShopOrder(
  session: Stripe.Checkout.Session,
  supabaseAdmin: SupabaseClient
) {
  try {
    const userId = session.metadata?.user_id || null;
    const itemsJson = session.metadata?.items;
    const compactItems = itemsJson ? JSON.parse(itemsJson) : [];

    // 从数据库获取完整的产品信息
    const productIds = compactItems.map((item: any) => item.id);
    const { data: products, error: productsError } = await supabaseAdmin
      .from("products")
      .select("*")
      .in("id", productIds);

    if (productsError) {
      console.error("获取产品信息失败：", productsError);
      throw productsError;
    }

    // 组合完整的订单项信息
    const items = compactItems.map((compactItem: any) => {
      const product = products?.find((p) => p.id === compactItem.id);
      return {
        product_id: compactItem.id,
        title: product?.title || "Unknown Product",
        price: product?.price || 0,
        quantity: compactItem.qty,
        image: product?.image || "",
      };
    });

    // 获取 Stripe 的发货地址 (从 shipping 或 customer_details)
    const shippingDetails = (session as any).shipping_details || (session as any).shipping;
    const shippingAddress = shippingDetails
      ? {
          name: shippingDetails.name || "",
          line1: shippingDetails.address?.line1 || "",
          line2: shippingDetails.address?.line2 || "",
          city: shippingDetails.address?.city || "",
          state: shippingDetails.address?.state || "",
          postal_code: shippingDetails.address?.postal_code || "",
          country: shippingDetails.address?.country || "",
        }
      : null;

    // 创建订单记录
    const { data: order, error: orderError } = await supabaseAdmin
      .from("orders")
      .insert({
        user_id: userId || null,
        stripe_session_id: session.id,
        amount_total: (session.amount_total || 0) / 100, // Convert from cents
        currency: session.currency || "usd",
        status: "paid",
        shipping_address: shippingAddress,
        items: items,
      })
      .select()
      .single();

    if (orderError) {
      console.error("创建订单失败：", orderError);
      return;
    }

    console.log(`商城订单已创建：order_id=${order.id}`);

    // 发送邮件通知管理员
    await sendAdminNotification(order, items, shippingAddress);
  } catch (error) {
    console.error("处理商城订单失败：", error);
  }
}

// 发送管理员通知邮件
async function sendAdminNotification(
  order: any,
  items: any[],
  shippingAddress: any
) {
  try {
    const resend = new Resend(process.env.RESEND_API_KEY);

    const itemsList = items
      .map((item: any) => `- ${item.title} x ${item.quantity} ($${item.price})`)
      .join("\n");

    const addressText = shippingAddress
      ? `${shippingAddress.name}
${shippingAddress.line1}${shippingAddress.line2 ? ", " + shippingAddress.line2 : ""}
${shippingAddress.city}, ${shippingAddress.state} ${shippingAddress.postal_code}
${shippingAddress.country}`
      : "No address provided";

    await resend.emails.send({
      from: "Fortune Shop <onboarding@resend.dev>",
      to: ["tokedoge666@gmail.com"], // 管理员邮箱
      subject: `New Order #${order.id.substring(0, 8)} - $${order.amount_total}`,
      text: `
New Order Received!

Order ID: ${order.id}
Amount: $${order.amount_total} ${order.currency.toUpperCase()}
Date: ${new Date().toLocaleString()}

Items:
${itemsList}

Shipping Address:
${addressText}

Please go to your admin dashboard to process this order:
${process.env.NEXT_PUBLIC_SITE_URL}/admin/orders

---
Fortune Shop
      `,
    });

    console.log(`管理员通知邮件已发送：order_id=${order.id}`);
  } catch (error) {
    console.error("发送管理员通知邮件失败：", error);
  }
}

// 异步生成深度解析（不阻塞 webhook 响应）
async function generateFullReading(readingId: string) {
  try {
    const supabaseAdmin = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // 获取记录
    const { data: reading, error: readingError } = await supabaseAdmin
      .from("readings")
      .select("*")
      .eq("id", readingId)
      .single();

    if (readingError || !reading) {
      console.error("获取记录失败：", readingError);
      return;
    }

    // 如果已有完整解析，跳过
    if (reading.ai_result_full) {
      console.log(`记录 ${readingId} 已有完整解析，跳过生成`);
      return;
    }

    const apiKey = process.env.VOLCENGINE_API_KEY;
    const endpointId = process.env.VOLCENGINE_ENDPOINT_ID;

    if (!apiKey || !endpointId) {
      console.error("AI 服务配置缺失");
      return;
    }

    const client = new OpenAI({
      apiKey: apiKey,
      baseURL: "https://ark.cn-beijing.volces.com/api/v3",
    });

    const baziData = reading.bazi_json as BaziData;
    const baziPrompt = generateBaziPrompt(baziData);

    console.log(`开始为记录 ${readingId} 生成深度解析...`);

    const response = await client.chat.completions.create({
      model: endpointId,
      messages: [
        { role: "system", content: paidSystemPrompt },
        { role: "user", content: baziPrompt },
      ],
      temperature: 0.8,
      max_tokens: 4000,
    });

    const fullResult = response.choices[0]?.message?.content || "";

    // 保存完整解析
    const { error: updateError } = await supabaseAdmin
      .from("readings")
      .update({ ai_result_full: fullResult })
      .eq("id", readingId);

    if (updateError) {
      console.error("保存完整解析失败：", updateError);
    } else {
      console.log(`记录 ${readingId} 的深度解析已生成并保存`);
    }
  } catch (error) {
    console.error("生成深度解析失败：", error);
  }
}

export async function POST(req: Request) {
  try {
    // 在函数内部创建客户端，确保环境变量已加载
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
    const supabaseAdmin = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // 获取 raw body - Next.js 15 App Router 的正确方式
    const body = await req.text();
    const signature = req.headers.get("stripe-signature");

    if (!signature) {
      console.error("缺少 Stripe 签名");
      return NextResponse.json(
        { error: "缺少 Stripe 签名" },
        { status: 400 }
      );
    }

    let event: Stripe.Event;

    // 验证 Webhook 签名
    try {
      event = stripe.webhooks.constructEvent(
        body,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET!
      );
    } catch (err: any) {
      console.error("Webhook 签名验证失败：", err.message);
      return NextResponse.json(
        { error: `Webhook Error: ${err.message}` },
        { status: 400 }
      );
    }

    // 处理 checkout.session.completed 事件
    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session;
      const orderType = session.metadata?.type;

      // 处理商城订单
      if (orderType === "shop_order") {
        await handleShopOrder(session, supabaseAdmin);
      } else {
        // 原有的算命订单处理逻辑
        const readingId = session.metadata?.reading_id;
        const userId = session.metadata?.user_id;

        if (!readingId) {
          console.error("Webhook 缺少 reading_id metadata");
          return NextResponse.json(
            { error: "缺少 reading_id" },
            { status: 400 }
          );
        }

        console.log(`处理支付完成：reading_id=${readingId}, user_id=${userId}`);
        console.log(`使用 service_role key: ${process.env.SUPABASE_SERVICE_ROLE_KEY?.substring(0, 20)}...`);

        // 更新数据库：标记为已支付
        const { data, error: updateError } = await supabaseAdmin
          .from("readings")
          .update({
            is_paid: true,
            payment_status: "paid",
            stripe_session_id: session.id,
          })
          .eq("id", readingId)
          .select();

        if (updateError) {
          console.error("更新支付状态失败：", updateError);
          return NextResponse.json(
            { error: "更新支付状态失败" },
            { status: 500 }
          );
        }

        console.log(`支付状态已更新：reading_id=${readingId}`, data);

        // 异步生成深度解析（不等待完成）
        generateFullReading(readingId).catch(console.error);
      }
    }

    return NextResponse.json({ received: true });
  } catch (error: any) {
    console.error("Webhook 处理异常：", error);
    return NextResponse.json(
      { error: error.message || "Webhook 处理失败" },
      { status: 500 }
    );
  }
}
