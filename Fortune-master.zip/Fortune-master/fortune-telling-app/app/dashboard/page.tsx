import { createClient } from "@/utils/supabase/server";
import { redirect } from "next/navigation";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { ArrowLeft, Package, Truck } from "lucide-react";
import { Order } from "@/lib/types";

// Helper function to convert date to Chinese format
function toChineseDate(dateString: string): string {
  const date = new Date(dateString);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();

  const chineseNums = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"];
  const yearChinese = year.toString().split("").map(n => chineseNums[parseInt(n)]).join("");
  const monthChinese = month < 10 ? chineseNums[month] : (month === 10 ? "十" : "十" + chineseNums[month - 10]);
  const dayChinese = day < 10
    ? "初" + chineseNums[day]
    : (day < 20
      ? "十" + (day === 10 ? "" : chineseNums[day - 10])
      : (day < 30
        ? "廿" + (day === 20 ? "" : chineseNums[day - 20])
        : "三十" + (day === 30 ? "" : chineseNums[day - 30])));

  return `${yearChinese} · ${monthChinese} · ${dayChinese}`;
}

export default async function DashboardPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  // 获取用户的所有测算记录
  const { data: readings, error } = await supabase
    .from("readings")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  // 获取用户的订单
  const { data: orders, error: ordersError } = await supabase
    .from("orders")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("获取记录失败：", error);
  }

  if (ordersError) {
    console.error("获取订单失败：", ordersError);
  }

  return (
    <main className="min-h-screen bg-rice-paper-texture pt-24 pb-12 px-4 md:px-8">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            asChild
            className="font-chinese text-ink-soot hover:text-cinnabar hover:bg-cinnabar/5 ink-dot-hover"
          >
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              返回首页
            </Link>
          </Button>

          <div className="font-chinese text-ink-light text-sm">
            {user.email}
          </div>
        </div>

        {/* Destiny Archives Section */}
        <div className="relative">
          {/* Title with Seal */}
          <div className="flex items-center justify-center gap-4 mb-12">
            <h1 className="font-brush text-5xl md:text-6xl text-cinnabar text-center">
              我的命书
            </h1>
            <div className="seal-stamp w-12 h-12 text-lg">批</div>
          </div>
          <p className="font-chinese text-ink-light text-center mb-8 tracking-widest">
            往期推演存档
          </p>

          {/* Readings List */}
          {!readings || readings.length === 0 ? (
            <div className="text-center py-16 bg-rice-paper-texture border-2 border-dashed border-stone-300 rounded-sm">
              <div className="font-chinese text-ink-light mb-6 text-lg">暂无命书记录</div>
              <Button
                asChild
                className="bg-cinnabar hover:bg-cinnabar-dark font-chinese text-rice-paper"
              >
                <Link href="/calculate">立即测算</Link>
              </Button>
            </div>
          ) : (
            <div className="bg-rice-paper-texture border-2 border-gold/20 rounded-sm p-6 md:p-8 scroll-shadow">
              {readings.map((reading, index) => {
                const chineseDate = toChineseDate(reading.created_at);
                const isCompleted = reading.ai_result && reading.ai_result.length > 0;
                const readingTitle = `${reading.name}的命理批注`;

                return (
                  <Link
                    key={reading.id}
                    href={`/readings/${reading.id}`}
                    className="block"
                  >
                    <div
                      className={`group py-6 transition-all duration-300 hover:bg-stone-200/30 rounded-sm px-4 cursor-pointer ${
                        index !== readings.length - 1 ? "border-b border-dashed border-stone-300" : ""
                      }`}
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        {/* Left: Chinese Date */}
                        <div className="font-chinese text-sm text-ink-light tracking-wider min-w-[180px]">
                          {chineseDate}
                        </div>

                        {/* Center: Reading Title */}
                        <div className="flex-1">
                          <h3 className="font-chinese text-xl md:text-2xl text-ink-soot font-semibold group-hover:text-cinnabar transition-colors">
                            {readingTitle}
                          </h3>
                          <p className="font-chinese text-sm text-ink-light mt-1">
                            {reading.birth_date} · {reading.gender}
                          </p>
                        </div>

                        {/* Right: Status Seal */}
                        <div className="flex items-center justify-end min-w-[80px]">
                          {isCompleted ? (
                            <div className="seal-stamp w-14 h-14 text-base">
                              已批
                            </div>
                          ) : (
                            <div className="relative inline-flex items-center justify-center w-14 h-14 border-2 border-stone-400 bg-stone-100 text-stone-600 font-chinese font-bold rounded-sm">
                              待解
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>

        {/* Orders Section */}
        <div className="relative">
          {/* Title with Seal */}
          <div className="flex items-center justify-center gap-4 mb-12">
            <h2 className="font-brush text-4xl md:text-5xl text-cinnabar text-center">
              交易存档
            </h2>
            <div className="seal-stamp w-10 h-10 text-base">货</div>
          </div>
          <p className="font-chinese text-ink-light text-center mb-8 tracking-widest">
            查看您的商铺订单
          </p>

          {/* Orders List */}
          {!orders || orders.length === 0 ? (
            <div className="text-center py-16 bg-rice-paper-texture border-2 border-dashed border-stone-300 rounded-sm">
              <div className="font-chinese text-ink-light mb-6 text-lg">暂无订单记录</div>
              <Button
                asChild
                className="bg-cinnabar hover:bg-cinnabar-dark font-chinese text-rice-paper"
              >
                <Link href="/shop">前往商铺</Link>
              </Button>
            </div>
          ) : (
            <div className="bg-rice-paper-texture border-2 border-gold/20 rounded-sm p-6 md:p-8 scroll-shadow">
              {(orders as Order[]).map((order, index) => {
                const chineseDate = toChineseDate(order.created_at);
                const getOrderStatus = (status: string) => {
                  switch (status) {
                    case "paid":
                      return { text: "备货中", color: "text-gold", bg: "bg-gold/10", border: "border-gold/30" };
                    case "shipped":
                      return { text: "已发", color: "text-blue-600", bg: "bg-blue-50", border: "border-blue-300" };
                    case "completed":
                      return { text: "已达", color: "text-green-600", bg: "bg-green-50", border: "border-green-300" };
                    default:
                      return { text: status, color: "text-stone-600", bg: "bg-stone-100", border: "border-stone-300" };
                  }
                };
                const statusStyle = getOrderStatus(order.status);

                return (
                  <div
                    key={order.id}
                    className={`group py-6 transition-all duration-300 hover:bg-stone-200/30 rounded-sm px-4 ${
                      index !== orders.length - 1 ? "border-b border-dashed border-stone-300" : ""
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      {/* Left: Icon and Date */}
                      <div className="flex items-center gap-4">
                        <div className="bg-gold/10 border border-gold/30 p-3 rounded-sm">
                          <Package className="h-6 w-6 text-gold" />
                        </div>
                        <div>
                          <div className="font-chinese text-sm text-ink-light tracking-wider">
                            {chineseDate}
                          </div>
                          <div className="font-chinese text-xs text-ink-light/60 mt-1">
                            订单 #{order.id.substring(0, 8)}
                          </div>
                        </div>
                      </div>

                      {/* Center: Order Items */}
                      <div className="flex-1">
                        <div className="font-chinese text-base text-ink-soot">
                          {order.items?.map((item: any, idx: number) => (
                            <span key={idx}>
                              {item.title} × {item.quantity}
                              {idx < order.items.length - 1 ? " · " : ""}
                            </span>
                          ))}
                        </div>
                        {order.tracking_number && (
                          <div className="flex items-center gap-2 mt-2 font-chinese text-sm text-ink-light">
                            <Truck className="h-4 w-4" />
                            <span>{order.carrier}: {order.tracking_number}</span>
                          </div>
                        )}
                      </div>

                      {/* Right: Price and Status */}
                      <div className="flex flex-col items-end gap-2 min-w-[120px]">
                        <span className="font-chinese text-xl font-bold text-cinnabar">
                          ¥{order.amount_total}
                        </span>
                        <span
                          className={`px-3 py-1 text-sm font-chinese rounded-sm border ${statusStyle.bg} ${statusStyle.color} ${statusStyle.border}`}
                        >
                          {statusStyle.text}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
