import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // New Chinese Style Color Palette
        "rice-paper": "#F7F5F0", // 宣纸色 - warm off-white background
        "cinnabar": {
          DEFAULT: "#B22222", // 朱砂红 - primary red
          dark: "#962E25", // 深朱砂
        },
        ink: {
          DEFAULT: "#1A1A1A", // 墨色 - deep black
          soot: "#2B2B2B", // 松烟墨 - text color
          light: "#666666", // 淡墨 - secondary text
        },
        indigo: {
          DEFAULT: "#2C3E50", // 黛蓝 - dark blue
        },
        gold: {
          DEFAULT: "#C5A059", // 流金色 - muted gold
          bright: "#D4AF37", // 亮金
        },
        // Legacy shop colors (keep for compatibility)
        shop: {
          parchment: "#F9F8F4",
          dark: "#0C0C0C",
          gold: "#D4AF37",
          navy: "#1A237E",
          charcoal: "#333333",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "float": {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-20px)" },
        },
        "ink-spread": {
          "0%": { transform: "scale(0)", opacity: "1" },
          "100%": { transform: "scale(2)", opacity: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "float": "float 6s ease-in-out infinite",
        "spin-slow": "spin 20s linear infinite",
        "ink-spread": "ink-spread 1.5s ease-out forwards",
      },
      fontFamily: {
        serif: ["var(--font-playfair)", "Playfair Display", "Georgia", "serif"],
        chinese: ["var(--font-noto-serif)", "Noto Serif SC", "SimSun", "serif"],
        brush: ["var(--font-ma-shan)", "Ma Shan Zheng", "KaiTi", "cursive"],
        sans: ["Lato", "Montserrat", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
export default config;