"use server";

import { createClient } from "@/utils/supabase/server";

/**
 * 用户角色类型
 */
export type UserRole = "user" | "admin" | "super_admin";

/**
 * 获取当前登录用户的角色
 * @returns 用户角色，如果未登录或查询失败则返回 'user'
 */
export async function getUserRole(): Promise<UserRole> {
  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return "user";
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    return (profile?.role as UserRole) || "user";
  } catch (error) {
    console.error("[getUserRole] Error:", error);
    return "user";
  }
}

/**
 * 检查当前用户是否是管理员（admin 或 super_admin）
 * @returns true 如果是管理员，否则 false
 */
export async function isAdmin(): Promise<boolean> {
  const role = await getUserRole();
  return role === "admin" || role === "super_admin";
}

/**
 * 检查当前用户是否是超级管理员
 * @returns true 如果是超级管理员，否则 false
 */
export async function isSuperAdmin(): Promise<boolean> {
  const role = await getUserRole();
  return role === "super_admin";
}

/**
 * 获取当前登录用户的信息和角色
 * @returns 用户信息和角色，如果未登录则返回 null
 */
export async function getCurrentUserWithRole() {
  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return null;
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single();

    return {
      user,
      profile,
      role: (profile?.role as UserRole) || "user",
    };
  } catch (error) {
    console.error("[getCurrentUserWithRole] Error:", error);
    return null;
  }
}

/**
 * 要求用户必须是管理员，否则抛出错误
 * 用于 Server Actions 中的权限检查
 */
export async function requireAdmin() {
  const isAdminUser = await isAdmin();
  if (!isAdminUser) {
    throw new Error("Unauthorized: 只有内务府人员可执行此操作");
  }
}

/**
 * 要求用户必须是超级管理员，否则抛出错误
 * 用于敏感操作的权限检查
 */
export async function requireSuperAdmin() {
  const isSuperAdminUser = await isSuperAdmin();
  if (!isSuperAdminUser) {
    throw new Error("Unauthorized: 只有钦差大臣可执行此操作");
  }
}
