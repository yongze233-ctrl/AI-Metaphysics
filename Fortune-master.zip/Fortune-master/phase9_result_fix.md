当前问题：用户点击测算记录进入详情页后，页面依然保留旧版深紫色/暗黑风格，字体为无衬线体，与首页及历史列表的新中式风格严重割裂。
目标：将结果页打造为一份电子版的 “传世命书” (Destiny Scroll)。
1. 页面容器与背景 (Container & Background)
核心指令：彻底移除所有深色背景类。
背景色：
查找页面最外层 div (通常包含 min-h-screen)。
移除：bg-slate-900, bg-black, bg-purple-950 等类名。
添加：bg-[#F7F5F0] (米色宣纸) 或 bg-rice-paper (如果你配置了 Tailwind 变量)。
纹理：添加 bg-noise 或 bg-paper-texture (如果 globals.css 里定义了)，模拟纸张粗糙感。
文字色：
全局强制设为 text-[#2B2B2B] (墨黑)。
严禁使用 text-white 或 text-gray-200（除非在深色按钮内部）。
2. 八字排盘区重构 (The BaZi Chart)
旧版：可能是横向排列的卡片，或者简单的表格。
新版：“庚帖” (Red Paper) 风格。
布局容器：
居中显示。
背景色：淡赭色/朱砂红 (bg-[#962E25]) 或 纯白宣纸配红框 (border-2 border-[#962E25])。这里推荐红底方案，更有仪式感。
四柱展示 (Year/Month/Day/Hour)：
使用 Grid (4列) 布局。
文字方向：虽然不用 CSS writing-mode，但在视觉上要像竖排。
天干 (Top Char)：大号，宋体，金色/白色。
地支 (Bottom Char)：大号，宋体，金色/白色。
五行 (Element)：小号，位于最下方，使用圆形边框包裹。
字体：必须使用 Noto Serif SC (宋体)。
3. 运势解读区重构 (The Interpretation)
旧版：Markdown 渲染在深色背景上，文字是白色/浅灰。
新版：“古籍书页” 风格。
排版容器：
宽度：max-w-3xl (阅读舒适区)。
背景：透明 (直接显示底层的宣纸背景)。
Markdown 样式 (prose配置)：
字体：全宋体 (font-serif).
标题 (H1, H2, H3)：
颜色：#1A1A1A (浓墨)。
装饰：标题左侧添加竖线装饰 (border-l-4 border-[#962E25])。
正文 (P)：
颜色：#333333 (焦墨)。
行高：leading-loose (宽松，像古书)。
段间距：space-y-6。
重点 (Strong/Bold)：
颜色：#962E25 (朱砂红)。
4. 付费锁/遮罩重构 (The Paywall)
旧版：Blur 模糊 + 现代按钮。
新版：“云山雾罩” 风格。
遮罩层：
移除：纯 CSS Blur。
添加：一个线性渐变遮罩 (bg-gradient-to-t from-[#F7F5F0] via-[#F7F5F0]/90 to-transparent)，让文字看起来是渐渐消失在纸张里。
解锁按钮：
位置：悬浮在底部中央。
样式：
形状：胶囊型。
背景：bg-[#962E25] (朱砂红) 或 bg-gradient-to-r from-yellow-600 to-yellow-500 (流金)。
文字：白色宋体，“解锁天机 ($9.9)”。
装饰：按钮两侧可以加简单的云纹 SVG 图标。
5. 推荐商品区重构 (Recommendations)
如果页面底部有推荐商品：
移除：任何深色卡片背景。
改为：
“博古架”布局：简单的线条边框将商品分隔开。
商品标题：使用竖排文字（如果技术允许）或居中宋体。
6. 开发步骤指令 (Step-by-Step)
请 AI 辅助按以下步骤执行：
Step 1: 清理旧样式
打开 app/[locale]/result/[id]/page.tsx。
删除最外层容器的所有深色背景类 (bg-slate-*, text-white 等)。
应用 bg-[#F7F5F0] 和 text-[#2B2B2B]。
Step 2: 重写八字组件
找到渲染八字 (Bazi) 的代码块。
将其重构为“红底金字”的四柱卡片。
确保字体引用了 font-serif。
Step 3: 优化 Markdown 渲染
如果你使用了 react-markdown 或类似的库，给它添加 class: prose prose-stone prose-headings:font-serif prose-p:leading-loose。
自定义 strong 标签的样式为红色。
Step 4: 美化解锁区域
修改 UnlockButton 组件。
将背景遮罩改为与米色背景融合的渐变。
将按钮改为中式印章或胶囊风格。
Task: 重构结果页的“解锁报告”按钮。
Design Requirements (水墨卷轴风格):
形态: 按钮左右两端添加 卷轴轴头 的视觉元素（可以用 CSS 伪元素画两个深色的小圆柱，或者圆角矩形）。
材质:
中间部分是 米黄色宣纸 质感，但比背景略深。
文字使用 浓墨色 (text-black)，宋体加粗。
交互:
默认状态：像一个卷起来的画轴。
Hover 状态：背景色像墨水晕染一样扩散 (transition-colors)。
文案: 将 "Pay Now" 改为更雅致的 “以此 开启 命盘” (竖线分隔)。
Code Action:
请帮我用 CSS 和 Tailwind 实现这个拟物化的卷轴按钮。