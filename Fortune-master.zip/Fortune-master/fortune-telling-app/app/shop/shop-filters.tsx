"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";

interface ShopFiltersProps {
  categories: string[];
  tags: string[];
  currentCategory?: string;
  currentTag?: string;
}

export function ShopFilters({
  categories,
  tags,
  currentCategory,
  currentTag,
}: ShopFiltersProps) {
  const router = useRouter();

  const buildUrl = (type: "category" | "tag", value: string | null) => {
    const params = new URLSearchParams();
    if (type === "category" && value) {
      params.set("category", value);
    } else if (type === "tag" && value) {
      params.set("tag", value);
    }
    if (type === "category" && currentTag) {
      params.set("tag", currentTag);
    }
    if (type === "tag" && currentCategory) {
      params.set("category", currentCategory);
    }
    const query = params.toString();
    return query ? `/shop?${query}` : "/shop";
  };

  return (
    <div className="relative border-b-2 border-gold/30 pb-8">
      {/* Decorative wave divider at top */}
      <div className="wave-divider w-32 text-gold opacity-40 mb-6 mx-auto" />

      {/* Categories */}
      <div className="mb-6">
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="w-1 h-1 rounded-full bg-cinnabar" />
          <h3 className="font-chinese text-base text-ink-soot tracking-widest">
            宝物分类
          </h3>
          <div className="w-1 h-1 rounded-full bg-cinnabar" />
        </div>

        <div className="flex flex-wrap justify-center gap-3">
          <Link
            href="/shop"
            className={`relative px-5 py-2 font-chinese text-sm transition-all duration-300 ${
              !currentCategory
                ? "bg-cinnabar text-rice-paper border-2 border-cinnabar-dark shadow-md"
                : "bg-rice-paper text-ink-soot border-2 border-stone-300 hover:border-gold hover:text-cinnabar"
            }`}
          >
            <span className="relative z-10">全部</span>
            {!currentCategory && (
              <div className="absolute top-0 right-0 w-2 h-2 bg-gold rounded-full transform translate-x-1 -translate-y-1" />
            )}
          </Link>

          {categories.map((category) => (
            <Link
              key={category}
              href={buildUrl("category", category)}
              className={`relative px-5 py-2 font-chinese text-sm transition-all duration-300 ${
                currentCategory === category
                  ? "bg-cinnabar text-rice-paper border-2 border-cinnabar-dark shadow-md"
                  : "bg-rice-paper text-ink-soot border-2 border-stone-300 hover:border-gold hover:text-cinnabar"
              }`}
            >
              <span className="relative z-10">{category}</span>
              {currentCategory === category && (
                <div className="absolute top-0 right-0 w-2 h-2 bg-gold rounded-full transform translate-x-1 -translate-y-1" />
              )}
            </Link>
          ))}
        </div>
      </div>

      {/* Tags */}
      {tags.length > 0 && (
        <div>
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-1 h-1 rounded-full bg-gold" />
            <h3 className="font-chinese text-base text-ink-soot tracking-widest">
              标签筛选
            </h3>
            <div className="w-1 h-1 rounded-full bg-gold" />
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            {currentTag && (
              <Link
                href={currentCategory ? `/shop?category=${currentCategory}` : "/shop"}
                className="px-3 py-1 text-xs font-chinese bg-cinnabar/10 text-cinnabar border border-cinnabar/30 rounded-sm hover:bg-cinnabar/20 transition-colors"
              >
                清除: {currentTag} ×
              </Link>
            )}
            {tags
              .filter((t) => t !== currentTag)
              .map((tag) => (
                <Link
                  key={tag}
                  href={buildUrl("tag", tag)}
                  className="px-3 py-1 text-xs font-chinese bg-stone-100 text-ink-light border border-stone-300 rounded-sm hover:bg-gold/20 hover:border-gold hover:text-ink-soot transition-all duration-200"
                >
                  {tag}
                </Link>
              ))}
          </div>
        </div>
      )}

      {/* Decorative wave divider at bottom */}
      <div className="wave-divider w-32 text-gold opacity-40 mt-6 mx-auto" />
    </div>
  );
}
