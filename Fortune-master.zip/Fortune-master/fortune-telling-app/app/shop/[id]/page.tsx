import { createClient } from "@/utils/supabase/server";
import { notFound } from "next/navigation";
import { ProductDetail } from "./product-detail";

interface ProductPageProps {
  params: Promise<{ id: string }>;
}

export default async function ProductPage({ params }: ProductPageProps) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: product, error } = await supabase
    .from("products")
    .select("*")
    .eq("id", id)
    .eq("is_active", true)
    .single();

  if (error || !product) {
    notFound();
  }

  // Get related products by tags
  const { data: relatedProducts } = await supabase
    .from("products")
    .select("*")
    .eq("is_active", true)
    .neq("id", id)
    .overlaps("tags", product.tags)
    .limit(4);

  return (
    <div className="min-h-screen bg-shop-parchment">
      <ProductDetail product={product} relatedProducts={relatedProducts || []} />
    </div>
  );
}
