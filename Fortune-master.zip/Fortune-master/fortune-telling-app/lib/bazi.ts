import { Lunar, Solar } from 'lunar-javascript';

/**
 * 八字数据结构
 */
export interface BaziData {
  name: string;
  gender: string;
  birthDate: string;
  birthTime: string;
  yearPillar: string;    // 年柱
  monthPillar: string;   // 月柱
  dayPillar: string;     // 日柱
  timePillar: string;    // 时柱
  wuxing: WuxingCount;   // 五行统计
}

/**
 * 五行统计
 */
export interface WuxingCount {
  金: number;
  木: number;
  水: number;
  火: number;
  土: number;
}

/**
 * 天干对应五行
 */
const tianGanWuxing: Record<string, string> = {
  '甲': '木', '乙': '木',
  '丙': '火', '丁': '火',
  '戊': '土', '己': '土',
  '庚': '金', '辛': '金',
  '壬': '水', '癸': '水',
};

/**
 * 地支对应五行
 */
const diZhiWuxing: Record<string, string> = {
  '子': '水', '亥': '水',
  '寅': '木', '卯': '木',
  '巳': '火', '午': '火',
  '申': '金', '酉': '金',
  '辰': '土', '戌': '土', '丑': '土', '未': '土',
};

/**
 * 计算八字五行
 */
function calculateWuxing(bazi: string[]): WuxingCount {
  const count: WuxingCount = { 金: 0, 木: 0, 水: 0, 火: 0, 土: 0 };

  bazi.forEach((ganZhi) => {
    // 天干
    const tianGan = ganZhi[0];
    const wuxing1 = tianGanWuxing[tianGan];
    if (wuxing1) {
      count[wuxing1 as keyof WuxingCount]++;
    }

    // 地支
    const diZhi = ganZhi[1];
    const wuxing2 = diZhiWuxing[diZhi];
    if (wuxing2) {
      count[wuxing2 as keyof WuxingCount]++;
    }
  });

  return count;
}

/**
 * 根据生辰信息计算八字
 */
export function calculateBazi(params: {
  name: string;
  gender: string;
  year: number;
  month: number;
  day: number;
  hour: number;
}): BaziData {
  const { name, gender, year, month, day, hour } = params;

  // 使用 lunar-javascript 创建公历日期对象
  const solar = Solar.fromYmdHms(year, month, day, hour, 0, 0);

  // 转换为农历
  const lunar = solar.getLunar();

  // 获取四柱八字
  const yearPillar = lunar.getYearInGanZhi();      // 年柱
  const monthPillar = lunar.getMonthInGanZhi();    // 月柱
  const dayPillar = lunar.getDayInGanZhi();        // 日柱
  const timePillar = lunar.getTimeInGanZhi();      // 时柱

  // 计算五行
  const bazi = [yearPillar, monthPillar, dayPillar, timePillar];
  const wuxing = calculateWuxing(bazi);

  return {
    name,
    gender,
    birthDate: `${year}年${month}月${day}日`,
    birthTime: `${hour}时`,
    yearPillar,
    monthPillar,
    dayPillar,
    timePillar,
    wuxing,
  };
}

/**
 * 生成用于 AI 分析的文本描述
 */
export function generateBaziPrompt(baziData: BaziData): string {
  const { name, gender, birthDate, birthTime, yearPillar, monthPillar, dayPillar, timePillar, wuxing } = baziData;

  // 五行描述
  const wuxingDesc = Object.entries(wuxing)
    .map(([element, count]) => `${element}${count}个`)
    .join('，');

  return `
姓名：${name}
性别：${gender}
出生日期：${birthDate} ${birthTime}

【八字排盘】
年柱：${yearPillar}
月柱：${monthPillar}
日柱：${dayPillar}
时柱：${timePillar}

【五行分析】
${wuxingDesc}

请根据以上八字信息，进行性格和运势的简批。
  `.trim();
}
