"use client";

import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const loadingTexts = [
  "乾坤定位中...",
  "正在推演流年...",
  "解析命宫星盘...",
  "五行归位...",
  "天干地支排列...",
  "命理解读中...",
];

export function CompassLoading() {
  const [textIndex, setTextIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTextIndex((prev) => (prev + 1) % loadingTexts.length);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-ink/95 backdrop-blur-sm z-50 flex items-center justify-center">
      {/* Decorative background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 font-brush text-9xl text-gold">命</div>
        <div className="absolute bottom-20 right-20 font-brush text-9xl text-gold">理</div>
        <div className="absolute top-1/2 left-1/4 font-brush text-7xl text-cinnabar">推</div>
        <div className="absolute top-1/3 right-1/4 font-brush text-7xl text-cinnabar">演</div>
      </div>

      <div className="relative z-10 flex flex-col items-center">
        {/* Rotating Compass */}
        <div className="relative w-64 h-64 md:w-80 md:h-80 mb-12">
          {/* Outermost ring - fastest rotation */}
          <motion.div
            animate={{ rotate: 360 }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute inset-0"
          >
            <div className="absolute inset-0 border-4 border-gold/40 rounded-full" />
            {/* Eight Trigrams positions */}
            {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => (
              <div
                key={i}
                className="absolute w-2 h-2 bg-gold rounded-full"
                style={{
                  top: "50%",
                  left: "50%",
                  transform: `translate(-50%, -50%) rotate(${angle}deg) translateY(-130px)`,
                }}
              />
            ))}
          </motion.div>

          {/* Middle ring with Heavenly Stems - medium rotation */}
          <motion.div
            animate={{ rotate: -360 }}
            transition={{
              duration: 30,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute inset-8"
          >
            <div className="absolute inset-0 border-2 border-cinnabar/30 rounded-full" />
            {/* Heavenly Stems (天干) */}
            {["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"].map(
              (stem, i) => (
                <div
                  key={stem}
                  className="absolute font-chinese text-gold text-sm"
                  style={{
                    top: "50%",
                    left: "50%",
                    transform: `translate(-50%, -50%) rotate(${
                      (i * 360) / 10
                    }deg) translateY(-100px) rotate(-${(i * 360) / 10}deg)`,
                  }}
                >
                  {stem}
                </div>
              )
            )}
          </motion.div>

          {/* Inner ring with Earthly Branches - slower rotation */}
          <motion.div
            animate={{ rotate: 360 }}
            transition={{
              duration: 40,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute inset-16"
          >
            <div className="absolute inset-0 border-2 border-gold/20 rounded-full" />
            {/* Earthly Branches (地支) */}
            {["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"].map(
              (branch, i) => (
                <div
                  key={branch}
                  className="absolute font-chinese text-cinnabar text-sm"
                  style={{
                    top: "50%",
                    left: "50%",
                    transform: `translate(-50%, -50%) rotate(${
                      (i * 360) / 12
                    }deg) translateY(-65px) rotate(-${(i * 360) / 12}deg)`,
                  }}
                >
                  {branch}
                </div>
              )
            )}
          </motion.div>

          {/* Center Yin Yang - breathing effect */}
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div
              animate={{
                scale: [1, 1.1, 1],
                opacity: [0.8, 1, 0.8],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="text-8xl"
            >
              ☯
            </motion.div>
          </div>

          {/* Glow effect */}
          <motion.div
            animate={{
              opacity: [0.3, 0.6, 0.3],
              scale: [0.8, 1.2, 0.8],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute inset-0 bg-gradient-to-br from-gold/20 to-cinnabar/20 rounded-full blur-3xl -z-10"
          />
        </div>

        {/* Loading Text with typewriter effect */}
        <motion.div
          key={textIndex}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.5 }}
          className="font-chinese text-xl md:text-2xl text-rice-paper tracking-widest text-center"
        >
          {loadingTexts[textIndex]}
        </motion.div>

        {/* Floating particles */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -30, 0],
                x: [0, Math.random() * 20 - 10, 0],
                opacity: [0, 1, 0],
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: i * 0.3,
              }}
              className="absolute w-1 h-1 bg-gold rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
