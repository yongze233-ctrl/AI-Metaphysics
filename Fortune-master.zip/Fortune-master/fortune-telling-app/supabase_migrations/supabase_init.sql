-- ============================================
-- Fortune Telling App - Supabase 数据库初始化脚本
-- ============================================
-- 请在 Supabase Dashboard 的 SQL Editor 中运行此脚本
-- ============================================

-- 1. 创建 profiles 表（用户资料表）
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. 创建 readings 表（算命记录表）
CREATE TABLE IF NOT EXISTS public.readings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  birth_date TIMESTAMP WITH TIME ZONE NOT NULL,
  gender TEXT NOT NULL,
  bazi_json JSONB,
  ai_result TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. 创建索引以提高查询性能
CREATE INDEX IF NOT EXISTS idx_readings_user_id ON public.readings(user_id);
CREATE INDEX IF NOT EXISTS idx_readings_created_at ON public.readings(created_at DESC);

-- 4. 启用 Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.readings ENABLE ROW LEVEL SECURITY;

-- 5. 创建 profiles 表的 RLS 策略
-- 用户可以查看自己的资料
CREATE POLICY "Users can view own profile"
  ON public.profiles
  FOR SELECT
  USING (auth.uid() = id);

-- 用户可以更新自己的资料
CREATE POLICY "Users can update own profile"
  ON public.profiles
  FOR UPDATE
  USING (auth.uid() = id);

-- 用户可以插入自己的资料
CREATE POLICY "Users can insert own profile"
  ON public.profiles
  FOR INSERT
  WITH CHECK (auth.uid() = id);

-- 6. 创建 readings 表的 RLS 策略
-- 用户只能查看自己的算命记录
CREATE POLICY "Users can view own readings"
  ON public.readings
  FOR SELECT
  USING (auth.uid() = user_id);

-- 用户只能插入自己的算命记录
CREATE POLICY "Users can insert own readings"
  ON public.readings
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- 用户可以删除自己的算命记录（可选功能）
CREATE POLICY "Users can delete own readings"
  ON public.readings
  FOR DELETE
  USING (auth.uid() = user_id);

-- 7. 创建自动化函数：新用户注册时自动创建 profile
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'avatar_url', '')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 8. 创建触发器：当 auth.users 表有新用户时触发
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- 9. 创建自动更新 updated_at 的函数
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 10. 创建触发器：当 profiles 表更新时自动更新 updated_at
DROP TRIGGER IF EXISTS on_profile_updated ON public.profiles;
CREATE TRIGGER on_profile_updated
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- ============================================
-- 初始化完成！
-- ============================================
-- 说明：
-- 1. profiles 表会在用户注册时自动创建记录
-- 2. readings 表用于存储每次算命的完整记录
-- 3. RLS 策略确保用户只能访问自己的数据
-- 4. 索引已创建以优化查询性能
-- ============================================
