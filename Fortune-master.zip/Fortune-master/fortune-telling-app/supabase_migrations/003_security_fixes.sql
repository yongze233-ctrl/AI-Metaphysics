-- =====================================================
-- Security Fixes for Fortune Telling App Database
-- =====================================================
-- Created: 2025-12-22
-- Purpose: Fix critical security vulnerabilities in RLS policies
--
-- INSTRUCTIONS:
-- 1. Review this entire script before executing
-- 2. Execute in Supabase SQL Editor
-- 3. Verify the results using the verification queries at the end
-- =====================================================

BEGIN;

-- =====================================================
-- 1. CRITICAL FIX: readings table payment update vulnerability
-- =====================================================
-- Issue: The "Allow payment updates" policy with qual: "true"
-- allows ANY user to modify ANY payment status.
-- Fix: Only admins can update payment status

DROP POLICY IF EXISTS "Allow payment updates" ON public.readings;

CREATE POLICY "Only admins can update payment status"
ON public.readings FOR UPDATE
USING (
  (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'super_admin')
)
WITH CHECK (
  (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'super_admin')
);

COMMENT ON POLICY "Only admins can update payment status" ON public.readings IS
'Restricts payment status updates to admin and super_admin roles only';


-- =====================================================
-- 2. Remove duplicate products SELECT policy
-- =====================================================
-- Issue: Two identical SELECT policies exist for products table
-- Fix: Keep only one policy

-- Drop the duplicate policy
DROP POLICY IF EXISTS "Products are viewable by everyone." ON public.products;

-- Verify the remaining policy still exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
    AND tablename = 'products'
    AND policyname = 'Products are viewable by everyone'
  ) THEN
    -- If the policy doesn't exist, recreate it
    CREATE POLICY "Products are viewable by everyone"
    ON public.products FOR SELECT
    USING (true);
  END IF;
END $$;


-- =====================================================
-- 3. Add WITH CHECK clauses to profiles UPDATE policies
-- =====================================================
-- Issue: UPDATE policies without WITH CHECK clauses don't validate
-- the new row data, only the old row permissions
-- Fix: Add WITH CHECK to ensure new data also meets requirements

-- Drop existing policies
DROP POLICY IF EXISTS "Users can update own profile v2" ON public.profiles;
DROP POLICY IF EXISTS "Super admin can update any profile" ON public.profiles;

-- Recreate with proper WITH CHECK clauses
CREATE POLICY "Users can update own profile"
ON public.profiles FOR UPDATE
USING (auth.uid() = id)
WITH CHECK (
  auth.uid() = id
  -- The trigger protect_role_changes() already prevents role changes
  -- by non-super-admins, so we don't need to check role here
);

CREATE POLICY "Super admin can update any profile"
ON public.profiles FOR UPDATE
USING (
  (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'super_admin'
)
WITH CHECK (
  (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'super_admin'
);

COMMENT ON POLICY "Users can update own profile" ON public.profiles IS
'Users can update their own profile, but role changes are protected by trigger';

COMMENT ON POLICY "Super admin can update any profile" ON public.profiles IS
'Super admins can update any profile including roles';


-- =====================================================
-- 4. Fix orders.user_id to be NOT NULL
-- =====================================================
-- Issue: orders.user_id allows NULL which could lead to orphaned orders
-- Fix: Make it NOT NULL after verifying no NULL values exist

-- First, check if there are any NULL user_id values
DO $$
DECLARE
  null_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO null_count
  FROM public.orders
  WHERE user_id IS NULL;

  IF null_count > 0 THEN
    RAISE NOTICE 'Warning: Found % orders with NULL user_id. Please fix these before setting NOT NULL constraint.', null_count;
  ELSE
    -- Safe to add NOT NULL constraint
    ALTER TABLE public.orders
    ALTER COLUMN user_id SET NOT NULL;

    RAISE NOTICE 'Successfully set user_id to NOT NULL';
  END IF;
END $$;


-- =====================================================
-- 5. OPTIONAL: Handle duplicate user_roles table
-- =====================================================
-- Issue: user_roles table exists but roles are managed in profiles.role
-- This creates potential data inconsistency
--
-- UNCOMMENT BELOW TO REMOVE user_roles TABLE:
-- This is commented out by default for safety. Review your application
-- to ensure nothing references user_roles before uncommenting.

-- DROP TABLE IF EXISTS public.user_roles CASCADE;
--
-- COMMENT: 'Removed redundant user_roles table - roles are managed in profiles.role';


-- =====================================================
-- 6. Additional Security Enhancement: readings SELECT policy
-- =====================================================
-- Enhance the existing policy to be more explicit

DROP POLICY IF EXISTS "Users can view own readings" ON public.readings;

CREATE POLICY "Users can view own readings"
ON public.readings FOR SELECT
USING (
  auth.uid() = user_id
  OR
  (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'super_admin')
);

COMMENT ON POLICY "Users can view own readings" ON public.readings IS
'Users can view their own readings, admins can view all readings';


COMMIT;

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================
-- Run these queries to verify the fixes were applied correctly

-- 1. Check all policies on readings table
SELECT
  schemaname,
  tablename,
  policyname,
  permissive,
  cmd,
  qual,
  with_check
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename = 'readings'
ORDER BY policyname;

-- 2. Check all policies on products table
SELECT
  schemaname,
  tablename,
  policyname,
  cmd
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename = 'products'
ORDER BY policyname;

-- 3. Check all policies on profiles table
SELECT
  schemaname,
  tablename,
  policyname,
  cmd,
  qual,
  with_check
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename = 'profiles'
ORDER BY policyname;

-- 4. Verify orders.user_id is NOT NULL
SELECT
  table_name,
  column_name,
  is_nullable,
  data_type
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'orders'
  AND column_name = 'user_id';

-- 5. Check if user_roles table still exists
SELECT EXISTS (
  SELECT 1
  FROM information_schema.tables
  WHERE table_schema = 'public'
  AND table_name = 'user_roles'
) AS user_roles_table_exists;

-- 6. Summary of all policies by table
SELECT
  tablename,
  COUNT(*) as policy_count,
  array_agg(policyname ORDER BY policyname) as policies
FROM pg_policies
WHERE schemaname = 'public'
GROUP BY tablename
ORDER BY tablename;

-- =====================================================
-- EXPECTED RESULTS AFTER FIXES:
-- =====================================================
-- readings table should have:
--   - "Only admins can update payment status" (UPDATE)
--   - "Users can view own readings" (SELECT)
--   - "Users can insert own readings" (INSERT)
--
-- products table should have:
--   - "Products are viewable by everyone" (SELECT) - ONLY ONE
--   - Admin policies for INSERT/UPDATE/DELETE
--
-- profiles table should have:
--   - "Users can update own profile" (UPDATE) with WITH CHECK
--   - "Super admin can update any profile" (UPDATE) with WITH CHECK
--   - Other existing policies
--
-- orders.user_id should be:
--   - is_nullable = 'NO'
-- =====================================================
