设计核心：新中式 (New Chinese)、水墨 (Ink Wash)、禅意 (Zen)、极简 (Minimalism)。
目标：将网站从“通用现代风”转变为“高端东方玄学风”，契合八字算命的业务属性。
1. 设计系统规范 (The Design System)
给 AI 的核心设计指令 (Design Prompts)：
1.1 核心配色 (Color Palette)
我们要抛弃纯黑纯白，使用更有质感的东方传统色。
背景色 (Background):
主背景：宣纸色 (Rice Paper) - #F7F5F0 (带一点点暖黄的米白，模拟纸张质感)。
深色背景（用于沉浸式区域）：墨色 (Ink Black) - #1A1A1A 或 黛蓝 (Indigo) - #2C3E50。
主色调 (Primary):
朱砂红 (Cinnabar Red) - #B22222 或 #962E25 (用于按钮、印章、强调文字)。
流金色 (Muted Gold) - #C5A059 (用于边框、图标、高亮，不要太亮，要像古铜)。
文字色 (Text):
松烟墨 (Soot Ink) - #2B2B2B (正文)。
淡墨 (Light Ink) - #666666 (次要文字)。
1.2 字体排印 (Typography)
英文字体: Playfair Display (衬线体) —— 优雅、传统。
中文字体: Noto Serif SC (思源宋体) 或 Ma Shan Zheng (马善政毛笔字体 - 仅用于大标题)。
重要: 必须在 layout.tsx 中引入 Google Fonts。
排版特色:
竖排文字 (Vertical Text): 在 Hero Slogan 或特定标题处，尝试使用 writing-mode: vertical-rl 营造古籍阅读感。
留白 (Whitespace): 增加行高 (leading-loose) 和字间距 (tracking-widest)，营造呼吸感。
1.3 纹理与装饰 (Textures & Decorations)
噪点/纸纹: 在背景 CSS 中添加轻微的 Noise Texture，模拟宣纸的粗糙感。
装饰元素:
窗棂 (Lattice): 使用细线条的几何边框。
祥云/水波 (Cloud/Wave): 作为 Section 之间的分割线 (Divider)。
印章 (Seal): 将 Logo 或重要 Slogan 做成红色印章样式。
2. 页面重构细节 (Page Specifics)
2.1 导航栏 (Navbar)
Logo: 左上角。设计为一个红色正方形印章样式（CSS实现即可），中间是白色的“命”字或品牌首字母。
菜单: 居中。字体使用宋体。Hover 时不显示下划线，而是显示一个红点或墨点。
背景: 透明 -> 磨砂宣纸效果 (Scrolled)。
2.2 首页首屏 (Hero Section)
背景:
不要用普通的轮播图。
建议使用一张水墨晕染的动态背景（CSS 动画）或一张极具意境的山水/星空/罗盘虚化大图。
文案:
竖排显示：“探知天命 · 顺势而为”（或类似 Slogan）。
字体：大号毛笔字体。
CTA 按钮:
形状：胶囊型或带有云纹边框。
样式：朱砂红底，白字，带微弱发光。
2.3 命理指引入口 (Fortune Entry)
卡片设计: 模仿奏折或古书的样式。
交互:
背景是一张暗淡的命盘图。
鼠标悬停时，命盘缓缓旋转 (animate-spin-slow)。
文字浮现：“输入生辰，解锁您的人生剧本”。
2.4 命理商城入口 (Store Showcase)
布局概念: “博古架” (Curio Shelf)。
设计:
不再是简单的网格。使用深褐色的线条构建类似中式架子的结构。
每个格子里放一个商品（已去背或深色背景）。
商品下方用竖排文字显示名称。
3. 组件样式覆盖 (Component Overrides)
3.1 Shadcn 组件改造
Input / Select: 去除默认的圆角 (rounded-md -> rounded-none 或 rounded-sm)。边框改为浅灰色，Focus 时变为朱砂红。
Dialog / Card: 背景改为米色纸纹，边框使用双线（模拟传统边框）。
Toast: 改为深墨色背景，金色文字。
3.2 动画效果 (Framer Motion)
Ink Spread (墨水晕染): 页面切换时，尝试使用墨水扩散的遮罩效果（如果太难，则使用简单的 Fade In）。
Slow Float (缓慢浮动): 所有主要元素都应有极其缓慢的上下浮动，模拟“气”的流动。
4. 开发步骤指令 (Step-by-Step)
请 AI 辅助按以下步骤执行：
Step 1: 配置主题 (Tailwind Config)
在 tailwind.config.ts 中扩展 colors，添加 cinnabar, ink, rice-paper, gold 等自定义颜色。
在 layout.tsx 中引入 Noto Serif SC 和 Playfair Display 字体。
在 globals.css 中添加全局背景纸纹 CSS 类。
Step 2: 重构全局组件
修改 Button, Input, Card 等基础组件，去除圆角，应用新配色。
创建一个 SectionDivider 组件，使用 SVG 绘制水波纹或山峦线条。
Step 3: 重构首页 Hero
实现竖排文字布局 (writing-mode: vertical-rl)。
创建一个 CSS 动画背景（如模拟呼吸或雾气）。
Step 4: 重构业务模块入口
实现“博古架”样式的商品展示区。
实现“古籍/奏折”样式的算命入口。
Step 5: 细节打磨
将所有英文 Label 改为 Serif 字体。
检查所有边框和阴影，使其更柔和、自然。