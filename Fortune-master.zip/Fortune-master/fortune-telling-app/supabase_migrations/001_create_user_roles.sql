-- ================================================
-- Phase 12: RBAC (Role-Based Access Control)
-- 创建用户角色管理系统
-- ================================================

-- 1. 创建 user_roles 表
CREATE TABLE IF NOT EXISTS user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('super_admin', 'admin', 'user')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id)
);

-- 添加注释
COMMENT ON TABLE user_roles IS '用户角色表：管理用户的系统权限';
COMMENT ON COLUMN user_roles.role IS '角色类型：super_admin（超级管理员）、admin（管理员）、user（普通用户）';

-- 2. 创建索引以提高查询性能
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role ON user_roles(role);

-- 3. 启用 RLS (Row Level Security)
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- 4. 创建 RLS 策略
-- 策略1：超级管理员可以查看所有角色
CREATE POLICY "Super admins can view all roles"
  ON user_roles FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'super_admin'
    )
  );

-- 策略2：超级管理员可以插入新角色
CREATE POLICY "Super admins can insert roles"
  ON user_roles FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'super_admin'
    )
  );

-- 策略3：超级管理员可以更新角色
CREATE POLICY "Super admins can update roles"
  ON user_roles FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'super_admin'
    )
  );

-- 策略4：超级管理员可以删除角色
CREATE POLICY "Super admins can delete roles"
  ON user_roles FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'super_admin'
    )
  );

-- 策略5：用户可以查看自己的角色
CREATE POLICY "Users can view their own role"
  ON user_roles FOR SELECT
  USING (user_id = auth.uid());

-- 5. 创建自动更新 updated_at 的触发器
CREATE OR REPLACE FUNCTION update_user_roles_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_user_roles_updated_at_trigger
BEFORE UPDATE ON user_roles
FOR EACH ROW
EXECUTE FUNCTION update_user_roles_updated_at();

-- 6. 将 tokedoge666@gmail.com 设为 super_admin
-- 注意：首次运行需要临时禁用 RLS 或使用 service_role 密钥
INSERT INTO user_roles (user_id, role)
SELECT id, 'super_admin'
FROM auth.users
WHERE email = 'tokedoge666@gmail.com'
ON CONFLICT (user_id) DO UPDATE SET role = 'super_admin';

-- 7. 创建辅助函数：获取用户角色
CREATE OR REPLACE FUNCTION get_user_role(p_user_id UUID)
RETURNS TEXT AS $$
DECLARE
  v_role TEXT;
BEGIN
  SELECT role INTO v_role
  FROM user_roles
  WHERE user_id = p_user_id;

  -- 如果没有角色记录，返回 'user'
  RETURN COALESCE(v_role, 'user');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 8. 创建辅助函数：检查用户是否是管理员
CREATE OR REPLACE FUNCTION is_admin(p_user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = p_user_id
    AND role IN ('super_admin', 'admin')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 完成！
-- ================================================
-- 执行说明：
-- 1. 复制此文件内容
-- 2. 登录 Supabase Dashboard
-- 3. 进入 SQL Editor
-- 4. 粘贴并运行
-- ================================================
