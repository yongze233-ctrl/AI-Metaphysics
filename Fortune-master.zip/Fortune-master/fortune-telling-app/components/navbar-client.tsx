"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { CartIcon } from "@/components/cart-icon";
import { User } from "@supabase/supabase-js";
import { signOut } from "@/app/login/actions";
import { Menu, X } from "lucide-react";

interface NavbarClientProps {
  user: User | null;
  userRole: string;
}

export function NavbarClient({ user, userRole }: NavbarClientProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? "bg-rice-paper-texture shadow-lg border-b border-gold/20"
          : "bg-gradient-to-b from-black/50 to-transparent"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex h-20 items-center justify-between">
          {/* Left: Seal Logo */}
          <Link href="/" className="flex items-center group">
            <div className="seal-stamp w-12 h-12 md:w-14 md:h-14 text-lg md:text-xl font-chinese font-bold transition-transform hover:scale-105">
              命
            </div>
            <span className={`ml-3 font-chinese text-xl md:text-2xl font-semibold tracking-wider transition-colors ${
              isScrolled ? "text-ink-soot" : "text-white"
            } group-hover:text-cinnabar`}>
              命理阁
            </span>
          </Link>

          {/* Center: Navigation Links (Desktop) */}
          <div className="hidden md:flex items-center gap-10">
            <Link
              href="/calculate"
              className={`font-chinese text-base tracking-wider transition-colors ink-dot-hover ${
                isScrolled ? "text-ink-soot hover:text-cinnabar" : "text-white/90 hover:text-white"
              }`}
            >
              命理测算
            </Link>
            <Link
              href="/shop"
              className={`font-chinese text-base tracking-wider transition-colors ink-dot-hover ${
                isScrolled ? "text-ink-soot hover:text-cinnabar" : "text-white/90 hover:text-white"
              }`}
            >
              法物商城
            </Link>
            <Link
              href="/about"
              className={`font-chinese text-base tracking-wider transition-colors ink-dot-hover ${
                isScrolled ? "text-ink-soot hover:text-cinnabar" : "text-white/90 hover:text-white"
              }`}
            >
              关于我们
            </Link>
          </div>

          {/* Right: User Actions */}
          <div className="hidden md:flex items-center gap-4">
            <CartIcon />
            {user ? (
              <>
                <span className={`text-sm max-w-[150px] truncate font-chinese ${
                  isScrolled ? "text-ink-light" : "text-gray-300"
                }`}>
                  {user.email}
                </span>
                <Button
                  variant="ghost"
                  asChild
                  className={`font-chinese ${
                    isScrolled
                      ? "text-ink-soot hover:text-cinnabar hover:bg-cinnabar/10"
                      : "text-gray-300 hover:text-white hover:bg-white/10"
                  }`}
                >
                  <Link href="/dashboard">我的测算</Link>
                </Button>
                {/* 管理员入口 */}
                {(userRole === "admin" || userRole === "super_admin") && (
                  <Button
                    variant="outline"
                    asChild
                    className={`font-chinese rounded-sm ${
                      isScrolled
                        ? "border-[#C5A059] text-[#C5A059] hover:bg-[#C5A059]/10 hover:border-[#C5A059]"
                        : "border-[#C5A059] text-[#C5A059] hover:bg-[#C5A059]/10"
                    }`}
                  >
                    <Link href="/admin">进入后台</Link>
                  </Button>
                )}
                <form action={signOut}>
                  <Button
                    variant="outline"
                    type="submit"
                    className={`font-chinese rounded-sm ${
                      isScrolled
                        ? "border-cinnabar/30 text-ink-soot hover:bg-cinnabar/10 hover:text-cinnabar hover:border-cinnabar"
                        : "border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white"
                    }`}
                  >
                    退出
                  </Button>
                </form>
              </>
            ) : (
              <Button
                asChild
                className="bg-cinnabar hover:bg-cinnabar-dark text-white font-chinese font-medium rounded-sm transition-all hover:shadow-lg"
              >
                <Link href="/login">登录</Link>
              </Button>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className={`md:hidden p-2 transition-colors ${
              isScrolled ? "text-ink-soot" : "text-white"
            }`}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className={`md:hidden py-4 border-t ${
            isScrolled ? "border-gold/20 bg-rice-paper" : "border-white/10 bg-black/30 backdrop-blur-md"
          }`}>
            <div className="flex flex-col gap-4">
              <Link
                href="/calculate"
                className={`font-chinese text-base py-2 transition-colors ${
                  isScrolled ? "text-ink-soot hover:text-cinnabar" : "text-white/90 hover:text-white"
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                命理测算
              </Link>
              <Link
                href="/shop"
                className={`font-chinese text-base py-2 transition-colors ${
                  isScrolled ? "text-ink-soot hover:text-cinnabar" : "text-white/90 hover:text-white"
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                法物商城
              </Link>
              <Link
                href="/about"
                className={`font-chinese text-base py-2 transition-colors ${
                  isScrolled ? "text-ink-soot hover:text-cinnabar" : "text-white/90 hover:text-white"
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                关于我们
              </Link>
              <div className={`pt-4 border-t flex flex-col gap-3 ${
                isScrolled ? "border-gold/20" : "border-white/10"
              }`}>
                <CartIcon />
                {user ? (
                  <>
                    <span className={`text-sm font-chinese ${
                      isScrolled ? "text-ink-light" : "text-gray-400"
                    }`}>{user.email}</span>
                    <Button
                      variant="ghost"
                      asChild
                      className={`font-chinese justify-start ${
                        isScrolled
                          ? "text-ink-soot hover:text-cinnabar hover:bg-cinnabar/10"
                          : "text-gray-300 hover:text-white hover:bg-white/10"
                      }`}
                    >
                      <Link href="/dashboard">我的测算</Link>
                    </Button>
                    {/* 管理员入口 - 移动端 */}
                    {(userRole === "admin" || userRole === "super_admin") && (
                      <Button
                        variant="outline"
                        asChild
                        className={`font-chinese w-full rounded-sm ${
                          isScrolled
                            ? "border-[#C5A059] text-[#C5A059] hover:bg-[#C5A059]/10"
                            : "border-[#C5A059] text-[#C5A059] hover:bg-[#C5A059]/10"
                        }`}
                      >
                        <Link href="/admin">进入后台</Link>
                      </Button>
                    )}
                    <form action={signOut}>
                      <Button
                        variant="outline"
                        type="submit"
                        className={`font-chinese w-full rounded-sm ${
                          isScrolled
                            ? "border-cinnabar/30 text-ink-soot hover:bg-cinnabar/10 hover:text-cinnabar"
                            : "border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white"
                        }`}
                      >
                        退出
                      </Button>
                    </form>
                  </>
                ) : (
                  <Button
                    asChild
                    className="bg-cinnabar hover:bg-cinnabar-dark text-white font-chinese font-medium rounded-sm"
                  >
                    <Link href="/login">登录</Link>
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
