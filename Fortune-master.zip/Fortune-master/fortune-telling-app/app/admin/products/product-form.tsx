"use client";

import { useState } from "react";
import { Product } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface ProductFormProps {
  product: Product | null;
  onClose: () => void;
}

const CATEGORIES = ["Crystal", "Jewelry", "Talisman", "Incense", "Candle", "Other"];

export function ProductForm({ product, onClose }: ProductFormProps) {
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    title: product?.title || "",
    description: product?.description || "",
    price: product?.price?.toString() || "",
    category: product?.category || CATEGORIES[0],
    tags: product?.tags?.join(", ") || "",
    images: product?.images || [] as string[],
    is_active: product?.is_active ?? true,
  });

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    const newImages: string[] = [];

    for (const file of Array.from(files)) {
      try {
        const formData = new FormData();
        formData.append("file", file);

        const response = await fetch("/api/admin/upload-image", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) {
          throw new Error("Failed to upload image");
        }

        const data = await response.json();
        newImages.push(data.url);
      } catch (error) {
        console.error("Upload error:", error);
        alert("Error uploading image");
      }
    }

    setFormData((prev) => ({
      ...prev,
      images: [...prev.images, ...newImages],
    }));
    setUploading(false);
  };

  const removeImage = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const productData = {
      title: formData.title,
      description: formData.description || null,
      price: parseFloat(formData.price),
      category: formData.category,
      tags: formData.tags
        .split(",")
        .map((t) => t.trim())
        .filter((t) => t),
      images: formData.images,
      is_active: formData.is_active,
    };

    try {
      const method = product ? "PUT" : "POST";
      const body = product
        ? { ...productData, id: product.id }
        : productData;

      const response = await fetch("/api/admin/products", {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        throw new Error("Failed to save product");
      }

      onClose();
    } catch (error) {
      console.error("Error saving product:", error);
      alert("Error saving product");
    }

    setLoading(false);
  };

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex justify-between items-center">
        <div className="border-l-4 border-[#C5A059] pl-4">
          <h1 className="text-3xl font-serif text-stone-900 tracking-wide">
            {product ? "编辑灵物" : "添加灵物"}
          </h1>
          <p className="text-sm text-stone-500 mt-1">
            {product ? "Edit Product" : "Add New Product"}
          </p>
        </div>
        <button
          onClick={onClose}
          className="px-6 py-2.5 border border-stone-400 text-stone-700 hover:bg-stone-100 transition-colors"
        >
          返回
        </button>
      </div>

      {/* 表单 */}
      <form onSubmit={handleSubmit} className="bg-[#F7F5F0] border border-stone-300 p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label htmlFor="title" className="block text-sm font-serif text-stone-700">
              名称 *
            </label>
            <input
              id="title"
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
              className="w-full px-4 py-2.5 bg-transparent border-b-2 border-stone-300 focus:border-[#B22222] focus:outline-none text-stone-900 transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="price" className="block text-sm font-serif text-stone-700">
              价格 (元) *
            </label>
            <input
              id="price"
              type="number"
              step="0.01"
              min="0"
              value={formData.price}
              onChange={(e) => setFormData({ ...formData, price: e.target.value })}
              required
              className="w-full px-4 py-2.5 bg-transparent border-b-2 border-stone-300 focus:border-[#B22222] focus:outline-none text-stone-900 font-mono tabular-nums transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="category" className="block text-sm font-serif text-stone-700">
              分类 *
            </label>
            <select
              id="category"
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className="w-full px-4 py-2.5 bg-transparent border-b-2 border-stone-300 focus:border-[#B22222] focus:outline-none text-stone-900 transition-colors"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label htmlFor="tags" className="block text-sm font-serif text-stone-700">
              标签 (逗号分隔)
            </label>
            <input
              id="tags"
              type="text"
              placeholder="金属, 财运, 护身"
              value={formData.tags}
              onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
              className="w-full px-4 py-2.5 bg-transparent border-b-2 border-stone-300 focus:border-[#B22222] focus:outline-none text-stone-900 transition-colors placeholder:text-stone-400"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label htmlFor="description" className="block text-sm font-serif text-stone-700">
            描述
          </label>
          <textarea
            id="description"
            rows={5}
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="w-full px-4 py-3 bg-transparent border-2 border-stone-300 focus:border-[#B22222] focus:outline-none text-stone-900 transition-colors resize-none"
          />
        </div>

        <div className="space-y-3">
          <label className="block text-sm font-serif text-stone-700">
            灵物画像
          </label>

          {/* 已上传的图片 */}
          {formData.images.length > 0 && (
            <div className="flex flex-wrap gap-4 mb-4">
              {formData.images.map((img, index) => (
                <div key={index} className="relative group">
                  <img
                    src={img}
                    alt={`灵物 ${index + 1}`}
                    className="h-28 w-28 object-cover border-2 border-stone-300"
                  />
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute -top-2 -right-2 bg-[#B22222] text-white w-7 h-7 flex items-center justify-center hover:bg-red-800 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* 上传区域 */}
          <div className="relative border-2 border-dashed border-stone-400 p-8 text-center hover:border-[#C5A059] transition-colors">
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleImageUpload}
              disabled={uploading}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <div className="pointer-events-none">
              <p className="text-stone-600 font-serif tracking-wide">
                {uploading ? "上传中..." : "拖入灵物画像"}
              </p>
              <p className="text-xs text-stone-400 mt-2">
                或点击选择文件
              </p>
            </div>
          </div>
        </div>

        {/* 上架状态 */}
        <div className="flex items-center space-x-3 pt-4 border-t border-stone-300">
          <input
            type="checkbox"
            id="is_active"
            checked={formData.is_active}
            onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
            className="w-5 h-5 border-2 border-stone-400 text-[#C5A059] focus:ring-[#C5A059]"
          />
          <label htmlFor="is_active" className="text-sm text-stone-700">
            立即上架 (在商城中可见)
          </label>
        </div>

        {/* 操作按钮 */}
        <div className="flex justify-end space-x-4 pt-6 border-t border-stone-300">
          <button
            type="button"
            onClick={onClose}
            className="px-8 py-2.5 border border-stone-400 text-stone-700 hover:bg-stone-100 transition-colors"
          >
            取消
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-8 py-2.5 bg-[#1A1A1A] text-[#C5A059] hover:bg-stone-900 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "保存中..." : "保存灵物"}
          </button>
        </div>
      </form>
    </div>
  );
}
