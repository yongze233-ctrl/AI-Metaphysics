// @ts-nocheck
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { EasternInput } from "@/components/ui/eastern-input";
import {
  EasternSelect,
  EasternSelectContent,
  EasternSelectItem,
  EasternSelectTrigger,
  EasternSelectValue,
} from "@/components/ui/eastern-select";
import { motion } from "framer-motion";

const formSchema = z.object({
  name: z.string().min(2, { message: "姓名至少需要2个字符" }),
  gender: z.enum(["男", "女"], { message: "请选择性别" }),
  year: z.coerce.number().min(1900).max(new Date().getFullYear(), { message: "请输入有效的年份" }),
  month: z.coerce.number().min(1).max(12, { message: "月份范围为1-12" }),
  day: z.coerce.number().min(1).max(31, { message: "日期范围为1-31" }),
  hour: z.coerce.number().min(0).max(23, { message: "时辰范围为0-23" }),
});

type FormValues = z.infer<typeof formSchema>;

const hours = Array.from({ length: 24 }, (_, i) => ({
  value: i,
  label: `${i.toString().padStart(2, '0')}:00`,
  chinese: ['子时', '丑时', '丑时', '寅时', '寅时', '卯时', '卯时', '辰时', '辰时', '巳时', '巳时', '午时', '午时', '未时', '未时', '申时', '申时', '酉时', '酉时', '戌时', '戌时', '亥时', '亥时', '子时'][i]
}));

export function BaziForm() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      gender: undefined,
      year: new Date().getFullYear() - 30,
      month: 1,
      day: 1,
      hour: 12,
    },
  });

  async function onSubmit(values: FormValues) {
    setIsLoading(true);
    try {
      const params = new URLSearchParams({
        name: values.name,
        gender: values.gender,
        year: values.year.toString(),
        month: values.month.toString(),
        day: values.day.toString(),
        hour: values.hour.toString(),
      });

      router.push(`/result?${params.toString()}`);
    } catch (error) {
      console.error("提交失败", error);
      setIsLoading(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="w-full max-w-3xl relative"
    >
      {/* Vertical Letter (信笺) Container */}
      <div className="relative bg-rice-paper-texture border-lattice text-gold scroll-shadow rounded-sm overflow-hidden">
        {/* Corner decorations */}
        <div className="absolute top-0 left-0 w-16 h-16 border-t-4 border-l-4 border-cinnabar opacity-30" />
        <div className="absolute top-0 right-0 w-16 h-16 border-t-4 border-r-4 border-cinnabar opacity-30" />
        <div className="absolute bottom-0 left-0 w-16 h-16 border-b-4 border-l-4 border-cinnabar opacity-30" />
        <div className="absolute bottom-0 right-0 w-16 h-16 border-b-4 border-r-4 border-cinnabar opacity-30" />

        {/* Decorative background characters */}
        <div className="absolute inset-0 opacity-3 pointer-events-none overflow-hidden">
          <div className="absolute top-10 right-10 font-brush text-6xl text-ink-light">命</div>
          <div className="absolute bottom-10 left-10 font-brush text-6xl text-ink-light">理</div>
        </div>

        {/* Header */}
        <div className="relative text-center pt-12 pb-8 px-8 border-b-2 border-gold/20">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="inline-block seal-stamp w-16 h-16 text-2xl mb-4"
          >
            命
          </motion.div>
          <h2 className="font-brush text-4xl md:text-5xl text-cinnabar mb-3 tracking-wider">
            八字测算
          </h2>
          <p className="font-chinese text-ink-light text-base tracking-widest">
            请书写您的生辰八字 · 探知天命密码
          </p>
        </div>

        {/* Form Content */}
        <div className="relative p-8 md:p-12">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              {/* Name */}
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <EasternInput
                        placeholder="请输入姓名"
                        label="姓名"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage className="font-chinese text-cinnabar text-sm mt-2" />
                  </FormItem>
                )}
              />

              {/* Gender */}
              <FormField
                control={form.control}
                name="gender"
                render={({ field }) => (
                  <FormItem>
                    <EasternSelect onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <EasternSelectTrigger label="性别">
                          <EasternSelectValue placeholder="请选择性别" />
                        </EasternSelectTrigger>
                      </FormControl>
                      <EasternSelectContent>
                        <EasternSelectItem value="男">男</EasternSelectItem>
                        <EasternSelectItem value="女">女</EasternSelectItem>
                      </EasternSelectContent>
                    </EasternSelect>
                    <FormMessage className="font-chinese text-cinnabar text-sm mt-2" />
                  </FormItem>
                )}
              />

              {/* Birth Date */}
              <div className="space-y-4">
                <div className="font-chinese text-sm text-ink-soot mb-4">
                  <span className="font-medium">出生日期</span>
                  <span className="text-ink-light ml-3">（阳历/公历）</span>
                </div>
                <div className="grid grid-cols-3 gap-6">
                  <FormField
                    control={form.control}
                    name="year"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <EasternInput
                            type="number"
                            placeholder="1990"
                            label="年"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="font-chinese text-cinnabar text-xs mt-1" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="month"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <EasternInput
                            type="number"
                            placeholder="1"
                            label="月"
                            min="1"
                            max="12"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="font-chinese text-cinnabar text-xs mt-1" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="day"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <EasternInput
                            type="number"
                            placeholder="1"
                            label="日"
                            min="1"
                            max="31"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="font-chinese text-cinnabar text-xs mt-1" />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Hour */}
              <FormField
                control={form.control}
                name="hour"
                render={({ field }) => (
                  <FormItem>
                    <EasternSelect
                      onValueChange={(value) => field.onChange(parseInt(value))}
                      defaultValue={field.value?.toString()}
                    >
                      <FormControl>
                        <EasternSelectTrigger label="出生时辰">
                          <EasternSelectValue placeholder="请选择时辰" />
                        </EasternSelectTrigger>
                      </FormControl>
                      <EasternSelectContent className="max-h-60">
                        {hours.map((hour) => (
                          <EasternSelectItem key={hour.value} value={hour.value.toString()}>
                            {hour.label} ({hour.chinese})
                          </EasternSelectItem>
                        ))}
                      </EasternSelectContent>
                    </EasternSelect>
                    <FormMessage className="font-chinese text-cinnabar text-sm mt-2" />
                  </FormItem>
                )}
              />

              {/* Submit Button - Seal Style */}
              <div className="pt-6 flex justify-center">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    type="submit"
                    className="bg-cinnabar hover:bg-cinnabar-dark text-white font-chinese text-lg px-12 py-6 rounded-sm border-2 border-cinnabar-dark shadow-lg hover:shadow-xl transition-all relative overflow-hidden group"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        <span className="font-chinese">排盘推演中...</span>
                      </>
                    ) : (
                      <span className="relative z-10 flex items-center gap-3">
                        <span className="font-brush text-xl">钤</span>
                        <span className="font-chinese">开始排盘</span>
                      </span>
                    )}
                    {/* Glow effect on hover */}
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-1000" />
                  </Button>
                </motion.div>
              </div>
            </form>
          </Form>
        </div>

        {/* Bottom decoration */}
        <div className="px-8 pb-8">
          <div className="wave-divider w-full text-gold opacity-30" />
        </div>
      </div>

      {/* Shadow/glow effect */}
      <div className="absolute -inset-4 bg-gradient-to-r from-gold/5 via-cinnabar/5 to-gold/5 rounded-sm blur-2xl -z-10 opacity-50" />
    </motion.div>
  );
}
