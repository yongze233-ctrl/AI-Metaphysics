"use client";

import { useEffect, useState } from "react";
import { getAllUsers, promoteUser, demoteUser, searchUsers, getCurrentUserRole } from "./actions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Shield, ShieldAlert, User, ArrowUp, ArrowDown } from "lucide-react";
import { toast } from "sonner";

type Profile = {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  role: "user" | "admin" | "super_admin";
  created_at: string;
};

export default function UsersPage() {
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [processing, setProcessing] = useState<string | null>(null);
  const [currentUserRole, setCurrentUserRole] = useState<string>("user");

  // 获取用户列表
  const fetchUsers = async () => {
    setLoading(true);
    try {
      const data = await getAllUsers();
      setUsers(data);
    } catch (error: any) {
      toast.error(error.message || "获取用户列表失败");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
    // 获取当前用户角色
    getCurrentUserRole().then((role) => {
      setCurrentUserRole(role);
    });
  }, []);

  // 搜索用户
  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      fetchUsers();
      return;
    }

    setLoading(true);
    try {
      const data = await searchUsers(searchQuery);
      setUsers(data);
    } catch (error: any) {
      toast.error(error.message || "搜索失败");
    } finally {
      setLoading(false);
    }
  };

  // 晋升用户
  const handlePromote = async (userId: string) => {
    setProcessing(userId);
    try {
      const result = await promoteUser(userId);
      toast.success(result.message);
      fetchUsers();
    } catch (error: any) {
      toast.error(error.message || "晋升失败");
    } finally {
      setProcessing(null);
    }
  };

  // 贬黜用户
  const handleDemote = async (userId: string) => {
    setProcessing(userId);
    try {
      const result = await demoteUser(userId);
      toast.success(result.message);
      fetchUsers();
    } catch (error: any) {
      toast.error(error.message || "贬黜失败");
    } finally {
      setProcessing(null);
    }
  };

  // 角色印章样式
  const getRoleBadge = (role: string) => {
    switch (role) {
      case "super_admin":
        return (
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 border-2 border-[#B22222] bg-[#B22222]/10">
            <ShieldAlert className="w-4 h-4 text-[#B22222]" strokeWidth={2} />
            <span className="text-[#B22222] text-xs font-serif tracking-wider">钦差大臣</span>
          </div>
        );
      case "admin":
        return (
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 border-2 border-[#C5A059] bg-[#C5A059]/10">
            <Shield className="w-4 h-4 text-[#C5A059]" strokeWidth={2} />
            <span className="text-[#C5A059] text-xs font-serif tracking-wider">内务府</span>
          </div>
        );
      default:
        return (
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-stone-300 bg-stone-50">
            <User className="w-4 h-4 text-stone-500" strokeWidth={1.5} />
            <span className="text-stone-600 text-xs tracking-wide">庶民</span>
          </div>
        );
    }
  };

  return (
    <div>
      {/* 页面标题 */}
      <div className="mb-8">
        <h1 className="text-3xl font-serif text-stone-800 mb-2">僚属管理</h1>
        <p className="text-stone-500 text-sm">管理所有注册用户的权限和身份</p>
      </div>

      {/* 搜索栏 */}
      <div className="mb-6 flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <Input
            type="text"
            placeholder="按邮箱搜索用户..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            className="pl-10 bg-white border-stone-300"
          />
        </div>
        <Button
          onClick={handleSearch}
          variant="outline"
          className="border-stone-300 hover:bg-stone-100"
        >
          搜索
        </Button>
        {searchQuery && (
          <Button
            onClick={() => {
              setSearchQuery("");
              fetchUsers();
            }}
            variant="ghost"
          >
            清除
          </Button>
        )}
      </div>

      {/* 用户列表 */}
      {loading ? (
        <div className="text-center py-12 text-stone-500">加载中...</div>
      ) : users.length === 0 ? (
        <div className="text-center py-12 text-stone-500">暂无用户</div>
      ) : (
        <div className="bg-white border border-stone-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-stone-50 border-b border-stone-200">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-medium text-stone-600 tracking-wider">
                  用户信息
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-stone-600 tracking-wider">
                  身份
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-stone-600 tracking-wider">
                  注册时间
                </th>
                <th className="px-6 py-4 text-right text-xs font-medium text-stone-600 tracking-wider">
                  操作
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-stone-50 transition-colors">
                  {/* 用户信息 */}
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {/* 头像 */}
                      <div className="w-10 h-10 rounded-full bg-stone-200 flex items-center justify-center">
                        {user.avatar_url ? (
                          <img
                            src={user.avatar_url}
                            alt={user.email}
                            className="w-10 h-10 rounded-full object-cover"
                          />
                        ) : (
                          <span className="text-stone-500 font-serif">
                            {user.email.charAt(0).toUpperCase()}
                          </span>
                        )}
                      </div>
                      {/* 邮箱和昵称 */}
                      <div>
                        <div className="text-sm font-medium text-stone-800">
                          {user.email}
                        </div>
                        {user.full_name && (
                          <div className="text-xs text-stone-500">{user.full_name}</div>
                        )}
                      </div>
                    </div>
                  </td>

                  {/* 身份印章 */}
                  <td className="px-6 py-4">{getRoleBadge(user.role)}</td>

                  {/* 注册时间 */}
                  <td className="px-6 py-4 text-sm text-stone-600">
                    {new Date(user.created_at).toLocaleDateString("zh-CN")}
                  </td>

                  {/* 操作按钮 - 只有超级管理员可以看到和操作 */}
                  <td className="px-6 py-4 text-right">
                    {currentUserRole !== "super_admin" ? (
                      // 非超级管理员：显示只读状态
                      <span className="text-xs text-stone-400">
                        {user.role === "super_admin" ? "最高权限" : "查看模式"}
                      </span>
                    ) : (
                      // 超级管理员：显示操作按钮
                      <>
                        {user.role === "super_admin" ? (
                          <span className="text-xs text-stone-400">最高权限</span>
                        ) : user.role === "admin" ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDemote(user.id)}
                            disabled={processing === user.id}
                            className="border-[#B22222] text-[#B22222] hover:bg-[#B22222]/10"
                          >
                            <ArrowDown className="w-3 h-3 mr-1.5" />
                            {processing === user.id ? "处理中..." : "贬黜"}
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handlePromote(user.id)}
                            disabled={processing === user.id}
                            className="border-[#C5A059] text-[#C5A059] hover:bg-[#C5A059]/10"
                          >
                            <ArrowUp className="w-3 h-3 mr-1.5" />
                            {processing === user.id ? "处理中..." : "晋升"}
                          </Button>
                        )}
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 统计信息 */}
      <div className="mt-6 flex gap-6 text-sm text-stone-600">
        <div>
          总用户数: <span className="font-medium text-stone-800">{users.length}</span>
        </div>
        <div>
          超级管理员:{" "}
          <span className="font-medium text-[#B22222]">
            {users.filter((u) => u.role === "super_admin").length}
          </span>
        </div>
        <div>
          管理员:{" "}
          <span className="font-medium text-[#C5A059]">
            {users.filter((u) => u.role === "admin").length}
          </span>
        </div>
        <div>
          普通用户:{" "}
          <span className="font-medium text-stone-600">
            {users.filter((u) => u.role === "user").length}
          </span>
        </div>
      </div>
    </div>
  );
}
