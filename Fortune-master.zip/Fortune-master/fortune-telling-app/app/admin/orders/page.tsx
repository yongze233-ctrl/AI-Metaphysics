"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/utils/supabase/client";
import { Order } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showShipModal, setShowShipModal] = useState(false);
  const [trackingNumber, setTrackingNumber] = useState("");
  const [carrier, setCarrier] = useState("");
  const [updating, setUpdating] = useState(false);

  const supabase = createClient();

  const fetchOrders = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching orders:", error);
    } else {
      setOrders(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleShip = (order: Order) => {
    setSelectedOrder(order);
    setTrackingNumber(order.tracking_number || "");
    setCarrier(order.carrier || "");
    setShowShipModal(true);
  };

  const submitShipping = async () => {
    if (!selectedOrder) return;
    setUpdating(true);

    const { error } = await supabase
      .from("orders")
      .update({
        status: "shipped",
        tracking_number: trackingNumber,
        carrier: carrier,
      })
      .eq("id", selectedOrder.id);

    if (error) {
      alert("Error updating order: " + error.message);
    } else {
      // Send shipping notification email
      try {
        await fetch("/api/send-shipping-email", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            orderId: selectedOrder.id,
            trackingNumber,
            carrier,
          }),
        });
      } catch (e) {
        console.error("Failed to send shipping email:", e);
      }

      setShowShipModal(false);
      setSelectedOrder(null);
      fetchOrders();
    }
    setUpdating(false);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return (
          <span className="border border-[#B22222] text-[#B22222] px-2 py-0.5 text-xs font-serif tracking-widest">
            [ 已 结 ]
          </span>
        );
      case "shipped":
        return (
          <span className="border border-stone-800 text-stone-800 px-2 py-0.5 text-xs font-serif tracking-widest">
            [ 已 发 ]
          </span>
        );
      case "completed":
        return (
          <span className="border border-green-600 text-green-600 px-2 py-0.5 text-xs font-serif tracking-widest">
            [ 已 完 ]
          </span>
        );
      default:
        return (
          <span className="border border-stone-500 text-stone-500 px-2 py-0.5 text-xs font-serif tracking-widest">
            [ 未知 ]
          </span>
        );
    }
  };

  const formatAddress = (addr: Order["shipping_address"]) => {
    if (!addr) return "暂无";
    return `${addr.name}, ${addr.line1}${addr.line2 ? ", " + addr.line2 : ""}, ${addr.city}, ${addr.state} ${addr.postal_code}`;
  };

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="border-l-4 border-[#C5A059] pl-4">
        <h1 className="text-3xl font-serif text-stone-900 tracking-wide">
          订单管理
        </h1>
        <p className="text-sm text-stone-500 mt-1">Order Management</p>
      </div>

      {loading ? (
        <div className="text-center py-12 text-stone-500">载入中...</div>
      ) : orders.length === 0 ? (
        <div className="bg-[#F7F5F0] border-2 border-dashed border-stone-300 p-12 text-center">
          <p className="text-stone-500">暂无订单</p>
        </div>
      ) : (
        <div className="bg-[#F7F5F0] border border-stone-300 overflow-hidden">
          {/* 账簿风格表格 */}
          <table className="min-w-full">
            <thead className="bg-[#E6DCD0]">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  订单号
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  金额
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  收货人
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  灵物
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  状态
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  日期
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  操作
                </th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order, index) => (
                <tr
                  key={order.id}
                  className={`
                    border-t border-stone-200 hover:bg-red-50 transition-colors
                    ${index % 2 === 1 ? 'bg-stone-100/50' : 'bg-transparent'}
                  `}
                >
                  <td className="px-6 py-4">
                    <div className="font-mono text-xs text-stone-600">
                      {order.id.slice(0, 8)}...
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-mono text-sm text-stone-900 tabular-nums">
                      ¥{order.amount_total}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-stone-900 max-w-xs truncate">
                      {order.shipping_address?.name || "暂无"}
                    </div>
                    <div className="text-xs text-stone-500 mt-1 max-w-xs truncate">
                      {formatAddress(order.shipping_address)}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-1">
                      {order.items?.slice(0, 2).map((item, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          {item.image && (
                            <img
                              src={item.image}
                              alt={item.title}
                              className="h-8 w-8 object-cover border border-stone-300"
                            />
                          )}
                          <span className="text-xs text-stone-700 truncate max-w-[150px]">
                            {item.title} x{item.quantity}
                          </span>
                        </div>
                      ))}
                      {order.items && order.items.length > 2 && (
                        <div className="text-xs text-stone-500">
                          +{order.items.length - 2} 件
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {getStatusBadge(order.status)}
                    {order.tracking_number && (
                      <div className="mt-2 text-xs text-stone-500">
                        {order.carrier}: {order.tracking_number}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 text-xs text-stone-600">
                    {new Date(order.created_at).toLocaleDateString('zh-CN')}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    {order.status === "paid" && (
                      <button
                        onClick={() => handleShip(order)}
                        className="text-[#C5A059] hover:text-[#B8934A] transition-colors"
                      >
                        发货
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 发货模态框 - 新中式风格 */}
      {showShipModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-[#F7F5F0] border-4 border-double border-stone-800 p-8 w-full max-w-md">
            {/* 标题 */}
            <div className="border-b-2 border-stone-300 pb-4 mb-6">
              <h2 className="text-2xl font-serif text-stone-900 tracking-wide">
                填写发货信息
              </h2>
              <p className="text-sm text-stone-500 mt-1">Shipping Details</p>
            </div>

            {/* 表单 */}
            <div className="space-y-5">
              <div>
                <label htmlFor="carrier" className="block text-sm font-serif text-stone-700 mb-2">
                  承运商
                </label>
                <select
                  id="carrier"
                  value={carrier}
                  onChange={(e) => setCarrier(e.target.value)}
                  className="w-full px-4 py-2.5 bg-transparent border-b-2 border-stone-300 focus:border-[#B22222] focus:outline-none text-stone-900 transition-colors"
                >
                  <option value="">请选择...</option>
                  <option value="顺丰速运">顺丰速运</option>
                  <option value="中通快递">中通快递</option>
                  <option value="圆通速递">圆通速递</option>
                  <option value="韵达快递">韵达快递</option>
                  <option value="其他">其他</option>
                </select>
              </div>
              <div>
                <label htmlFor="tracking" className="block text-sm font-serif text-stone-700 mb-2">
                  运单号
                </label>
                <input
                  id="tracking"
                  type="text"
                  value={trackingNumber}
                  onChange={(e) => setTrackingNumber(e.target.value)}
                  placeholder="请输入运单号"
                  className="w-full px-4 py-2.5 bg-transparent border-b-2 border-stone-300 focus:border-[#B22222] focus:outline-none text-stone-900 transition-colors placeholder:text-stone-400"
                />
              </div>
            </div>

            {/* 操作按钮 */}
            <div className="flex justify-end gap-3 mt-8">
              <button
                onClick={() => setShowShipModal(false)}
                disabled={updating}
                className="px-6 py-2.5 border border-stone-400 text-stone-700 hover:bg-stone-100 transition-colors disabled:opacity-50"
              >
                取消
              </button>
              <button
                onClick={submitShipping}
                disabled={updating || !trackingNumber || !carrier}
                className="px-6 py-2.5 bg-[#1A1A1A] text-[#C5A059] hover:bg-stone-900 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {updating ? "处理中..." : "确认发货"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
