import { createClient } from "@/utils/supabase/server";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const supabase = await createClient();

    // 获取当前用户
    const {
      data: { user },
    } = await supabase.auth.getUser();

    // 如果未登录，返回成功但不保存
    if (!user) {
      return NextResponse.json({
        success: true,
        saved: false,
        message: "未登录，结果未保存"
      });
    }

    const { name, birthDate, gender, baziData, aiResult } = await req.json();

    // 解析中文日期格式 "2004年10月1日 8时" 为 ISO 格式
    let parsedBirthDate: string;
    try {
      const match = birthDate.match(/(\d+)年(\d+)月(\d+)日\s*(\d+)时/);
      if (match) {
        const [, year, month, day, hour] = match;
        parsedBirthDate = new Date(
          parseInt(year),
          parseInt(month) - 1,
          parseInt(day),
          parseInt(hour)
        ).toISOString();
      } else {
        // 如果不是中文格式，尝试直接解析
        parsedBirthDate = new Date(birthDate).toISOString();
      }
    } catch {
      parsedBirthDate = new Date().toISOString();
    }

    // 插入记录到数据库
    const { data, error } = await supabase
      .from("readings")
      .insert({
        user_id: user.id,
        name,
        birth_date: parsedBirthDate,
        gender,
        bazi_json: baziData,
        ai_result: aiResult,
      })
      .select()
      .single();

    if (error) {
      console.error("保存记录失败：", error);
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      saved: true,
      readingId: data.id
    });
  } catch (error: any) {
    console.error("保存记录异常：", error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
