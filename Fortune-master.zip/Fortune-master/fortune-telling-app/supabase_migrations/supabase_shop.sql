-- ============================================
-- Fortune Telling App - Phase 4 商城数据库
-- ============================================
-- 请在 Supabase Dashboard 的 SQL Editor 中运行此脚本
-- ============================================

-- 1. 商品表 (Products)
CREATE TABLE IF NOT EXISTS public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  price NUMERIC NOT NULL,
  images TEXT[] NOT NULL DEFAULT '{}',
  category TEXT NOT NULL,
  tags TEXT[] NOT NULL DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. 订单表 (Orders)
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id),
  stripe_session_id TEXT UNIQUE,
  amount_total NUMERIC,
  currency TEXT DEFAULT 'usd',
  status TEXT DEFAULT 'paid',
  shipping_address JSONB,
  items JSONB,
  tracking_number TEXT,
  carrier TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. 创建索引
CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category);
CREATE INDEX IF NOT EXISTS idx_products_is_active ON public.products(is_active);
CREATE INDEX IF NOT EXISTS idx_products_tags ON public.products USING GIN(tags);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON public.orders(created_at DESC);

-- 4. 启用 RLS
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- 5. Products RLS 策略
-- 所有人可读取上架商品
CREATE POLICY "Public read active products"
  ON public.products
  FOR SELECT
  USING (is_active = true);

-- 管理员可读取所有商品 (通过 Service Role)
-- Service Role 会绕过 RLS

-- 6. Orders RLS 策略
-- 用户只能查看自己的订单
CREATE POLICY "Users can view own orders"
  ON public.orders
  FOR SELECT
  USING (auth.uid() = user_id);

-- 用户可以创建自己的订单
CREATE POLICY "Users can insert own orders"
  ON public.orders
  FOR INSERT
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- ============================================
-- 7. 创建 Supabase Storage Bucket (需要在 Dashboard 手动创建)
-- ============================================
-- 在 Supabase Dashboard -> Storage 中:
-- 1. 点击 "New bucket"
-- 2. 名称: product-images
-- 3. 勾选 "Public bucket"
-- 4. 点击 Create bucket
--
-- 然后添加以下 Policy (在 bucket 的 Policies 中):
-- Policy name: Public read access
-- Allowed operation: SELECT
-- Policy definition: true
--
-- Policy name: Admin upload (如需前端上传)
-- Allowed operation: INSERT
-- Policy definition: true (或根据需求限制)
-- ============================================

-- ============================================
-- 初始化完成！
-- ============================================
