"use client";

import { motion, Variants } from "framer-motion";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

interface Product {
  id: string;
  name: string;
  price: number;
  image_url: string;
  description: string;
}

interface StoreShowcaseProps {
  products: Product[];
}

const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2,
    },
  },
};

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: [0, 0, 0.2, 1] as const,
    },
  },
};

export function StoreShowcase({ products }: StoreShowcaseProps) {
  const featuredProducts = products.slice(0, 4);

  return (
    <section className="relative min-h-screen bg-gradient-to-b from-ink to-ink-soot py-20 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 right-20 text-9xl text-gold font-brush">宝</div>
        <div className="absolute bottom-20 left-20 text-9xl text-gold font-brush">物</div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="wave-divider w-32 mx-auto mb-8 text-gold" />
          <h2 className="font-chinese text-4xl md:text-5xl text-rice-paper mb-4 tracking-wider">
            甄选法物
          </h2>
          <p className="font-chinese text-lg text-gold">
            Curated Energy Objects
          </p>
        </motion.div>

        {/* Curio Shelf (博古架) */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="max-w-6xl mx-auto mb-16"
        >
          {/* Shelf structure */}
          <div className="relative border-4 border-gold/30 rounded-sm p-6 md:p-8 bg-gradient-to-br from-ink-soot/50 to-transparent backdrop-blur-sm">
            {/* Horizontal shelf dividers */}
            <div className="absolute left-0 right-0 top-1/2 h-1 bg-gradient-to-r from-transparent via-gold/40 to-transparent" />

            {/* Vertical shelf dividers - hidden on mobile */}
            <div className="hidden md:block absolute top-0 bottom-0 left-1/2 w-1 bg-gradient-to-b from-transparent via-gold/40 to-transparent" />

            {/* Corner decorations */}
            <div className="absolute top-2 left-2 w-8 h-8 border-t-2 border-l-2 border-gold" />
            <div className="absolute top-2 right-2 w-8 h-8 border-t-2 border-r-2 border-gold" />
            <div className="absolute bottom-2 left-2 w-8 h-8 border-b-2 border-l-2 border-gold" />
            <div className="absolute bottom-2 right-2 w-8 h-8 border-b-2 border-r-2 border-gold" />

            {/* Products Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
              {featuredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  variants={itemVariants}
                  className="group relative"
                >
                  <Link href={`/shop/${product.id}`}>
                    <div className="relative">
                      {/* Product container */}
                      <div className="relative aspect-square mb-4 overflow-hidden rounded-sm bg-rice-paper/5 border border-gold/20 group-hover:border-gold/60 transition-all">
                        <Image
                          src={product.image_url || "/placeholder-product.jpg"}
                          alt={product.name}
                          fill
                          className="object-cover p-4 transition-transform duration-500 group-hover:scale-110"
                        />

                        {/* Hover overlay */}
                        <div className="absolute inset-0 bg-gradient-to-t from-cinnabar/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-4">
                          <span className="font-chinese text-white text-sm">查看详情</span>
                        </div>
                      </div>

                      {/* Product info - vertical text style */}
                      <div className="text-center space-y-2">
                        <h3 className="font-chinese text-rice-paper text-sm md:text-base group-hover:text-gold transition-colors line-clamp-2">
                          {product.name}
                        </h3>
                        <div className="flex items-center justify-center gap-2">
                          <span className="font-chinese text-gold text-lg font-medium">
                            ¥{product.price}
                          </span>
                        </div>
                      </div>

                      {/* Decorative stamp on hover */}
                      <motion.div
                        initial={{ opacity: 0, scale: 0 }}
                        whileHover={{ opacity: 1, scale: 1 }}
                        className="absolute top-2 right-2 w-8 h-8 seal-stamp text-xs flex items-center justify-center"
                      >
                        宝
                      </motion.div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <Button
            asChild
            variant="outline"
            size="lg"
            className="border-2 border-gold text-gold hover:bg-gold hover:text-ink font-chinese text-lg px-8 py-6 rounded-sm group"
          >
            <Link href="/shop" className="flex items-center gap-3">
              <span>浏览全部珍品</span>
              <motion.span
                animate={{ x: [0, 5, 0] }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              >
                <ArrowRight className="w-5 h-5" />
              </motion.span>
            </Link>
          </Button>
        </motion.div>
      </div>

      {/* Decorative fog/mist effect */}
      <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-ink via-ink/50 to-transparent pointer-events-none" />
    </section>
  );
}
