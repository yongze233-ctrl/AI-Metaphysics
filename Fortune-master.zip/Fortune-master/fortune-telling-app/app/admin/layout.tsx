"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Package, ShoppingCart, Home, Users } from "lucide-react";

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  const navItems = [
    { href: "/admin", label: "仪表盘", icon: LayoutDashboard, enLabel: "Dashboard" },
    { href: "/admin/products", label: "灵物管理", icon: Package, enLabel: "Products" },
    { href: "/admin/orders", label: "订单管理", icon: ShoppingCart, enLabel: "Orders" },
    { href: "/admin/users", label: "僚属管理", icon: Users, enLabel: "Users" },
  ];

  return (
    <div className="fixed inset-0 bg-[#EBE9E4] flex z-[100]">
      {/* 侧边栏 - 深墨色 */}
      <aside className="w-64 bg-[#1A1A1A] border-r border-[#C5A059] flex flex-col h-full">
        {/* Logo 区 */}
        <div className="p-6 border-b border-white/10">
          <div className="flex flex-col items-center space-y-2">
            {/* 印章 Logo */}
            <div className="w-16 h-16 border-2 border-[#C5A059] flex items-center justify-center">
              <span className="text-[#C5A059] text-2xl font-serif">天</span>
            </div>
            {/* 标识 */}
            <div className="text-center">
              <div className="text-[#C5A059] font-serif text-sm tracking-widest">天机</div>
              <div className="text-stone-400 text-xs tracking-wider">内务</div>
            </div>
          </div>
        </div>

        {/* 导航菜单 */}
        <nav className="flex-1 px-3 py-6">
          <ul className="space-y-2">
            {navItems.map((item) => {
              const isActive = pathname === item.href;
              const Icon = item.icon;

              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className={`
                      group relative flex items-center px-3 py-2.5 text-sm transition-all
                      ${isActive
                        ? "text-[#C5A059] bg-white/5"
                        : "text-stone-400 hover:text-white"
                      }
                    `}
                  >
                    {/* 左侧红色竖线指示器 (hover 时显示) */}
                    <span
                      className={`
                        absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-8 bg-[#B22222] transition-opacity
                        ${isActive ? "opacity-0" : "opacity-0 group-hover:opacity-100"}
                      `}
                    />

                    {/* 图标 */}
                    <Icon className="w-4 h-4 mr-3" strokeWidth={1.5} />

                    {/* 中文标签 */}
                    <span className="font-sans tracking-wide">{item.label}</span>

                    {/* 英文副标签 */}
                    <span className="ml-auto text-xs opacity-50">{item.enLabel}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* 底部返回按钮 */}
        <div className="p-4 border-t border-white/10">
          <Link
            href="/"
            className="flex items-center justify-center px-4 py-2 text-sm text-stone-400 hover:text-white transition-colors"
          >
            <Home className="w-4 h-4 mr-2" strokeWidth={1.5} />
            <span>返回前台</span>
          </Link>
        </div>
      </aside>

      {/* 主内容区 */}
      <main className="flex-1 overflow-auto h-full">
        <div className="max-w-7xl mx-auto py-8 px-6">
          {children}
        </div>
      </main>
    </div>
  );
}
