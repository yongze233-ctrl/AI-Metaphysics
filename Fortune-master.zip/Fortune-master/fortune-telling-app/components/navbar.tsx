import { createClient } from "@/utils/supabase/server";
import { NavbarClient } from "@/components/navbar-client";

export async function Navbar() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // 获取用户角色
  let userRole = "user";
  if (user) {
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();
    userRole = profile?.role || "user";
  }

  return <NavbarClient user={user} userRole={userRole} />;
}
