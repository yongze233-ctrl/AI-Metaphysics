"use client";

import { Product } from "@/lib/types";
import { useCartStore } from "@/lib/cart-store";
import Link from "next/link";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const addItem = useCartStore((state) => state.addItem);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addItem(product);
  };

  return (
    <Link href={`/shop/${product.id}`} className="group block">
      <div className="relative overflow-hidden bg-gradient-to-br from-rice-paper to-amber-50 border border-stone-300 rounded-sm transition-all duration-300 group-hover:border-gold group-hover:shadow-lg">
        {/* Image Container */}
        <div className="relative aspect-square overflow-hidden bg-stone-50">
          {product.images[0] ? (
            <>
              <img
                src={product.images[0]}
                alt={product.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              {/* Image overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-t from-ink-soot/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </>
          ) : (
            <div className="w-full h-full bg-stone-200 flex items-center justify-center">
              <span className="font-chinese text-ink-light">暂无图片</span>
            </div>
          )}

          {/* Corner decoration */}
          <div className="absolute top-2 right-2 w-8 h-8 border-t-2 border-r-2 border-cinnabar/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>

        {/* Quick Add Button - Seal Style */}
        <button
          onClick={handleAddToCart}
          className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-cinnabar hover:bg-cinnabar-dark text-rice-paper font-chinese text-sm px-6 py-2 rounded-sm opacity-0 group-hover:opacity-100 transition-all duration-300 shadow-lg border-2 border-cinnabar-dark"
        >
          加入购物车
        </button>
      </div>

      {/* Product Info */}
      <div className="mt-4 space-y-2">
        {/* Title */}
        <h3 className="font-chinese text-base text-ink-soot text-center tracking-wide group-hover:text-cinnabar transition-colors duration-300">
          {product.title}
        </h3>

        {/* Price */}
        <div className="text-center">
          <span className="font-chinese text-lg font-bold text-gold">
            ¥{product.price.toFixed(2)}
          </span>
        </div>

        {/* Tags */}
        {product.tags.length > 0 && (
          <div className="flex justify-center gap-2 flex-wrap">
            {product.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="text-xs font-chinese text-ink-light px-2 py-1 bg-stone-100 border border-stone-300 rounded-sm"
              >
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>
    </Link>
  );
}
