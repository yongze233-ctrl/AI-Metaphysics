export interface Product {
  id: string;
  title: string;
  description: string | null;
  price: number;
  images: string[];
  category: string;
  tags: string[];
  is_active: boolean;
  created_at: string;
}

export interface Order {
  id: string;
  user_id: string | null;
  stripe_session_id: string | null;
  amount_total: number;
  currency: string;
  status: "paid" | "shipped" | "completed";
  shipping_address: ShippingAddress | null;
  items: OrderItem[];
  tracking_number: string | null;
  carrier: string | null;
  created_at: string;
}

export interface ShippingAddress {
  name: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postal_code: string;
  country: string;
}

export interface OrderItem {
  product_id: string;
  title: string;
  price: number;
  quantity: number;
  image: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
