import * as React from "react";
import { cn } from "@/lib/utils";

export interface EasternInputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
}

const EasternInput = React.forwardRef<HTMLInputElement, EasternInputProps>(
  ({ className, type, label, ...props }, ref) => {
    const [isFocused, setIsFocused] = React.useState(false);

    return (
      <div className="relative w-full">
        {label && (
          <label className="block font-chinese text-sm text-ink-soot mb-2 tracking-wide">
            {label}
          </label>
        )}
        <div className="relative">
          <input
            type={type}
            className={cn(
              // Remove default borders and background
              "flex w-full bg-transparent px-3 py-3 text-base font-chinese",
              // Bottom border only - darker for rice-paper background
              "border-0 border-b-2 border-stone-400",
              // Focus state
              "focus:border-cinnabar focus:outline-none",
              // Transition
              "transition-all duration-300",
              // Text styling
              "text-ink-soot placeholder:text-ink-light/60",
              // Disabled state
              "disabled:cursor-not-allowed disabled:opacity-50",
              className
            )}
            ref={ref}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            {...props}
          />

          {/* Ink spread animation on focus */}
          <div
            className={cn(
              "absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-transparent via-cinnabar to-transparent transition-all duration-500",
              isFocused ? "w-full opacity-100" : "w-0 opacity-0"
            )}
          />

          {/* Decorative corner accents */}
          <div
            className={cn(
              "absolute bottom-0 left-0 w-2 h-2 border-l-2 border-b-2 transition-all duration-300",
              isFocused ? "border-cinnabar opacity-100" : "border-gold/20 opacity-0"
            )}
          />
          <div
            className={cn(
              "absolute bottom-0 right-0 w-2 h-2 border-r-2 border-b-2 transition-all duration-300",
              isFocused ? "border-cinnabar opacity-100" : "border-gold/20 opacity-0"
            )}
          />
        </div>
      </div>
    );
  }
);
EasternInput.displayName = "EasternInput";

export { EasternInput };
