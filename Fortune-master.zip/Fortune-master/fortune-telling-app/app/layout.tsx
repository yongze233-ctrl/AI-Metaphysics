import type { Metadata } from "next";
import { Inter, Playfair_Display, Lato, Noto_Serif_SC, Ma_Shan_Zheng } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/navbar";
import { Toaster } from "sonner";

const inter = Inter({ subsets: ["latin"] });

// English Serif Font - for elegant headings
const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});

const lato = Lato({
  subsets: ["latin"],
  weight: ["300", "400", "700"],
  variable: "--font-lato",
  display: "swap",
});

// Chinese Serif Font - Noto Serif SC (思源宋体)
const notoSerifSC = Noto_Serif_SC({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-noto-serif",
  display: "swap",
});

// Chinese Brush Font - Ma Shan Zheng (马善政毛笔字)
const maShanZheng = Ma_Shan_Zheng({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-ma-shan",
  display: "swap",
});

export const metadata: Metadata = {
  title: "AI 八字算命 - 专业命理测算",
  description: "基于传统八字命理学和AI大模型，为您提供专业的八字排盘和命理解读",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className={`${inter.className} ${playfair.variable} ${lato.variable} ${notoSerifSC.variable} ${maShanZheng.variable}`}>
        <Navbar />
        {children}
        <Toaster position="top-center" richColors />
      </body>
    </html>
  );
}
