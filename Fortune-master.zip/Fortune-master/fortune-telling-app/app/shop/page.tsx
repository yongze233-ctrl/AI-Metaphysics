import { createClient } from "@/utils/supabase/server";
import { Product } from "@/lib/types";
import { ProductCard } from "./product-card";
import { ShopFilters } from "./shop-filters";

interface ShopPageProps {
  searchParams: Promise<{ category?: string; tag?: string }>;
}

export default async function ShopPage({ searchParams }: ShopPageProps) {
  const params = await searchParams;
  const supabase = await createClient();

  let query = supabase
    .from("products")
    .select("*")
    .eq("is_active", true)
    .order("created_at", { ascending: false });

  if (params.category) {
    query = query.eq("category", params.category);
  }

  if (params.tag) {
    query = query.contains("tags", [params.tag]);
  }

  const { data: products, error } = await query;

  if (error) {
    console.error("Error fetching products:", error);
  }

  // Get unique categories and tags for filters
  const { data: allProducts } = await supabase
    .from("products")
    .select("category, tags")
    .eq("is_active", true);

  const categories = [...new Set(allProducts?.map((p) => p.category) || [])];
  const tags = [...new Set(allProducts?.flatMap((p) => p.tags) || [])];

  return (
    <div className="min-h-screen bg-rice-paper-texture pt-24 pb-12">
      {/* Hero Section - 藏宝阁 */}
      <div className="relative py-16 overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-5 pointer-events-none">
          <div className="absolute top-10 left-10 font-brush text-9xl text-ink-soot">宝</div>
          <div className="absolute bottom-10 right-10 font-brush text-9xl text-ink-soot">阁</div>
        </div>

        <div className="max-w-7xl mx-auto px-4 text-center relative z-10">
          {/* Title with seal */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="seal-stamp w-12 h-12 text-lg">珍</div>
            <h1 className="font-brush text-5xl md:text-7xl text-cinnabar">
              藏宝阁
            </h1>
            <div className="seal-stamp w-12 h-12 text-lg">宝</div>
          </div>
          <p className="font-chinese text-ink-light text-lg tracking-widest">
            精选灵物 · 助道修行
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Filters */}
        <ShopFilters
          categories={categories}
          tags={tags}
          currentCategory={params.category}
          currentTag={params.tag}
        />

        {/* Products Grid - 博古架 Layout */}
        {products && products.length > 0 ? (
          <div className="mt-12">
            {/* 博古架框架 */}
            <div className="relative bg-gradient-to-br from-stone-100 via-amber-50 to-stone-100 border-4 border-gold/40 rounded-sm p-8 shadow-2xl">
              {/* Corner decorations */}
              <div className="absolute top-2 left-2 w-16 h-16 border-t-4 border-l-4 border-cinnabar/30" />
              <div className="absolute top-2 right-2 w-16 h-16 border-t-4 border-r-4 border-cinnabar/30" />
              <div className="absolute bottom-2 left-2 w-16 h-16 border-b-4 border-l-4 border-cinnabar/30" />
              <div className="absolute bottom-2 right-2 w-16 h-16 border-b-4 border-r-4 border-cinnabar/30" />

              {/* Shelf dividers */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product: Product, index: number) => (
                  <div
                    key={product.id}
                    className="relative"
                  >
                    {/* Shelf compartment */}
                    <div className="absolute inset-0 border-2 border-stone-400/40 rounded-sm pointer-events-none" />

                    {/* Product card */}
                    <div className="relative p-4">
                      <ProductCard product={product} />
                    </div>

                    {/* Decorative corner seal for special items */}
                    {index % 4 === 0 && (
                      <div className="absolute -top-2 -right-2 seal-stamp w-8 h-8 text-xs">
                        珍
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Bottom decorative wave */}
              <div className="mt-8 pt-6 border-t-2 border-gold/20">
                <div className="wave-divider w-full text-gold opacity-40" />
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-20 bg-rice-paper-texture border-2 border-dashed border-stone-300 rounded-sm">
            <div className="font-chinese text-ink-light text-lg mb-4">暂无宝物</div>
            <p className="font-chinese text-ink-light/60 text-sm">敬请期待新品上架</p>
          </div>
        )}
      </div>
    </div>
  );
}
