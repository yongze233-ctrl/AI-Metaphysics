"use client";

import { useState } from "react";
import { Loader2 } from "lucide-react";

interface PaymentButtonProps {
  readingId: string;
}

export function PaymentButton({ readingId }: PaymentButtonProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePayment = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ readingId }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "创建支付会话失败");
      }

      // 跳转到 Stripe 支付页面
      if (data.url) {
        window.location.href = data.url;
      }
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Scroll Button - 水墨卷轴风格 */}
      <button
        onClick={handlePayment}
        disabled={loading}
        className="group relative px-12 py-5 font-chinese text-lg font-bold text-ink-soot disabled:opacity-60 disabled:cursor-not-allowed transition-all duration-300"
      >
        {/* Left Scroll End (左侧轴头) */}
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-3 h-full bg-gradient-to-r from-stone-700 to-stone-600 rounded-l-md border-l-2 border-stone-800 shadow-inner" />

        {/* Right Scroll End (右侧轴头) */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-full bg-gradient-to-l from-stone-700 to-stone-600 rounded-r-md border-r-2 border-stone-800 shadow-inner" />

        {/* Scroll Paper (卷轴纸面) */}
        <div className="absolute inset-0 mx-3 bg-gradient-to-br from-amber-50 via-stone-100 to-amber-100 border-2 border-stone-300 shadow-md transition-all duration-500 group-hover:from-stone-200 group-hover:via-stone-300 group-hover:to-stone-200 group-hover:border-stone-400" />

        {/* Ink Wash Effect on Hover (墨水晕染效果) */}
        <div className="absolute inset-0 mx-3 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-ink-light/10 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ink-light/5 to-transparent" />
        </div>

        {/* Decorative Seal Marks (装饰性印记) */}
        <div className="absolute top-1 left-6 w-1.5 h-1.5 rounded-full bg-cinnabar/20" />
        <div className="absolute bottom-1 right-6 w-1.5 h-1.5 rounded-full bg-cinnabar/20" />

        {/* Button Content */}
        <span className="relative z-10 flex items-center justify-center gap-3">
          {loading ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              <span>支付跳转中...</span>
            </>
          ) : (
            <>
              <span className="text-ink-light">|</span>
              <span className="tracking-wider">解锁天机</span>
              <span className="text-ink-light">|</span>
              <span className="text-base">$9.90</span>
            </>
          )}
        </span>

        {/* Subtle Shadow for Depth */}
        <div className="absolute inset-0 mx-3 shadow-lg opacity-30 group-hover:opacity-50 transition-opacity duration-300" />
      </button>

      {/* Error Message */}
      {error && (
        <p className="font-chinese text-cinnabar text-sm text-center bg-red-50 border border-cinnabar/30 rounded-sm p-2">
          {error}
        </p>
      )}
    </div>
  );
}
