import { createClient } from "@/utils/supabase/server";
import { NextResponse } from "next/server";
import OpenAI from "openai";
import { generateBaziPrompt, type BaziData } from "@/lib/bazi";

const paidSystemPrompt = `你是一位精通《三命通会》与《渊海子平》的命理大师，拥有30年经验。请根据用户的八字给出 **3000字** 的深度解析。

必须包含以下内容：
1. **性格详批**：深入分析性格优缺点、适合的发展方向
2. **未来10年大运**：每个大运的具体影响和建议
3. **今年流年运势**：今年的机遇与挑战
4. **事业运势**：适合的行业、发展建议、贵人方位
5. **感情婚姻**：桃花运、婚姻走向、配偶特征
6. **财运分析**：正财偏财、投资建议、财运旺月

风格要求：
1. 语言半文半白，既有专业术语（如伤官见官、身弱财旺、食神生财等）又要用白话文解释清楚
2. 分析要有理有据，结合天干地支的生克制化关系
3. 语气要庄重又不失亲切，让人感受到专业性
4. 内容要详实丰富，对得起"深度解析"的定位

输出格式：使用 Markdown，层次分明，每个方面单独成段并加粗标题。`;

export async function POST(req: Request) {
  try {
    const supabase = await createClient();

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 });
    }

    const { readingId } = await req.json();

    if (!readingId) {
      return NextResponse.json({ error: "缺少 readingId" }, { status: 400 });
    }

    // 获取记录并验证已付费
    const { data: reading, error: readingError } = await supabase
      .from("readings")
      .select("*")
      .eq("id", readingId)
      .eq("user_id", user.id)
      .single();

    if (readingError || !reading) {
      return NextResponse.json({ error: "记录不存在" }, { status: 404 });
    }

    if (!reading.is_paid) {
      return NextResponse.json({ error: "请先完成支付" }, { status: 403 });
    }

    // 如果已经有完整解析，直接返回
    if (reading.ai_result_full) {
      return NextResponse.json({
        success: true,
        message: "已有完整解析",
        result: reading.ai_result_full,
      });
    }

    // 生成深度解析
    const apiKey = process.env.VOLCENGINE_API_KEY;
    const endpointId = process.env.VOLCENGINE_ENDPOINT_ID;

    if (!apiKey || !endpointId) {
      return NextResponse.json({ error: "服务配置错误" }, { status: 500 });
    }

    const client = new OpenAI({
      apiKey: apiKey,
      baseURL: "https://ark.cn-beijing.volces.com/api/v3",
    });

    const baziData = reading.bazi_json as BaziData;
    const baziPrompt = generateBaziPrompt(baziData);

    const response = await client.chat.completions.create({
      model: endpointId,
      messages: [
        { role: "system", content: paidSystemPrompt },
        { role: "user", content: baziPrompt },
      ],
      temperature: 0.8,
      max_tokens: 4000,
    });

    const fullResult = response.choices[0]?.message?.content || "";

    // 保存完整解析到数据库
    const { error: updateError } = await supabase
      .from("readings")
      .update({ ai_result_full: fullResult })
      .eq("id", readingId);

    if (updateError) {
      console.error("保存完整解析失败：", updateError);
    }

    return NextResponse.json({
      success: true,
      result: fullResult,
    });
  } catch (error: any) {
    console.error("生成深度解析失败：", error);
    return NextResponse.json(
      { error: error.message || "生成失败" },
      { status: 500 }
    );
  }
}
