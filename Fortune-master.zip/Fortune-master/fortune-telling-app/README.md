# AI 八字算命 MVP - Fortune Telling App

基于 Next.js 15 和火山方舟（Volcengine Ark）的 AI 八字算命网站。

## 技术栈

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **UI Components**: Shadcn UI
- **八字计算**: lunar-javascript
- **AI Provider**: Volcengine Ark (火山方舟) via OpenAI SDK

## 项目结构

```
fortune-telling-app/
├── app/               # Next.js App Router 页面
├── components/        # React 组件
├── lib/               # 工具函数和库
│   ├── utils.ts       # Shadcn UI 工具函数
│   └── bazi.ts        # 八字计算逻辑（待创建）
├── public/            # 静态资源
└── .env.local         # 环境变量配置
```

## 环境配置

1. 复制 `.env.example` 到 `.env.local`
2. 在[火山方舟控制台](https://console.volcengine.com/ark)获取：
   - API Key
   - 部署的模型端点 ID (Endpoint ID)
3. 填入 `.env.local` 文件

## 安装和运行

```bash
# 安装依赖
npm install --legacy-peer-deps

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build

# 启动生产服务器
npm start
```

## 开发进度

### 已完成 ✅
- [x] 初始化 Next.js 15 项目
- [x] 安装所有必要依赖
- [x] 配置 Shadcn UI
- [x] 创建环境变量模板

### 待开发 📝
- [ ] Step 2: 创建八字计算工具类 (lib/bazi.ts)
- [ ] Step 3: 构建 UI 组件（表单和结果展示）
- [ ] Step 4: 实现 AI 接口集成
- [ ] Step 5: 完成首页和结果页

## 注意事项

- 由于依赖版本兼容性问题，安装时需要使用 `--legacy-peer-deps` 参数
- 确保已正确配置火山方舟的 API Key 和 Endpoint ID
- 项目使用 React 19 RC 版本以兼容 Next.js 15

## License

MIT