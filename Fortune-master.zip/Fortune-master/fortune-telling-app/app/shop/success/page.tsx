"use client";

import { useEffect } from "react";
import { useCartStore } from "@/lib/cart-store";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function SuccessPage() {
  const clearCart = useCartStore((state) => state.clearCart);

  useEffect(() => {
    // Clear the cart after successful payment
    clearCart();
  }, [clearCart]);

  return (
    <div className="min-h-screen bg-shop-parchment flex items-center justify-center">
      <div className="max-w-md mx-auto px-4 text-center">
        <div className="mb-8">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg
              className="w-10 h-10 text-green-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>
          <h1 className="font-serif text-3xl text-shop-charcoal mb-4">
            Thank You for Your Order!
          </h1>
          <p className="text-gray-600 leading-relaxed">
            Your payment has been processed successfully. You will receive an
            email confirmation shortly with your order details.
          </p>
        </div>

        <div className="space-y-4">
          <Link href="/shop">
            <Button className="w-full bg-shop-dark hover:bg-shop-charcoal text-white rounded-none py-3">
              CONTINUE SHOPPING
            </Button>
          </Link>
          <Link href="/dashboard">
            <Button
              variant="outline"
              className="w-full rounded-none py-3 border-shop-dark text-shop-dark hover:bg-shop-dark hover:text-white"
            >
              VIEW MY ORDERS
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
