"use client";

import { useEffect, useState } from "react";
import { Product } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { ProductForm } from "./product-form";

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/admin/products");
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }
      const data = await response.json();
      setProducts(data || []);
    } catch (error) {
      console.error("Error fetching products:", error);
      alert("Error fetching products");
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this product?")) return;

    try {
      const response = await fetch(`/api/admin/products?id=${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        throw new Error("Failed to delete product");
      }

      fetchProducts();
    } catch (error) {
      console.error("Error deleting product:", error);
      alert("Error deleting product");
    }
  };

  const handleToggleActive = async (product: Product) => {
    try {
      const response = await fetch("/api/admin/products", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: product.id,
          is_active: !product.is_active,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to update product");
      }

      fetchProducts();
    } catch (error) {
      console.error("Error updating product:", error);
      alert("Error updating product");
    }
  };

  const handleFormClose = () => {
    setShowForm(false);
    setEditingProduct(null);
    fetchProducts();
  };

  if (showForm) {
    return (
      <ProductForm product={editingProduct} onClose={handleFormClose} />
    );
  }

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex justify-between items-center">
        <div className="border-l-4 border-[#C5A059] pl-4">
          <h1 className="text-3xl font-serif text-stone-900 tracking-wide">
            灵物管理
          </h1>
          <p className="text-sm text-stone-500 mt-1">Product Inventory</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="px-6 py-2.5 bg-[#1A1A1A] text-[#C5A059] hover:bg-stone-900 transition-colors font-sans tracking-wide"
        >
          添加灵物
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12 text-stone-500">载入中...</div>
      ) : products.length === 0 ? (
        <div className="bg-[#F7F5F0] border-2 border-dashed border-stone-300 p-12 text-center">
          <p className="text-stone-500">暂无灵物，请添加第一件灵物</p>
        </div>
      ) : (
        <div className="bg-[#F7F5F0] border border-stone-300 overflow-hidden">
          {/* 账簿风格表格 */}
          <table className="min-w-full">
            <thead className="bg-[#E6DCD0]">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  画像
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  名称
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  价格
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  分类
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  状态
                </th>
                <th className="px-6 py-4 text-left text-sm font-serif text-stone-800 tracking-wider">
                  操作
                </th>
              </tr>
            </thead>
            <tbody>
              {products.map((product, index) => (
                <tr
                  key={product.id}
                  className={`
                    border-t border-stone-200 hover:bg-red-50 transition-colors
                    ${index % 2 === 1 ? 'bg-stone-100/50' : 'bg-transparent'}
                  `}
                >
                  <td className="px-6 py-4">
                    {product.images[0] ? (
                      <img
                        src={product.images[0]}
                        alt={product.title}
                        className="h-14 w-14 object-cover border border-stone-300"
                      />
                    ) : (
                      <div className="h-14 w-14 bg-stone-200 border border-stone-300 flex items-center justify-center">
                        <span className="text-stone-400 text-xs">无</span>
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-sans text-stone-900 max-w-xs truncate">
                      {product.title}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-mono text-stone-900 tabular-nums">
                      ¥{product.price}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-stone-600">
                    {product.category}
                  </td>
                  <td className="px-6 py-4">
                    {/* 印戳样式状态标签 */}
                    <span
                      className={`
                        border px-2 py-0.5 text-xs font-serif tracking-widest
                        ${product.is_active
                          ? "border-green-600 text-green-600"
                          : "border-stone-500 text-stone-500"
                        }
                      `}
                    >
                      {product.is_active ? "[ 上 架 ]" : "[ 下 架 ]"}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm space-x-3">
                    <button
                      onClick={() => handleEdit(product)}
                      className="text-[#C5A059] hover:text-[#B8934A] transition-colors"
                    >
                      编辑
                    </button>
                    <button
                      onClick={() => handleToggleActive(product)}
                      className="text-stone-600 hover:text-stone-800 transition-colors"
                    >
                      {product.is_active ? "下架" : "上架"}
                    </button>
                    <button
                      onClick={() => handleDelete(product.id)}
                      className="text-[#B22222] hover:text-red-800 transition-colors"
                    >
                      删除
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
