"use client";

import { useState } from "react";
import { Product } from "@/lib/types";
import { useCartStore } from "@/lib/cart-store";
import Link from "next/link";
import { Button } from "@/components/ui/button";

interface ProductDetailProps {
  product: Product;
  relatedProducts: Product[];
}

export function ProductDetail({ product, relatedProducts }: ProductDetailProps) {
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const addItem = useCartStore((state) => state.addItem);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addItem(product);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      {/* Breadcrumb */}
      <nav className="mb-8">
        <ol className="flex items-center space-x-2 text-sm">
          <li>
            <Link href="/shop" className="text-gray-500 hover:text-shop-gold">
              Shop
            </Link>
          </li>
          <li className="text-gray-400">/</li>
          <li>
            <Link
              href={`/shop?category=${product.category}`}
              className="text-gray-500 hover:text-shop-gold"
            >
              {product.category}
            </Link>
          </li>
          <li className="text-gray-400">/</li>
          <li className="text-shop-charcoal">{product.title}</li>
        </ol>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Images */}
        <div>
          <div className="aspect-square overflow-hidden bg-white mb-4">
            {product.images[selectedImage] ? (
              <img
                src={product.images[selectedImage]}
                alt={product.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                <span className="text-gray-400">No image</span>
              </div>
            )}
          </div>
          {product.images.length > 1 && (
            <div className="flex gap-2">
              {product.images.map((img, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`w-20 h-20 overflow-hidden ${
                    selectedImage === index
                      ? "ring-2 ring-shop-gold"
                      : "opacity-70 hover:opacity-100"
                  }`}
                >
                  <img
                    src={img}
                    alt={`${product.title} ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div>
          <h1 className="font-serif text-3xl md:text-4xl text-shop-charcoal tracking-wide mb-4">
            {product.title}
          </h1>
          <p className="text-2xl text-shop-gold font-sans mb-6">
            ${product.price.toFixed(2)}
          </p>

          {product.description && (
            <div className="prose prose-sm text-gray-600 mb-8 leading-relaxed">
              <p>{product.description}</p>
            </div>
          )}

          {/* Tags */}
          {product.tags.length > 0 && (
            <div className="mb-8">
              <p className="text-sm text-gray-500 uppercase tracking-wider mb-2">
                Properties
              </p>
              <div className="flex flex-wrap gap-2">
                {product.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 text-sm bg-gray-100 text-gray-600"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Quantity */}
          <div className="mb-6">
            <p className="text-sm text-gray-500 uppercase tracking-wider mb-2">
              Quantity
            </p>
            <div className="flex items-center border border-gray-300 w-fit">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="px-4 py-2 text-gray-600 hover:bg-gray-100"
              >
                -
              </button>
              <span className="px-6 py-2 border-x border-gray-300">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="px-4 py-2 text-gray-600 hover:bg-gray-100"
              >
                +
              </button>
            </div>
          </div>

          {/* Add to Cart */}
          <Button
            onClick={handleAddToCart}
            className="w-full py-6 bg-shop-dark hover:bg-shop-charcoal text-white text-sm tracking-widest rounded-none"
          >
            ADD TO CART
          </Button>

          {/* Category */}
          <p className="mt-6 text-sm text-gray-500">
            Category:{" "}
            <Link
              href={`/shop?category=${product.category}`}
              className="text-shop-gold hover:underline"
            >
              {product.category}
            </Link>
          </p>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mt-20">
          <h2 className="font-serif text-2xl text-shop-charcoal text-center mb-8">
            You May Also Like
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {relatedProducts.map((p) => (
              <Link key={p.id} href={`/shop/${p.id}`} className="group">
                <div className="aspect-square overflow-hidden bg-white mb-3">
                  {p.images[0] ? (
                    <img
                      src={p.images[0]}
                      alt={p.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  ) : (
                    <div className="w-full h-full bg-gray-200" />
                  )}
                </div>
                <h3 className="font-serif text-sm text-shop-charcoal text-center">
                  {p.title}
                </h3>
                <p className="text-sm text-shop-gold text-center">
                  ${p.price.toFixed(2)}
                </p>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
