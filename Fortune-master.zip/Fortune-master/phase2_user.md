# Phase 2 PRD: User System & History Storage

## 1. 阶段目标 (Objective)
集成 **Supabase** 作为后端服务，实现以下功能：
1.  **身份认证 (Auth)**：支持邮箱/密码注册登录，以及 Google 一键登录。
2.  **数据存储 (Database)**：设计数据库表结构，存储用户信息和算命历史记录。
3.  **业务逻辑升级**：当用户登录时，自动将 AI 生成的运势结果存入数据库。
4.  **个人中心 (Dashboard)**：用户可以查看历史算命列表和详情。

## 2. 技术栈新增 (Tech Stack Addition)
-   **Backend/DB**: Supabase (PostgreSQL + Auth)
-   **Client SDK**: `@supabase/ssr` (Next.js 官方推荐的服务端渲染兼容包)
-   **Auth UI**: 自定义 Shadcn Form 组件 (不使用 Supabase 原生 UI 库，以保持风格统一)

## 3. 数据库设计 (Database Schema)
**这是核心指令**：请 AI 帮我生成 SQL 并在 Supabase 的 SQL Editor 中运行。

### 3.1 表结构
1.  **Table: `profiles` (用户资料表)**
    -   `id` (uuid, Primary Key): 对应 `auth.users` 的 id。
    -   `email` (text): 用户邮箱。
    -   `full_name` (text): 用户昵称 (可为空)。
    -   `avatar_url` (text): 头像地址。
    -   `updated_at` (timestamp).

2.  **Table: `readings` (算命记录表)**
    -   `id` (uuid, Primary Key, Default: gen_random_uuid()).
    -   `user_id` (uuid, Foreign Key -> profiles.id): 归属用户。
    -   `name` (text): 测算时输入的名字。
    -   `birth_date` (timestamp): 出生日期。
    -   `gender` (text): 性别。
    -   `bazi_json` (jsonb): Phase 1 算出的八字结构化数据 (存下来以备后用)。
    -   `ai_result` (text): 火山方舟生成的完整运势文本。
    -   `created_at` (timestamp, Default: now()).

### 3.2 安全策略 (RLS - Row Level Security)
**必须开启 RLS**，确保用户只能看到自己的数据：
-   `profiles`: 用户可以查看 (`SELECT`) 和更新 (`UPDATE`) 自己的资料。
-   `readings`: 用户只能查看 (`SELECT`) `user_id` 等于自己 ID 的记录。
-   `readings`: 用户只能插入 (`INSERT`) `user_id` 等于自己 ID 的记录。

### 3.3 自动化触发器 (Triggers)
-   当 Supabase Auth 新注册一个用户时，自动触发 PostgreSQL Function，在 `profiles` 表中创建一行对应数据。

## 4. 功能模块需求 (Feature Specs)

### 4.1 认证模块 (Authentication)
-   **登录/注册页 (`/login`)**:
    -   一个 Tab 切换： "登录" / "注册"。
    -   字段：邮箱、密码。
    -   按钮："使用 Google 登录" (OAuth)。
-   **导航栏更新**:
    -   如果未登录：显示 "登录" 按钮。
    -   如果已登录：显示 "我的测算" 和 "退出" 按钮。
-   **Middleware**:
    -   创建 `middleware.ts`，用于刷新 Session 和保护 `/dashboard` 路由（未登录跳转至 `/login`）。

### 4.2 算命逻辑升级 (Logic Update)
修改 Phase 1 的 Server Action（API 接口）：
-   **步骤 A**: 获取当前用户 Session。
-   **步骤 B**: 执行原有的 八字计算 + AI 推理。
-   **步骤 C (新增)**:
    -   如果用户 **已登录**：在 AI 流式输出完成后（或开始时），将本次测算的所有信息 `INSERT` 到 `readings` 表。
    -   如果用户 **未登录**：仅返回结果，不做存储（或者前端提示“登录以保存结果”）。

### 4.3 仪表盘 (`/dashboard`)
-   **列表页**: 展示卡片列表，每个卡片包含：测算名字、测算日期、AI 回复的前 50 个字摘要。
-   **详情页 (`/readings/[id]`)**: 点击列表项进入，展示当时那次测算的完整 AI 回复。

## 5. 开发步骤指令 (Step-by-Step Instructions)

请 AI 辅助按以下步骤执行：

**Step 1: Supabase 初始化**
-   安装依赖: `npm install @supabase/ssr @supabase/supabase-js`
-   创建 `utils/supabase/server.ts`, `client.ts`, `middleware.ts` (参考 Supabase Next.js 官方文档的标准写法)。
-   编写 SQL 建表脚本（包含 RLS 和 Trigger），并指导我在 Supabase Dashboard 运行。

**Step 2: 认证 UI 实现**
-   创建 `/login/page.tsx`。
-   实现 `login` 和 `signup` 的 Server Actions。
-   在 Navbar 组件中根据登录状态切换显示内容。

**Step 3: 数据库写入集成**
-   修改 Phase 1 的算命 Action。
-   引入 Supabase Client，实现写入 `readings` 表的逻辑。

**Step 4: 历史记录展示**
-   创建 `/dashboard/page.tsx` (获取数据并渲染列表)。
-   创建 `/readings/[id]/page.tsx` (获取单条详情)。

**Step 5: 环境变量检查**
-   确保 `.env.local` 中包含了 `NEXT_PUBLIC_SUPABASE_URL` 和 `NEXT_PUBLIC_SUPABASE_ANON_KEY`。