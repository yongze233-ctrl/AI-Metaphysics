"use server";

import { createClient } from "@/utils/supabase/server";
import { requireSuperAdmin, getUserRole } from "@/utils/auth/role";
import { revalidatePath } from "next/cache";

/**
 * 获取当前登录用户的角色
 */
export async function getCurrentUserRole() {
  return await getUserRole();
}

/**
 * 获取所有用户列表
 */
export async function getAllUsers() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("profiles")
    .select("id, email, full_name, avatar_url, role, created_at")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("[getAllUsers] Error:", error);
    throw new Error("获取用户列表失败");
  }

  return data;
}

/**
 * 晋升用户为管理员
 * @param userId 用户ID
 */
export async function promoteUser(userId: string) {
  // 只有超级管理员可以执行此操作
  await requireSuperAdmin();

  const supabase = await createClient();

  // 获取当前用户信息
  const { data: user } = await supabase
    .from("profiles")
    .select("email, role")
    .eq("id", userId)
    .single();

  if (!user) {
    throw new Error("用户不存在");
  }

  // 如果已经是管理员，不执行操作
  if (user.role === "admin" || user.role === "super_admin") {
    throw new Error("该用户已经是管理员");
  }

  // 晋升为管理员
  const { error } = await supabase
    .from("profiles")
    .update({ role: "admin" })
    .eq("id", userId);

  if (error) {
    console.error("[promoteUser] Error:", error);
    throw new Error("晋升失败");
  }

  revalidatePath("/admin/users");
  return { success: true, message: `已晋升 ${user.email} 为管理员` };
}

/**
 * 贬黜管理员为普通用户
 * @param userId 用户ID
 */
export async function demoteUser(userId: string) {
  // 只有超级管理员可以执行此操作
  await requireSuperAdmin();

  const supabase = await createClient();

  // 获取当前用户信息
  const { data: user } = await supabase
    .from("profiles")
    .select("email, role")
    .eq("id", userId)
    .single();

  if (!user) {
    throw new Error("用户不存在");
  }

  // 不能贬黜超级管理员
  if (user.role === "super_admin") {
    throw new Error("无法贬黜超级管理员");
  }

  // 如果已经是普通用户，不执行操作
  if (user.role === "user") {
    throw new Error("该用户已经是普通用户");
  }

  // 贬黜为普通用户
  const { error } = await supabase
    .from("profiles")
    .update({ role: "user" })
    .eq("id", userId);

  if (error) {
    console.error("[demoteUser] Error:", error);
    throw new Error("贬黜失败");
  }

  revalidatePath("/admin/users");
  return { success: true, message: `已将 ${user.email} 贬为普通用户` };
}

/**
 * 搜索用户
 * @param query 搜索关键词（邮箱）
 */
export async function searchUsers(query: string) {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("profiles")
    .select("id, email, full_name, avatar_url, role, created_at")
    .ilike("email", `%${query}%`)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("[searchUsers] Error:", error);
    throw new Error("搜索失败");
  }

  return data;
}
