import OpenAI from "openai";
import { OpenAIStream, StreamingTextResponse } from "ai";
import { generateBaziPrompt, type BaziData } from "@/lib/bazi";

export const runtime = "edge";

// Mode A: 免费简评 (200字以内)
const freeSystemPrompt = `你是一位精通《三命通会》与《渊海子平》的命理大师。请根据用户的八字给出一段 **200字以内** 的性格简评。

要求：
1. 语气神秘、专业
2. 点到为止，不要展开详细分析
3. 只简单概括性格特点，为付费内容留下悬念
4. 最后可以暗示"详细运势分析需解锁完整报告"

输出格式：使用 Markdown，简洁明了。`;

// Mode B: 付费深度解析 (3000字)
const paidSystemPrompt = `你是一位精通《三命通会》与《渊海子平》的命理大师，拥有30年经验。请根据用户的八字给出 **3000字** 的深度解析。

必须包含以下内容：
1. **性格详批**：深入分析性格优缺点、适合的发展方向
2. **未来10年大运**：每个大运的具体影响和建议
3. **今年流年运势**：今年的机遇与挑战
4. **事业运势**：适合的行业、发展建议、贵人方位
5. **感情婚姻**：桃花运、婚姻走向、配偶特征
6. **财运分析**：正财偏财、投资建议、财运旺月

风格要求：
1. 语言半文半白，既有专业术语（如伤官见官、身弱财旺、食神生财等）又要用白话文解释清楚
2. 分析要有理有据，结合天干地支的生克制化关系
3. 语气要庄重又不失亲切，让人感受到专业性
4. 内容要详实丰富，对得起"深度解析"的定位

输出格式：使用 Markdown，层次分明，每个方面单独成段并加粗标题。`;

export async function POST(req: Request) {
  try {
    const { messages, baziData, mode = "free" } = await req.json();

    if (!baziData) {
      return new Response("缺少八字数据", { status: 400 });
    }

    const apiKey = process.env.VOLCENGINE_API_KEY;
    const endpointId = process.env.VOLCENGINE_ENDPOINT_ID;

    if (!apiKey || !endpointId) {
      console.error("环境变量未配置：", { apiKey: !!apiKey, endpointId: !!endpointId });
      return new Response("服务配置错误，请检查环境变量", { status: 500 });
    }

    const client = new OpenAI({
      apiKey: apiKey,
      baseURL: "https://ark.cn-beijing.volces.com/api/v3",
    });

    const baziPrompt = generateBaziPrompt(baziData as BaziData);

    // 根据模式选择不同的 prompt 和 token 限制
    const systemPrompt = mode === "paid" ? paidSystemPrompt : freeSystemPrompt;
    const maxTokens = mode === "paid" ? 4000 : 500;

    const response = await client.chat.completions.create({
      model: endpointId,
      stream: true,
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: baziPrompt,
        },
      ],
      temperature: 0.8,
      max_tokens: maxTokens,
    });

    const stream = OpenAIStream(response as any);

    return new StreamingTextResponse(stream);
  } catch (error: any) {
    console.error("AI 接口调用失败：", error);
    return new Response(
      JSON.stringify({
        error: "AI 服务调用失败",
        details: error.message
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" }
      }
    );
  }
}
