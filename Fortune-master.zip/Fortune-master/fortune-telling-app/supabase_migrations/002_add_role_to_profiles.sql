-- ================================================
-- Phase 12: RBAC - 在 profiles 表添加角色字段
-- ================================================
-- 此脚本将为现有的 profiles 表添加角色管理功能

-- 1. 创建角色枚举类型（更规范，防止拼写错误）
CREATE TYPE user_role AS ENUM ('user', 'admin', 'super_admin');

-- 2. 给 profiles 表添加 role 字段
ALTER TABLE public.profiles
ADD COLUMN role user_role DEFAULT 'user';

-- 3. 将你的账号初始化为超级管理员
UPDATE public.profiles
SET role = 'super_admin'
WHERE email = 'tokedoge666@gmail.com';

-- 4. 创建索引以提高角色查询性能
CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);

-- 5. 更新 profiles 表的 RLS 策略
-- 删除所有旧的策略
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;

-- 新策略：所有人都可以查看 profiles（包括 role 字段）
-- 这样前端可以根据角色显示不同的 UI
CREATE POLICY "Public profiles are viewable by everyone"
ON public.profiles FOR SELECT
USING (true);

-- 新策略：用户可以插入自己的 profile
CREATE POLICY "Users can insert own profile"
ON public.profiles FOR INSERT
WITH CHECK (auth.uid() = id);

-- 6. 创建角色更新策略
-- 策略 A: 用户可以更新自己的 profile（但触发器会保护 role 字段）
CREATE POLICY "Users can update own profile v2"
ON public.profiles FOR UPDATE
USING (auth.uid() = id);

-- 策略 B: Super admin 可以更新任何人的 profile
CREATE POLICY "Super admin can update any profile"
ON public.profiles FOR UPDATE
USING (
  (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'super_admin'
);

-- 7. 创建触发器函数：防止非 super_admin 修改 role 字段
CREATE OR REPLACE FUNCTION public.protect_role_changes()
RETURNS TRIGGER AS $$
DECLARE
  current_user_role user_role;
BEGIN
  -- 获取当前操作用户的角色
  SELECT role INTO current_user_role
  FROM public.profiles
  WHERE id = auth.uid();

  -- 如果 role 字段被修改
  IF OLD.role IS DISTINCT FROM NEW.role THEN
    -- 检查当前用户是否是 super_admin
    IF current_user_role != 'super_admin' THEN
      RAISE EXCEPTION 'Only super_admin can modify user roles';
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建触发器
DROP TRIGGER IF EXISTS protect_role_changes_trigger ON public.profiles;
CREATE TRIGGER protect_role_changes_trigger
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.protect_role_changes();

-- 8. 创建辅助函数：获取当前用户角色
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS user_role AS $$
DECLARE
  v_role user_role;
BEGIN
  SELECT role INTO v_role
  FROM public.profiles
  WHERE id = auth.uid();

  -- 如果没有找到，返回默认值 'user'
  RETURN COALESCE(v_role, 'user'::user_role);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 9. 创建辅助函数：检查当前用户是否是管理员
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    SELECT role IN ('admin', 'super_admin')
    FROM public.profiles
    WHERE id = auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 10. 创建辅助函数：检查当前用户是否是超级管理员
CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    SELECT role = 'super_admin'
    FROM public.profiles
    WHERE id = auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 11. 更新 products 表的 RLS 策略（如果存在）
-- 只允许管理员进行 INSERT/UPDATE/DELETE 操作
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'products') THEN
    -- 删除旧策略
    DROP POLICY IF EXISTS "Products are viewable by everyone" ON public.products;
    DROP POLICY IF EXISTS "Only admins can insert products" ON public.products;
    DROP POLICY IF EXISTS "Only admins can update products" ON public.products;
    DROP POLICY IF EXISTS "Only admins can delete products" ON public.products;

    -- 创建新策略
    EXECUTE 'CREATE POLICY "Products are viewable by everyone" ON public.products FOR SELECT USING (true)';
    EXECUTE 'CREATE POLICY "Only admins can insert products" ON public.products FOR INSERT WITH CHECK (public.is_admin())';
    EXECUTE 'CREATE POLICY "Only admins can update products" ON public.products FOR UPDATE USING (public.is_admin())';
    EXECUTE 'CREATE POLICY "Only admins can delete products" ON public.products FOR DELETE USING (public.is_admin())';
  END IF;
END $$;

-- 12. 更新 orders 表的 RLS 策略（如果存在）
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'orders') THEN
    -- 删除旧策略
    DROP POLICY IF EXISTS "Users can view own orders" ON public.orders;
    DROP POLICY IF EXISTS "Admins can view all orders" ON public.orders;
    DROP POLICY IF EXISTS "Users can insert own orders" ON public.orders;
    DROP POLICY IF EXISTS "Only admins can update orders" ON public.orders;

    -- 创建新策略
    -- SELECT: 用户看自己的订单 OR 管理员看所有订单
    EXECUTE 'CREATE POLICY "Users can view own orders or admins view all"
      ON public.orders FOR SELECT
      USING (user_id = auth.uid() OR public.is_admin())';

    -- INSERT: 用户可以创建自己的订单
    EXECUTE 'CREATE POLICY "Users can create own orders"
      ON public.orders FOR INSERT
      WITH CHECK (user_id = auth.uid())';

    -- UPDATE: 只有管理员可以更新订单状态
    EXECUTE 'CREATE POLICY "Only admins can update orders"
      ON public.orders FOR UPDATE
      USING (public.is_admin())';

    -- DELETE: 只有管理员可以删除订单
    EXECUTE 'CREATE POLICY "Only admins can delete orders"
      ON public.orders FOR DELETE
      USING (public.is_admin())';
  END IF;
END $$;

-- ================================================
-- 完成！现在你的系统已经具备完整的 RBAC 功能
-- ================================================

-- 验证步骤：
-- 1. 检查你的角色：
SELECT email, role FROM public.profiles WHERE email = 'tokedoge666@gmail.com';

-- 2. 查看所有管理员：
SELECT email, role, created_at FROM public.profiles WHERE role IN ('admin', 'super_admin');

-- 3. 测试辅助函数（需要在登录状态下执行）：
-- SELECT public.get_current_user_role();
-- SELECT public.is_admin();
-- SELECT public.is_super_admin();
