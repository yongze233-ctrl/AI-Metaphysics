-- =====================================================
-- Database Cleanup Script
-- =====================================================
-- Created: 2025-12-22
-- Purpose: Remove redundant user_roles table and fix products policies
--
-- INSTRUCTIONS:
-- 1. Backup your database before executing
-- 2. Execute in Supabase SQL Editor
-- 3. Verify using the verification queries at the end
-- =====================================================

BEGIN;

-- =====================================================
-- Part 1: Remove redundant user_roles table
-- =====================================================

-- Note: user_roles table is redundant because we use profiles.role instead
-- All application code uses profiles.role, not user_roles

-- Use DO block to handle table that may not exist
DO $$
BEGIN
  -- Check if table exists before attempting to drop policies
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public'
    AND table_name = 'user_roles'
  ) THEN
    -- Drop all policies first
    DROP POLICY IF EXISTS "Super admins can view all roles" ON public.user_roles;
    DROP POLICY IF EXISTS "Users can view their own role" ON public.user_roles;
    DROP POLICY IF EXISTS "Super admins can insert roles" ON public.user_roles;
    DROP POLICY IF EXISTS "Super admins can update roles" ON public.user_roles;
    DROP POLICY IF EXISTS "Super admins can delete roles" ON public.user_roles;

    -- Drop the trigger
    DROP TRIGGER IF EXISTS update_user_roles_updated_at_trigger ON public.user_roles;

    -- Finally, drop the table
    DROP TABLE public.user_roles CASCADE;

    RAISE NOTICE 'Successfully removed user_roles table';
  ELSE
    RAISE NOTICE 'user_roles table does not exist, skipping...';
  END IF;
END $$;

-- Drop the trigger function (can exist even if table is gone)
DROP FUNCTION IF EXISTS public.update_user_roles_updated_at();

-- Drop helper functions that reference user_roles
-- Note: We have newer versions of these functions that use profiles.role
DROP FUNCTION IF EXISTS public.get_user_role(UUID);
DROP FUNCTION IF EXISTS public.is_admin(UUID);


-- =====================================================
-- Part 2: Fix products table policies
-- =====================================================

-- Currently there are two SELECT policies:
-- 1. "Products are viewable by everyone" (qual: true) - allows viewing ALL products
-- 2. "Public read active products" (qual: is_active = true) - should restrict to active only
--
-- The first policy makes the second one useless.
-- Best practice: Public users should only see active products, admins see all.

-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Products are viewable by everyone" ON public.products;

-- Ensure the restrictive policy exists (should already exist)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
    AND tablename = 'products'
    AND policyname = 'Public read active products'
  ) THEN
    CREATE POLICY "Public read active products"
    ON public.products FOR SELECT
    USING (is_active = true);
  END IF;
END $$;

-- Add admin policy to view all products (including inactive ones)
DROP POLICY IF EXISTS "Admins can view all products" ON public.products;

CREATE POLICY "Admins can view all products"
ON public.products FOR SELECT
USING (
  (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'super_admin')
);

COMMENT ON POLICY "Public read active products" ON public.products IS
'Public users can only view active products';

COMMENT ON POLICY "Admins can view all products" ON public.products IS
'Admins can view all products including inactive ones';


COMMIT;

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================

-- 1. Verify user_roles table is gone
SELECT EXISTS (
  SELECT 1
  FROM information_schema.tables
  WHERE table_schema = 'public'
  AND table_name = 'user_roles'
) AS user_roles_exists;
-- Expected: false

-- 2. Verify products policies
SELECT
  policyname,
  cmd,
  qual
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename = 'products'
  AND cmd = 'SELECT'
ORDER BY policyname;
-- Expected:
--   "Admins can view all products" with admin check
--   "Public read active products" with is_active = true

-- 3. Check all remaining database functions
SELECT
  routine_name,
  routine_type,
  routine_definition
FROM information_schema.routines
WHERE routine_schema = 'public'
  AND (
    routine_name LIKE '%role%'
    OR routine_name LIKE '%admin%'
  )
ORDER BY routine_name;
-- Should show functions from 002_add_role_to_profiles.sql that use profiles.role

-- 4. Summary: All policies on products table
SELECT
  policyname,
  cmd,
  roles
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename = 'products'
ORDER BY cmd, policyname;

-- 5. Verify no orphaned policies reference user_roles
SELECT
  schemaname,
  tablename,
  policyname,
  qual,
  with_check
FROM pg_policies
WHERE qual LIKE '%user_roles%'
   OR with_check LIKE '%user_roles%'
ORDER BY tablename, policyname;
-- Expected: empty result

-- =====================================================
-- EXPECTED RESULTS:
-- =====================================================
-- ✅ user_roles table should be completely removed
-- ✅ products should have 2 SELECT policies:
--    - "Public read active products" (for everyone, is_active = true)
--    - "Admins can view all products" (for admins, no restriction)
-- ✅ No functions or policies should reference user_roles
-- ✅ All helper functions (is_admin, is_super_admin, etc.) from
--    002_add_role_to_profiles.sql should still exist and use profiles.role
-- =====================================================
