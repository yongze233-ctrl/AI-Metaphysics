"use client";

import * as React from "react";
import * as SelectPrimitive from "@radix-ui/react-select";
import { Check, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const EasternSelect = SelectPrimitive.Root;

const EasternSelectGroup = SelectPrimitive.Group;

const EasternSelectValue = SelectPrimitive.Value;

const EasternSelectTrigger = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Trigger> & { label?: string }
>(({ className, children, label, ...props }, ref) => {
  const [isFocused, setIsFocused] = React.useState(false);

  return (
    <div className="relative w-full">
      {label && (
        <label className="block font-chinese text-sm text-ink-soot mb-2 tracking-wide">
          {label}
        </label>
      )}
      <div className="relative">
        <SelectPrimitive.Trigger
          ref={ref}
          className={cn(
            "flex w-full items-center justify-between bg-transparent px-3 py-3 text-base font-chinese",
            "border-0 border-b-2 border-stone-400",
            "focus:border-cinnabar focus:outline-none",
            "transition-all duration-300",
            "text-ink-soot",
            "disabled:cursor-not-allowed disabled:opacity-50",
            "[&>span]:line-clamp-1",
            className
          )}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          {...props}
        >
          {children}
          <SelectPrimitive.Icon asChild>
            <ChevronDown className="h-4 w-4 text-ink-light transition-transform duration-300 data-[state=open]:rotate-180" />
          </SelectPrimitive.Icon>
        </SelectPrimitive.Trigger>

        {/* Ink spread animation on focus */}
        <div
          className={cn(
            "absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-transparent via-cinnabar to-transparent transition-all duration-500",
            isFocused ? "w-full opacity-100" : "w-0 opacity-0"
          )}
        />

        {/* Decorative corner accents */}
        <div
          className={cn(
            "absolute bottom-0 left-0 w-2 h-2 border-l-2 border-b-2 transition-all duration-300",
            isFocused ? "border-cinnabar opacity-100" : "border-gold/20 opacity-0"
          )}
        />
        <div
          className={cn(
            "absolute bottom-0 right-0 w-2 h-2 border-r-2 border-b-2 transition-all duration-300",
            isFocused ? "border-cinnabar opacity-100" : "border-gold/20 opacity-0"
          )}
        />
      </div>
    </div>
  );
});
EasternSelectTrigger.displayName = SelectPrimitive.Trigger.displayName;

const EasternSelectContent = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Content>
>(({ className, children, position = "popper", ...props }, ref) => (
  <SelectPrimitive.Portal>
    <SelectPrimitive.Content
      ref={ref}
      className={cn(
        "relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-sm bg-rice-paper border-2 border-gold/30 shadow-lg",
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        position === "popper" &&
          "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
        className
      )}
      position={position}
      {...props}
    >
      <SelectPrimitive.Viewport
        className={cn(
          "p-1",
          position === "popper" &&
            "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
        )}
      >
        {children}
      </SelectPrimitive.Viewport>
    </SelectPrimitive.Content>
  </SelectPrimitive.Portal>
));
EasternSelectContent.displayName = SelectPrimitive.Content.displayName;

const EasternSelectLabel = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Label>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Label
    ref={ref}
    className={cn("py-1.5 pl-8 pr-2 text-sm font-chinese font-semibold text-cinnabar", className)}
    {...props}
  />
));
EasternSelectLabel.displayName = SelectPrimitive.Label.displayName;

const EasternSelectItem = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Item>
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex w-full cursor-pointer select-none items-center rounded-sm py-2 pl-8 pr-2 text-sm font-chinese outline-none",
      "focus:bg-cinnabar/10 focus:text-cinnabar",
      "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      "text-ink-soot",
      "transition-colors duration-200",
      className
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <SelectPrimitive.ItemIndicator>
        <Check className="h-4 w-4 text-cinnabar" />
      </SelectPrimitive.ItemIndicator>
    </span>

    <SelectPrimitive.ItemText>{children}</SelectPrimitive.ItemText>
  </SelectPrimitive.Item>
));
EasternSelectItem.displayName = SelectPrimitive.Item.displayName;

const EasternSelectSeparator = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-gold/20", className)}
    {...props}
  />
));
EasternSelectSeparator.displayName = SelectPrimitive.Separator.displayName;

export {
  EasternSelect,
  EasternSelectGroup,
  EasternSelectValue,
  EasternSelectTrigger,
  EasternSelectContent,
  EasternSelectLabel,
  EasternSelectItem,
  EasternSelectSeparator,
};
