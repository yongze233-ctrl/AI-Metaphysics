"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export function DestinySection() {
  return (
    <section className="relative min-h-screen bg-rice-paper-texture flex items-center justify-center overflow-hidden py-20">
      {/* Decorative background elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 text-9xl text-ink font-brush">命</div>
        <div className="absolute bottom-10 right-10 text-9xl text-ink font-brush">理</div>
        <div className="absolute top-1/2 left-1/4 text-7xl text-ink font-brush opacity-30">福</div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="wave-divider w-32 mx-auto mb-8 text-gold" />
          <h2 className="font-chinese text-4xl md:text-5xl text-ink-soot mb-4 tracking-wider">
            命理测算
          </h2>
          <p className="font-chinese text-lg text-ink-light">
            探寻命运轨迹 · 预见未来可能
          </p>
        </motion.div>

        {/* Ancient Scroll Card */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
          className="max-w-5xl mx-auto"
        >
          <div className="relative group">
            {/* Scroll background with border lattice */}
            <div className="border-lattice text-gold bg-gradient-to-br from-rice-paper via-white to-rice-paper p-8 md:p-12 scroll-shadow rounded-sm">
              {/* Corner decorations */}
              <div className="absolute top-0 left-0 w-16 h-16 border-t-4 border-l-4 border-cinnabar opacity-40 -m-2" />
              <div className="absolute top-0 right-0 w-16 h-16 border-t-4 border-r-4 border-cinnabar opacity-40 -m-2" />
              <div className="absolute bottom-0 left-0 w-16 h-16 border-b-4 border-l-4 border-cinnabar opacity-40 -m-2" />
              <div className="absolute bottom-0 right-0 w-16 h-16 border-b-4 border-r-4 border-cinnabar opacity-40 -m-2" />

              <div className="grid md:grid-cols-2 gap-12 items-center">
                {/* Left: Rotating Compass */}
                <div className="relative flex items-center justify-center">
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.3 }}
                    className="relative w-64 h-64 md:w-80 md:h-80"
                  >
                    {/* Rotating outer ring */}
                    <motion.div
                      className="absolute inset-0 opacity-20 group-hover:opacity-40 transition-opacity"
                      animate={{ rotate: 360 }}
                      transition={{
                        duration: 60,
                        repeat: Infinity,
                        ease: "linear",
                      }}
                    >
                      <div className="absolute inset-0 border-4 border-gold rounded-full" />
                      <div className="absolute inset-8 border-2 border-gold rounded-full" />
                      <div className="absolute inset-16 border border-gold rounded-full" />
                      {/* Cardinal points */}
                      <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 font-chinese text-gold text-sm">子</div>
                      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-2 font-chinese text-gold text-sm">午</div>
                      <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-2 font-chinese text-gold text-sm">卯</div>
                      <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-2 font-chinese text-gold text-sm">酉</div>
                    </motion.div>

                    {/* Center compass plate - slower rotation */}
                    <motion.div
                      className="absolute inset-12 bg-gradient-to-br from-gold/20 to-cinnabar/20 rounded-full flex items-center justify-center opacity-60 group-hover:opacity-100 transition-opacity"
                      animate={{ rotate: -360 }}
                      transition={{
                        duration: 40,
                        repeat: Infinity,
                        ease: "linear",
                      }}
                    >
                      <div className="font-brush text-6xl text-cinnabar">
                        命
                      </div>
                    </motion.div>

                    {/* Static Yin Yang center */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <motion.div
                        animate={{
                          scale: [1, 1.1, 1],
                          opacity: [0.6, 1, 0.6],
                        }}
                        transition={{
                          duration: 4,
                          repeat: Infinity,
                          ease: "easeInOut",
                        }}
                        className="text-7xl text-ink-soot"
                      >
                        ☯
                      </motion.div>
                    </div>
                  </motion.div>
                </div>

                {/* Right: Content */}
                <div className="space-y-6">
                  <motion.div
                    initial={{ opacity: 0, x: 30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                    viewport={{ once: true }}
                  >
                    <h3 className="font-brush text-3xl md:text-4xl text-cinnabar mb-4 leading-relaxed">
                      输入生辰
                      <br />
                      解锁人生剧本
                    </h3>
                    <p className="font-chinese text-ink-soot leading-loose text-lg mb-6">
                      基于传统八字命理学，融合现代AI智能分析，为您精准解读命运密码。了解自身优势与挑战，把握人生关键节点。
                    </p>

                    <ul className="space-y-3 mb-8">
                      {[
                        "八字排盘 · 五行分析",
                        "性格特质 · 天赋解读",
                        "事业财运 · 感情婚姻",
                        "流年运势 · 趋吉避凶",
                      ].map((item, index) => (
                        <motion.li
                          key={index}
                          initial={{ opacity: 0, x: 20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                          viewport={{ once: true }}
                          className="flex items-center gap-3 font-chinese text-ink-light"
                        >
                          <span className="text-cinnabar text-lg">•</span>
                          {item}
                        </motion.li>
                      ))}
                    </ul>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.8 }}
                    viewport={{ once: true }}
                  >
                    <Button
                      asChild
                      size="lg"
                      className="bg-cinnabar hover:bg-cinnabar-dark text-white font-chinese text-lg px-8 py-6 rounded-sm border-2 border-cinnabar-dark shadow-lg hover:shadow-xl transition-all"
                    >
                      <Link href="/calculate">
                        开始测算
                        <span className="ml-2">→</span>
                      </Link>
                    </Button>
                  </motion.div>
                </div>
              </div>
            </div>

            {/* Subtle shadow/glow effect on hover */}
            <div className="absolute -inset-4 bg-gradient-to-r from-gold/10 via-cinnabar/10 to-gold/10 rounded-sm blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
