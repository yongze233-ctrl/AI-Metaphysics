import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { Resend } from "resend";

export async function POST(request: Request) {
  try {
    const { orderId, trackingNumber, carrier } = await request.json();

    if (!orderId || !trackingNumber || !carrier) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    const supabaseAdmin = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // Get order details
    const { data: order, error: orderError } = await supabaseAdmin
      .from("orders")
      .select("*, profiles(email)")
      .eq("id", orderId)
      .single();

    if (orderError || !order) {
      return NextResponse.json(
        { error: "Order not found" },
        { status: 404 }
      );
    }

    // Get user email
    const userEmail = order.profiles?.email;
    if (!userEmail) {
      console.log("No user email found for order, skipping notification");
      return NextResponse.json({ success: true, message: "No email to send" });
    }

    // Send shipping notification to customer
    const resend = new Resend(process.env.RESEND_API_KEY);

    const itemsList = order.items
      ?.map((item: any) => `- ${item.title} x ${item.quantity}`)
      .join("\n") || "Your items";

    await resend.emails.send({
      from: "Fortune Shop <onboarding@resend.dev>",
      to: [userEmail],
      subject: `Your Order Has Been Shipped! - Order #${orderId.substring(0, 8)}`,
      text: `
Great news! Your order has been shipped!

Order ID: ${orderId}

Items:
${itemsList}

Tracking Information:
Carrier: ${carrier}
Tracking Number: ${trackingNumber}

You can track your package using the tracking number above on the ${carrier} website.

Thank you for shopping with us!

---
Fortune Shop
      `,
    });

    console.log(`Shipping notification sent to ${userEmail} for order ${orderId}`);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error sending shipping email:", error);
    return NextResponse.json(
      { error: "Failed to send email" },
      { status: 500 }
    );
  }
}
