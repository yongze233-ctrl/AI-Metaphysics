# Phase 4 PRD: Dropshipping Store & Admin Dashboard

## 1. 阶段目标 (Objective)
1.  **C 端商城 (`/shop`)**：高端法物商城，支持购物车、标签筛选、Stripe 支付（自动收集地址）。
2.  **B 端后台 (`/admin`)**：
    -   **商品管理**：可视化上传商品、图片、设置标签。
    -   **订单管理**：查看新订单，回填物流单号 (Tracking Number)。
3.  **自动化通知**：用户下单后，系统自动发送邮件给**管理员**（你），包含客户地址和商品信息，以便你向供应商下单。
4.  **UI/UX**: 模仿 Kailashenergy 的设计语言（大地色系、衬线字体、沉浸式体验），摆脱“廉价工具站”的感觉。
### 字体与排版
-   **Headings (标题)**: 使用 **Playfair Display** 或 **Cinzel** (Google Fonts)。营造神秘、传统、高端的感觉。
-   **Body (正文)**: 使用 **Lato** 或 **Montserrat**。保证阅读清晰。
-   **风格**: 字间距微宽 (`tracking-wide`)，行高舒适 (`leading-relaxed`)。

### 配色方案 (Tailwind Config)
-   **Background**: 暖米色/羊皮纸色 (`#F9F8F4`) 或 深邃黑 (`#0C0C0C`)。
-   **Primary**: 鎏金色 (`#D4AF37`) 或 藏青色 (`#1A237E`)。
-   **Text**: 炭灰色 (`#333333`) 而非纯黑。

### 组件风格 (Shadcn Customization)
-   **Buttons**: 直角 (`rounded-none`) 或极小圆角 (`rounded-sm`)，黑色实心背景，白色文字，Hover 时变为深灰。
-   **Cards**: 去除边框和阴影，采用“图片+底部文字”的极简布局。
-   **Images**: 必须使用高质量大图，支持 Hover 放大效果 (`transition-transform duration-500 hover:scale-105`)。

## 2. 技术栈新增 (Tech Stack)
-   **State Management**: `zustand` (购物车)。
-   **Email Service**: `resend` (用于发送订单通知邮件，免费且好用)。
-   **UI Components**: Shadcn `Table`, `Dialog`, `Sheet`, `Select`.

## 3. 数据库设计 (Database Schema)
我们需要两张核心表：`products` (商品) 和 `orders` (订单)。

### 3.1 表结构指令
请 AI 帮我生成以下 SQL：

```sql
-- 1. 商品表 (Products)
create table public.products (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  price numeric not null,
  images text[] not null,          -- 图片URL数组
  category text not null,          -- 分类
  tags text[] not null,            -- 标签 (用于推荐)
  is_active boolean default true,  -- 上下架状态
  created_at timestamp with time zone default now()
);

-- 2. 订单表 (Orders)
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id), -- 可为空(如果是匿名购买)
  stripe_session_id text unique,
  amount_total numeric,
  currency text,
  status text default 'paid',      -- 'paid', 'shipped', 'completed'
  
  -- 关键：无货源模式需要的发货信息
  shipping_address jsonb,          -- Stripe 传回来的详细地址
  items jsonb,                     -- 买了什么 (快照)
  
  -- 物流信息 (管理员回填)
  tracking_number text,            -- 快递单号
  carrier text,                    -- 快递公司 (e.g. USPS, DHL)
  
  created_at timestamp with time zone default now()
);

-- 3. RLS 权限 (关键)
-- Products: 所有人可读，只有管理员(Service Role)可写
alter table public.products enable row level security;
create policy "Public read products" on public.products for select using (true);

-- Orders: 用户只能看自己的，管理员(Service Role)可看所有
alter table public.orders enable row level security;
create policy "User view own orders" on public.orders for select using (auth.uid() = user_id);
```

## 4. 业务流程 (Workflows)

### 4.1 管理员上架流程 (Admin Product)
-   访问 `/admin/products` (需要简单的密码保护或检查特定邮箱)。
-   点击 "Add Product"。
-   填写标题、价格、标签。
-   **图片上传**：直接拖拽上传到 Supabase Storage，自动获取 URL 填入表单。
-   点击 Save -> 存入数据库。
-   *注意：无货源模式下，Price ID 可由后端动态创建，或者在后台手动填入 Stripe Price ID。为简化开发，建议后端根据数据库价格动态创建 Stripe Session，不强制绑定 Stripe Product ID。*

### 4.2 用户购买流程 (User Buying)
1.  **浏览**：在 `/shop` 看到商品，加入购物车 (Zustand)。
2.  **结算**：点击 Checkout -> 调用 `/api/checkout`。
3.  **支付**：在 Stripe 页面填写信用卡 + **收货地址 (Shipping Address)**。
4.  **回调**：
    -   Stripe Webhook 收到 `checkout.session.completed`。
    -   **存库**：将 `shipping_details` 和 `line_items` 存入 `orders` 表。
    -   **通知**：调用 Resend API，发一封邮件给**你自己**：
        > "新订单！客户张三，地址：纽约xx街...，购买了：红水晶x1。请去 AliExpress 下单。"

### 4.3 发货流程 (Fulfillment)
1.  你去供应商（1688/Temu/AliExpress）下单，填客户地址。
2.  供应商发货，给你单号。
3.  你回到 `/admin/orders`。
4.  找到对应订单，点击 "Mark as Shipped"。
5.  填入单号 (Tracking Number)。
6.  系统更新数据库状态为 `shipped`。
7.  系统自动发邮件给客户："您的宝贝已发货，单号是..."。

### 5 智能推荐算法 (Smart Matching)
-   场景：用户算完命，进入结果页 /result/[id]。
-   AI 分析: 在 Phase 3 的 Prompt 中，让 AI 输出一个 JSON 字段 recommended_tags。
-   Example: AI 算出用户缺金且漏财，输出 ["Metal", "Wealth"]。
-   查询匹配:
-   前端拿到 Tags，调用 Supabase 查询：
-   SELECT * FROM products WHERE tags && ['Wealth', 'Metal'] LIMIT 3;
-   (注: && 是 Postgres 的数组重叠操作符，意为“包含任意一个标签”)。

## 6. 开发步骤指令 (Step-by-Step)

请 AI 辅助按以下步骤执行：

**Step 1: 环境与数据库**
-   配置 `Resend` (注册账号，获取 API Key)。
-   运行 SQL 建表。
-   创建 Supabase Storage Bucket `product-images` (Public)。

**Step 2: 后台管理端 (`/admin`)**
-   创建 `/admin` 布局。
-   **安全校验**：创建一个简单的 Middleware，只允许特定邮箱 (你的邮箱) 访问 `/admin` 路由。
-   **商品管理页**: 实现上传图片、添加商品的表单。

**Step 3: 商城前端 (`/shop`)**
-   实现商品列表、详情页、购物车(Zustand)。
-   UI 参考 Kailashenergy：大图、留白、高级感。

**Step 4: 支付与订单处理**
-   修改 `/api/checkout`：启用 `shipping_address_collection`。
-   修改 Webhook：
    -   解析 Stripe 传回的地址信息。
    -   插入 `orders` 表。
    -   使用 `Resend` 发送邮件通知管理员。

**Step 5: 订单管理与发货**
-   在 `/admin` 增加订单列表页。
-   实现 "发货" 功能：弹窗输入单号 -> 更新数据库。
-   在前端 `/dashboard` 用户中心，展示订单状态和物流单号。
```

---