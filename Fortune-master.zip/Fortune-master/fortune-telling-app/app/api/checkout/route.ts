import { createClient } from "@/utils/supabase/server";
import { NextResponse } from "next/server";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

export async function POST(req: Request) {
  try {
    const supabase = await createClient();

    // 获取当前用户
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json(
        { error: "请先登录" },
        { status: 401 }
      );
    }

    const { readingId } = await req.json();

    if (!readingId) {
      return NextResponse.json(
        { error: "缺少 readingId" },
        { status: 400 }
      );
    }

    // 验证该记录属于当前用户
    const { data: reading, error: readingError } = await supabase
      .from("readings")
      .select("id, is_paid")
      .eq("id", readingId)
      .eq("user_id", user.id)
      .single();

    if (readingError || !reading) {
      return NextResponse.json(
        { error: "记录不存在或无权访问" },
        { status: 404 }
      );
    }

    if (reading.is_paid) {
      return NextResponse.json(
        { error: "该记录已支付" },
        { status: 400 }
      );
    }

    // 获取请求来源
    const origin = req.headers.get("origin") || "http://localhost:3000";

    // 创建 Stripe Checkout Session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price: process.env.STRIPE_PRICE_ID!,
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${origin}/readings/${readingId}?success=true`,
      cancel_url: `${origin}/readings/${readingId}`,
      metadata: {
        reading_id: readingId,
        user_id: user.id,
      },
      customer_email: user.email,
    });

    // 将 session_id 保存到数据库
    await supabase
      .from("readings")
      .update({ stripe_session_id: session.id })
      .eq("id", readingId);

    return NextResponse.json({ url: session.url });
  } catch (error: any) {
    console.error("创建支付会话失败：", error);
    return NextResponse.json(
      { error: error.message || "创建支付会话失败" },
      { status: 500 }
    );
  }
}
