"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export function HeroCarousel() {
  return (
    <div className="relative h-screen overflow-hidden bg-ink">
      {/* Ink Wash Background Animation */}
      <div className="absolute inset-0">
        {/* Base ink wash gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-ink via-indigo to-ink" />

        {/* Animated ink clouds */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-transparent via-indigo/30 to-transparent"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1,
          }}
          className="absolute bottom-0 right-0 w-full h-full bg-gradient-to-tl from-transparent via-cinnabar/20 to-transparent"
        />

        {/* Floating particles */}
        <div className="absolute inset-0">
          <motion.div
            animate={{ y: [0, -20, 0], x: [0, 10, 0] }}
            transition={{ duration: 6, repeat: Infinity }}
            className="absolute top-1/4 left-1/4 w-2 h-2 bg-gold rounded-full opacity-40"
          />
          <motion.div
            animate={{ y: [0, 20, 0], x: [0, -10, 0] }}
            transition={{ duration: 8, repeat: Infinity, delay: 1 }}
            className="absolute top-1/3 right-1/3 w-3 h-3 bg-gold/30 rounded-full opacity-40"
          />
          <motion.div
            animate={{ y: [0, -15, 0], x: [0, 15, 0] }}
            transition={{ duration: 7, repeat: Infinity, delay: 2 }}
            className="absolute bottom-1/4 right-1/4 w-2 h-2 bg-gold/50 rounded-full opacity-40"
          />
        </div>
      </div>

      {/* Content Container */}
      <div className="relative h-full flex items-center justify-center px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-center gap-12 md:gap-20">
          {/* Vertical Text (Traditional) */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="hidden md:block"
          >
            <div className="vertical-text font-brush text-7xl lg:text-8xl text-gold tracking-wider leading-loose">
              探知天命
            </div>
          </motion.div>

          {/* Center Content */}
          <div className="text-center">
            {/* Mobile horizontal title */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.3 }}
              className="md:hidden font-brush text-5xl sm:text-6xl text-gold mb-4 tracking-wide"
            >
              探知天命
            </motion.h1>

            {/* Compass/Seal decoration */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="mb-8"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                className="relative mx-auto w-32 h-32 md:w-40 md:h-40"
              >
                {/* Outer ring */}
                <div className="absolute inset-0 border-2 border-gold/30 rounded-full" />
                <div className="absolute inset-4 border border-gold/20 rounded-full" />
                {/* Center symbol */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-5xl md:text-6xl text-gold">☯</span>
                </div>
              </motion.div>
            </motion.div>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.7 }}
              className="font-chinese text-xl md:text-2xl text-rice-paper mb-8 tracking-widest leading-relaxed"
            >
              千年命理智慧 · 解读人生密码
            </motion.p>

            {/* CTA Button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.9 }}
            >
              <Button
                asChild
                size="lg"
                className="bg-cinnabar hover:bg-cinnabar-dark text-white font-chinese text-lg px-10 py-6 rounded-full relative overflow-hidden group border-2 border-cinnabar-dark shadow-lg shadow-cinnabar/30"
              >
                <Link href="/calculate">
                  <span className="relative z-10">立即测算</span>
                  <motion.div
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0, 0.3, 0],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                    className="absolute inset-0 bg-white rounded-full"
                  />
                </Link>
              </Button>
            </motion.div>
          </div>

          {/* Vertical Text (Right side) */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="hidden md:block"
          >
            <div className="vertical-text font-brush text-7xl lg:text-8xl text-gold tracking-wider leading-loose">
              顺势而为
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent" />
    </div>
  );
}
