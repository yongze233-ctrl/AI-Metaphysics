**前置条件**：用户系统 (Phase 2) 和 管理员后台 (Phase 5 Admin UI) 已存在。
**目标**：
1.  **数据库化**：在数据库中存储用户角色 (`admin` / `user`)，不再依赖代码里的邮箱列表。
2.  **动态管理**：超级管理员可以在后台界面“任命”或“罢免”其他管理员。
3.  **全链路风控**：在 Middleware（路由层）、Server Actions（逻辑层）和 RLS（数据层）三重关卡严控权限。

## 1. 数据库变更 (Database Schema)

我们需要修改 `profiles` 表来存储角色信息。

**SQL 指令**:
请 AI 协助执行以下 SQL（或者手动在 Supabase SQL Editor 执行）：

```sql
-- 1. 创建角色枚举类型 (更规范，防止拼写错误)
CREATE TYPE user_role AS ENUM ('user', 'admin', 'super_admin');

-- 2. 给 profiles 表添加 role 字段
ALTER TABLE public.profiles 
ADD COLUMN role user_role DEFAULT 'user';

-- 3. 将你的账号初始化为超级管理员 (替换你的真实邮箱)
UPDATE public.profiles
SET role = 'super_admin'
WHERE email = 'tokedoge666@gmail.com';

-- 4. 开启 profiles 表的 RLS (如果之前没开)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 5. 权限策略更新 (RLS Policies)
-- 允许所有人读取 role 字段 (前端需要判断显示什么UI)
CREATE POLICY "Public profiles are viewable by everyone" 
ON public.profiles FOR SELECT USING (true);

-- 只有 'super_admin' 可以修改别人的 role
CREATE POLICY "Only Super Admin can update roles" 
ON public.profiles FOR UPDATE 
USING (
  (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'super_admin'
);
```

## 2. 核心安全逻辑升级 (Security Logic)

### 2.1 路由拦截 (Middleware)
**文件**: `utils/supabase/middleware.ts`
**逻辑变更**:
-   **旧逻辑**: 检查 `user.email` 是否在 `["tokedoge666@..."]` 数组里。
-   **新逻辑**:
    1.  获取当前用户 `user`。
    2.  查询 `profiles` 表：`SELECT role FROM profiles WHERE id = user.id`。
    3.  如果 `role` 不是 `admin` 或 `super_admin`，且试图访问 `/admin` 开头的路径 -> 强制重定向回首页。

### 2.2 数据层拦截 (Row Level Security - RLS)
这是最底层的防线。即使有人绕过了前端，也无法直接操作数据库。

**更新 `products` 表策略**:
-   `SELECT`: `true` (所有人可读)。
-   `INSERT/UPDATE/DELETE`: 仅允许 `role` 为 `admin` 或 `super_admin` 的用户。

**更新 `orders` 表策略**:
-   `SELECT`: 用户看自己的 (`user_id = auth.uid()`) OR 管理员看所有 (`role IN ('admin', 'super_admin')`)。
-   `UPDATE`: 仅管理员可更新状态/物流信息。

### 2.3 逻辑层拦截 (Server Actions)
在 `app/admin` 下的所有 Server Actions（如 `createProduct`, `updateOrder`）的开头，必须加入权限检查代码：

```typescript
// 示例伪代码
const isAdmin = async () => {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;
  
  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();
    
  return profile?.role === 'admin' || profile?.role === 'super_admin';
}

// 在 Action 中使用
export async function deleteProduct(id) {
  if (!await isAdmin()) {
    throw new Error("Unauthorized: 只有内务府人员可执行此操作");
  }
  // ...继续执行
}
```

## 3. 后台管理界面新增功能 (Admin UI)

我们需要在后台增加一个 **“人员管理” (Personnel)** 模块。

### 3.1 页面设计
-   **路径**: `/admin/users`
-   **入口**: 侧边栏新增“僚属管理”或“人员名册”。
-   **UI 风格**: 延续 Phase 5 的“内务府”风格。
    -   表格展示所有注册用户。
    -   列：头像、昵称、邮箱、**当前身份 (印章样式)**、注册时间、操作。

### 3.2 功能交互
-   **搜索**: 按邮箱搜索用户。
-   **权限变更**:
    -   在“操作”列，对于普通用户，显示“**晋升**”按钮（变为 Admin）。
    -   对于管理员，显示“**贬黜**”按钮（变为 User）。
    -   *保护机制*: 无法更改 `super_admin` 的权限。

## 4. 开发步骤指令 (Step-by-Step)

请 AI 辅助按以下步骤执行：

**Step 1: 数据库迁移**
-   运行上述 SQL 脚本，添加 `role` 字段并设置初始超级管理员。
-   更新 Supabase RLS 策略，确保 `products` 和 `orders` 表受到 Role 保护。

**Step 2: 工具函数封装**
-   创建一个 `utils/auth/role.ts` 文件。
-   封装 `getUserRole()` 函数，用于在 Server Component 和 Action 中快速获取当前用户角色。

**Step 3: 升级 Middleware**
-   修改 `middleware.ts`，替换硬编码邮箱检查，改为查询数据库角色。

**Step 4: 实现人员管理页面**
-   创建 `/admin/users/page.tsx`。
-   实现用户列表展示。
-   实现 `promoteUser` and `demoteUser` 的 Server Actions。

**Step 5: 全局权限审查**
-   扫描所有 Admin 相关的 Server Actions (上架商品、发货等)，加上 `isAdmin()` 检查。
-   前端控制：在 Navbar 上，只有当检测到 `role === 'admin'` 时，才显示“进入后台”的入口按钮。

