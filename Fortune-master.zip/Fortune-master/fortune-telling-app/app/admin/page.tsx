import Link from "next/link";
import { TrendingUp, Package, ShoppingCart, DollarSign } from "lucide-react";

// 令牌样式的统计卡片组件
function StatCard({
  title,
  value,
  unit,
  icon: Icon,
}: {
  title: string;
  value: string | number;
  unit?: string;
  icon: React.ElementType;
}) {
  return (
    <div className="bg-[#F7F5F0] border-4 border-double border-stone-800 p-6 relative group hover:shadow-lg transition-shadow">
      {/* 红色印章标签 */}
      <div className="absolute -top-3 left-6">
        <div className="bg-[#F7F5F0] px-3 py-1 border border-[#B22222] text-[#B22222] text-xs font-serif tracking-widest">
          {title}
        </div>
      </div>

      {/* 图标 */}
      <div className="absolute top-4 right-4 text-stone-300">
        <Icon className="w-8 h-8" strokeWidth={1} />
      </div>

      {/* 巨大的数字 */}
      <div className="mt-6 flex items-baseline">
        <span className="text-5xl font-serif text-stone-900 tracking-tight">
          {value}
        </span>
        {unit && (
          <span className="ml-2 text-xl text-stone-500 font-serif">{unit}</span>
        )}
      </div>

      {/* 装饰性底纹 */}
      <div className="mt-4 h-px bg-gradient-to-r from-stone-300 via-stone-400 to-stone-300 opacity-30" />
    </div>
  );
}

export default function AdminDashboard() {
  // TODO: 后续接入真实数据
  const stats = [
    { title: "今日营收", value: "2,888", unit: "元", icon: DollarSign },
    { title: "待发货", value: "15", unit: "单", icon: ShoppingCart },
    { title: "上架灵物", value: "38", unit: "件", icon: Package },
    { title: "本月增长", value: "+23", unit: "%", icon: TrendingUp },
  ];

  return (
    <div className="space-y-8">
      {/* 页面标题 */}
      <div className="border-l-4 border-[#C5A059] pl-4">
        <h1 className="text-3xl font-serif text-stone-900 tracking-wide">
          内务总览
        </h1>
        <p className="text-sm text-stone-500 mt-1">Imperial Dashboard</p>
      </div>

      {/* 统计令牌卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <StatCard
            key={stat.title}
            title={stat.title}
            value={stat.value}
            unit={stat.unit}
            icon={stat.icon}
          />
        ))}
      </div>

      {/* 快捷入口 */}
      <div className="mt-12">
        <h2 className="text-xl font-serif text-stone-900 mb-4 border-b border-stone-300 pb-2">
          快捷入口
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link
            href="/admin/products"
            className="bg-[#F7F5F0] border border-stone-300 p-5 hover:border-[#C5A059] hover:shadow-md transition-all group"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-sans text-stone-900 group-hover:text-[#C5A059] transition-colors">
                  灵物管理
                </h3>
                <p className="text-sm text-stone-500 mt-1">
                  Manage your product catalog
                </p>
              </div>
              <Package className="w-6 h-6 text-stone-400 group-hover:text-[#C5A059] transition-colors" strokeWidth={1.5} />
            </div>
          </Link>

          <Link
            href="/admin/orders"
            className="bg-[#F7F5F0] border border-stone-300 p-5 hover:border-[#C5A059] hover:shadow-md transition-all group"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-sans text-stone-900 group-hover:text-[#C5A059] transition-colors">
                  订单管理
                </h3>
                <p className="text-sm text-stone-500 mt-1">
                  View and fulfill customer orders
                </p>
              </div>
              <ShoppingCart className="w-6 h-6 text-stone-400 group-hover:text-[#C5A059] transition-colors" strokeWidth={1.5} />
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}
