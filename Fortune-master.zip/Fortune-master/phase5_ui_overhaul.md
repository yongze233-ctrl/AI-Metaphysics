1. 设计目标 (Design Objective)
风格定位：神秘、东方美学、极简高端（参考 Kailashenergy）。
交互体验：沉浸式、丝滑动画、响应式布局。
核心改动：
全新导航栏：左 Logo，中菜单。
Hero 区域：全屏轮播图。
算命入口：沉浸式引导卡片。
商城入口：创新型商品展示墙。
2. 技术栈新增 (Tech Stack)
Animation: framer-motion (用于滚动动画、进入效果、Hover 效果)。
Carousel: embla-carousel-react (轻量级、高性能轮播组件)。
Icons: lucide-react (保持统一)。
3. 页面详细设计 (Detailed Design)
3.1 导航栏 (Navbar)
布局：
左侧：Logo（请使用简单的文字 Logo 或 SVG 图标，字号较大，衬线体）。
中间：导航链接组（Flex 居中，间距适中）。
"Destiny Guide" (命理指引) -> 指向 / 或 /calculate
"Spiritual Store" (命理商城) -> 指向 /shop
"More" (其他) -> 指向 /about (暂为占位)
右侧：用户头像 / 购物车图标 / 登录按钮。
交互：
默认透明背景，文字白色。
向下滚动超过 100px 后，背景变为磨砂玻璃效果 (Blur) 或 纯黑/深色背景，固定在顶部 (Sticky)。
移动端：折叠为汉堡菜单 (Hamburger Menu)。
3.2 区域一：全屏轮播 (Hero Carousel)
高度：100vh (占满第一屏)。
内容：
背景：高质量大图轮播（建议 3-4 张，主题：星空、水晶、禅意场景）。
遮罩：图片上方叠加一层黑色渐变 (bg-gradient-to-t from-black/60 to-transparent) 以保证文字可读。
文字：居中显示 Slogan（例如 "Discover Your Fate, Empower Your Soul"），配合淡入动画。
指示器：底部居中显示轮播点。
3.3 区域二：命理指引入口 (Destiny Guide Section)
视觉：深色背景（星空或深紫渐变）。
布局：
左侧/居中：一段神秘的引导语（“生辰八字，蕴藏天机...”）。
右侧/居中：一个**“发光的罗盘”或“流动的星盘”**视觉元素（可以用 CSS 动画或简单的 SVG 旋转实现）。
交互：
当用户滚动到此区域时，元素执行 WhileInView 动画（从下方浮出）。
CTA 按钮：“Start Your Reading” (开启测算)。
点击按钮，平滑滚动到算命表单区域（如果表单在首页）或跳转到专门的测算页。
3.4 区域三：商城创新展示 (Store Showcase)
标题： "Curated Energy Objects" (甄选法物)。
展示方式（创新点）：
方案：视差滚动画廊 (Parallax Scroll Gallery)。
不使用普通的网格。使用 横向滚动带 或 错落式布局 (Masonry)。
动态效果：
商品卡片在滚动时，图片和文字有不同的滚动速度（视差感）。
鼠标悬停 (Hover) 时，卡片轻微上浮，并显示“Quick Add”按钮。
内容：只展示 3-4 个“镇店之宝”或“热门推荐”，底部放一个“View All Collection” 按钮导向 /shop。
4. 开发步骤指令 (Step-by-Step)
请 AI 辅助按以下步骤执行：
Step 1: 准备工作
安装依赖：npm install framer-motion embla-carousel-react embla-carousel-autoplay。
准备 3-4 张高质量 Banner 图片（可使用占位图）。
Step 2: 改造 Navbar
修改 components/Navbar.tsx。
实现 useScroll 钩子来监听页面滚动，控制背景色的切换。
调整布局为 Left-Logo, Center-Links 结构。
Step 3: 实现 Hero Carousel
创建 components/home/HeroCarousel.tsx。
使用 Embla Carousel 实现全屏轮播，添加自动播放插件。
在图片上层添加 Slogan 和 Framer Motion 的入场动画。
Step 4: 实现命理指引入口
创建 components/home/DestinySection.tsx。
使用 Flex 或 Grid 布局。
添加“呼吸灯”效果的 CTA 按钮（利用 animate={{ scale: [1, 1.05, 1] }}）。
Step 5: 实现商城展示区
创建 components/home/StoreShowcase.tsx。
从数据库 products 表获取 4 个推荐商品。
使用 Framer Motion 实现 Stagger Children (交错显示) 动画效果，让商品卡片一个接一个优雅地浮现。
Step 6: 组装首页
修改 app/page.tsx。
按顺序引入上述组件：Navbar -> Hero -> DestinySection -> StoreShowcase -> Footer。