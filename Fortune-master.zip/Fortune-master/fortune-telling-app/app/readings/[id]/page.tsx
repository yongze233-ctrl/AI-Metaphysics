import { createClient } from "@/utils/supabase/server";
import { redirect, notFound } from "next/navigation";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { ArrowLeft, Sparkles, CheckCircle } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { PaymentButton } from "./payment-button";

export default async function ReadingDetailPage({
  params,
  searchParams
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ success?: string }>;
}) {
  const { id } = await params;
  const { success } = await searchParams;

  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  // 获取指定的测算记录
  const { data: reading, error } = await supabase
    .from("readings")
    .select("*")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();

  if (error || !reading) {
    notFound();
  }

  const baziData = reading.bazi_json as any;
  const birthDate = new Date(reading.birth_date).toLocaleDateString("zh-CN");
  const isPaid = reading.is_paid === true;
  const paymentSuccess = success === "true";

  return (
    <main className="min-h-screen bg-rice-paper-texture pt-24 pb-12 px-4 md:px-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Back Button */}
        <Button
          variant="ghost"
          asChild
          className="font-chinese text-ink-soot hover:text-cinnabar hover:bg-cinnabar/5 ink-dot-hover"
        >
          <Link href="/dashboard">
            <ArrowLeft className="mr-2 h-4 w-4" />
            返回我的命书
          </Link>
        </Button>

        {/* Payment Success Banner */}
        {paymentSuccess && isPaid && (
          <div className="bg-green-50 border-2 border-green-600 rounded-sm p-4 flex items-center gap-3">
            <CheckCircle className="h-6 w-6 text-green-600" />
            <div>
              <p className="font-chinese text-green-800 font-semibold">支付成功！</p>
              <p className="font-chinese text-green-700 text-sm">您已解锁完整的深度解析报告</p>
            </div>
          </div>
        )}

        {/* Bazi Display - Geng Tie (庚帖) Style */}
        <div className="relative">
          {/* Red Paper Background */}
          <div className="relative bg-gradient-to-br from-cinnabar via-cinnabar-dark to-cinnabar p-8 md:p-12 rounded-sm border-4 border-cinnabar-dark scroll-shadow overflow-hidden">
            {/* Corner decorations */}
            <div className="absolute top-2 left-2 w-12 h-12 border-t-4 border-l-4 border-gold opacity-60" />
            <div className="absolute top-2 right-2 w-12 h-12 border-t-4 border-r-4 border-gold opacity-60" />
            <div className="absolute bottom-2 left-2 w-12 h-12 border-b-4 border-l-4 border-gold opacity-60" />
            <div className="absolute bottom-2 right-2 w-12 h-12 border-b-4 border-r-4 border-gold opacity-60" />

            {/* Title Seal */}
            <div className="text-center mb-8">
              <div className="inline-block bg-rice-paper border-2 border-gold px-6 py-3 rounded-sm">
                <h2 className="font-brush text-3xl text-cinnabar">命书</h2>
              </div>
              <p className="font-chinese text-rice-paper/80 mt-3 tracking-widest">
                {reading.name} · {reading.gender} · {birthDate}
              </p>
            </div>

            {/* Four Pillars - Vertical Display */}
            <div className="flex justify-center gap-4 md:gap-8 mb-8">
              {[
                { label: "年柱", value: baziData?.yearPillar || "N/A" },
                { label: "月柱", value: baziData?.monthPillar || "N/A" },
                { label: "日柱", value: baziData?.dayPillar || "N/A" },
                { label: "时柱", value: baziData?.timePillar || "N/A" },
              ].map((pillar, index) => (
                <div key={pillar.label} className="relative">
                  {/* Vertical Pillar */}
                  <div className="bg-rice-paper border-2 border-gold rounded-sm p-4 md:p-6 flex flex-col items-center min-w-[80px] md:min-w-[100px]">
                    {/* Label */}
                    <div className="font-chinese text-xs md:text-sm text-ink-light mb-3 border-b border-ink-light/20 pb-2 w-full text-center">
                      {pillar.label}
                    </div>

                    {/* Characters - Vertical */}
                    <div className="space-y-2">
                      {pillar.value.split("").map((char: string, i: number) => (
                        <div
                          key={i}
                          className="font-brush text-4xl md:text-5xl text-ink-soot text-center"
                        >
                          {char}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Decorative stamp on first and last pillar */}
                  {(index === 0 || index === 3) && (
                    <div className="absolute -top-3 -right-3 w-8 h-8 seal-stamp text-xs flex items-center justify-center">
                      {index === 0 ? "天" : "地"}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Five Elements */}
            {baziData?.wuxing && (
              <div className="bg-rice-paper/90 rounded-sm p-6 border-2 border-gold">
                <div className="font-chinese text-sm text-ink-soot mb-4 text-center border-b border-ink-light/20 pb-2">
                  五行分布
                </div>
                <div className="grid grid-cols-5 gap-4">
                  {Object.entries(baziData.wuxing).map(([element, count]: [string, any]) => (
                    <div key={element} className="text-center">
                      <div className="font-chinese text-base text-ink-soot">{element}</div>
                      <div className="font-brush text-3xl text-cinnabar font-bold">{count}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* AI Interpretation - Ancient Book Style */}
        <div className="relative">
          <div className="relative bg-rice-paper-texture border-lattice text-gold scroll-shadow rounded-sm overflow-hidden">
            {/* Corner decorations */}
            <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-cinnabar opacity-20" />
            <div className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-cinnabar opacity-20" />
            <div className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-cinnabar opacity-20" />
            <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-cinnabar opacity-20" />

            {/* Header */}
            <div className="relative text-center pt-10 pb-6 px-8 border-b-2 border-gold/20">
              <div className="inline-block seal-stamp w-12 h-12 text-lg mb-3">批</div>
              <h2 className="font-brush text-3xl md:text-4xl text-cinnabar mb-2">
                {isPaid ? "命理详批" : "命理初解"}
              </h2>
              <p className="font-chinese text-ink-light text-sm">
                {isPaid ? "完整深度解析报告" : "基于传统命理学与AI智能分析"}
              </p>
              {isPaid && (
                <div className="inline-flex items-center gap-2 bg-gold/10 px-3 py-1 rounded-sm border border-gold/30 mt-3">
                  <Sparkles className="h-4 w-4 text-gold" />
                  <span className="font-chinese text-gold text-sm font-medium">完整版</span>
                </div>
              )}
            </div>

            {/* Content */}
            <div className="relative p-8 md:p-12">
              {isPaid ? (
                /* Paid: Full Content */
                <div className="prose prose-lg max-w-none">
                  <div className="font-chinese text-ink-soot leading-loose space-y-6 text-base md:text-lg">
                    <ReactMarkdown
                      components={{
                        h1: ({ children }) => (
                          <h1 className="font-brush text-3xl text-cinnabar mb-4 mt-8 text-center border-b-2 border-gold/20 pb-3">
                            『{children}』
                          </h1>
                        ),
                        h2: ({ children }) => (
                          <h2 className="font-brush text-2xl text-cinnabar mb-3 mt-6 border-l-4 border-cinnabar pl-4">
                            【{children}】
                          </h2>
                        ),
                        h3: ({ children }) => (
                          <h3 className="font-chinese text-xl text-ink-soot mb-2 mt-4 font-semibold">
                            · {children}
                          </h3>
                        ),
                        p: ({ children }) => (
                          <p className="font-chinese text-ink-soot leading-loose mb-4 indent-8">
                            {children}
                          </p>
                        ),
                        strong: ({ children }) => (
                          <strong className="text-cinnabar font-semibold">{children}</strong>
                        ),
                        ul: ({ children }) => (
                          <ul className="space-y-2 my-4 ml-8">{children}</ul>
                        ),
                        li: ({ children }) => (
                          <li className="font-chinese text-ink-soot flex items-start gap-3">
                            <span className="text-cinnabar mt-1">•</span>
                            <span>{children}</span>
                          </li>
                        ),
                      }}
                    >
                      {reading.ai_result_full || reading.ai_result}
                    </ReactMarkdown>
                  </div>
                </div>
              ) : (
                /* Unpaid: Preview + Cloud-Mist Paywall */
                <div className="relative">
                  {/* Free Preview Content */}
                  <div className="prose prose-lg max-w-none">
                    <div className="font-chinese text-ink-soot leading-loose space-y-6 text-base md:text-lg">
                      <ReactMarkdown
                        components={{
                          h1: ({ children }) => (
                            <h1 className="font-brush text-3xl text-cinnabar mb-4 mt-8 text-center border-b-2 border-gold/20 pb-3">
                              『{children}』
                            </h1>
                          ),
                          h2: ({ children }) => (
                            <h2 className="font-brush text-2xl text-cinnabar mb-3 mt-6 border-l-4 border-cinnabar pl-4">
                              【{children}】
                            </h2>
                          ),
                          h3: ({ children }) => (
                            <h3 className="font-chinese text-xl text-ink-soot mb-2 mt-4 font-semibold">
                              · {children}
                            </h3>
                          ),
                          p: ({ children }) => (
                            <p className="font-chinese text-ink-soot leading-loose mb-4 indent-8">
                              {children}
                            </p>
                          ),
                          strong: ({ children }) => (
                            <strong className="text-cinnabar font-semibold">{children}</strong>
                          ),
                          ul: ({ children }) => (
                            <ul className="space-y-2 my-4 ml-8">{children}</ul>
                          ),
                          li: ({ children }) => (
                            <li className="font-chinese text-ink-soot flex items-start gap-3">
                              <span className="text-cinnabar mt-1">•</span>
                              <span>{children}</span>
                            </li>
                          ),
                        }}
                      >
                        {reading.ai_result}
                      </ReactMarkdown>
                    </div>
                  </div>

                  {/* Cloud-Mist Gradient Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 h-80 bg-gradient-to-t from-rice-paper via-rice-paper/90 to-transparent pointer-events-none" />

                  {/* Unlock Section */}
                  <div className="relative mt-8 bg-gradient-to-br from-rice-paper to-stone-100 border-2 border-gold/40 rounded-sm p-8 text-center scroll-shadow">
                    {/* Seal Icon */}
                    <div className="flex justify-center mb-6">
                      <div className="seal-stamp w-16 h-16 text-2xl">
                        锁
                      </div>
                    </div>

                    <h3 className="font-brush text-3xl text-cinnabar mb-3">
                      解锁天机
                    </h3>
                    <p className="font-chinese text-ink-soot mb-6 max-w-md mx-auto leading-relaxed">
                      付费后可获得 3000 字深度报告，包含：未来10年大运、今年流年运势、事业/感情/财运的具体建议
                    </p>

                    {/* Benefits List */}
                    <ul className="text-left font-chinese text-ink-soot text-sm mb-8 max-w-sm mx-auto space-y-3">
                      <li className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 text-cinnabar flex-shrink-0" />
                        <span>性格深度剖析</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 text-cinnabar flex-shrink-0" />
                        <span>未来10年大运走势</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 text-cinnabar flex-shrink-0" />
                        <span>今年流年运势详批</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 text-cinnabar flex-shrink-0" />
                        <span>事业/感情/财运具体建议</span>
                      </li>
                    </ul>

                    <PaymentButton readingId={id} />
                  </div>
                </div>
              )}
            </div>

            {/* Bottom decoration */}
            <div className="px-8 pb-6">
              <div className="wave-divider w-full text-gold opacity-30" />
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
