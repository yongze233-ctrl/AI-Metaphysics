当前问题：
紫色残留：虽然组件改了，但 body 或页面容器背景依然是旧版的深紫色，导致“宣纸”像贴在霓虹灯上，极不协调。
风格割裂：/dashboard（测算历史）依然是现代 SaaS 风格（卡片、阴影），与新中式首页格格不入。
1. 全局背景修正 (Global Background Fix)
目标：彻底铲除“深紫色/科技风”背景，确立“宣纸/水墨”为全站基调。
1.1 根布局修正 (app/layout.tsx & globals.css)
CSS 变量重写：
检查 :root 下的 background 和 foreground 变量。
强制修改为：
Background: #F7F5F0 (Rice Paper / 米白)。
Foreground: #2B2B2B (Ink / 墨黑)。
Body 样式：
确保 body 标签应用了 bg-rice-paper text-ink 类。
添加一个全局的颗粒纹理层 (Grain Overlay)：使用 ::before 伪元素在 body 上覆盖一层低透明度的噪点图片，模拟纸张质感。
1.2 输入页背景修正 (/calculate)
现状：中间是纸，但四周是紫色。
修改：
页面容器 (min-h-screen) 的背景色必须移除 bg-slate-900 或类似深色类。
改为 水墨晕染背景：使用 CSS 径向渐变，中心亮（米白），四周微暗（淡灰），模拟光照在纸上的感觉。
容器阴影：输入表单的容器（那个“竖排信笺”）需要加上柔和的投影 (shadow-2xl shadow-stone-400/50)，让它看起来是浮在背景之上的。
2. 测算历史页重构 (/dashboard)
目标：将“列表页”改造成**“命书存档” (Destiny Archives)** 风格。
2.1 整体布局
标题区：
文案：由 "Dashboard" 改为 “我的命书” 或 “往期推演”。
样式：竖排大号宋体，右侧加一个小小的红色印章。
背景：
保持全局米色宣纸纹理。
2.2 列表项设计 (List Items)
旧版：现代 Card，白色背景，浮起阴影。
新版概念：“账簿” 或 “竹简” 风格。
样式方案：
去除卡片背景：列表项不再有明显的白色背景块。
分割线：每一项之间用一条虚线 (border-dashed border-stone-300) 或 水墨笔触线条 分隔。
单行内容：
左侧：日期。使用汉字日期格式（如“二零二三 · 十二 · 初五”），竖排或小字宋体。
中间：测算名称。大号宋体，加粗。例如“甲辰年运势分析”。
右侧：状态印章。
已支付/已完成 -> 红色实心圆章“已批”。
未支付 -> 灰色方框章“待解”。
操作：整个行可点击，Hover 时背景出现淡淡的水墨晕染 (bg-stone-200/30)。
2.3 详情弹窗/跳转
点击列表项后，跳转到 /result/[id]（这个页面我们在之前已经重构过）。
3. 组件级微调 (Micro Adjustments)
3.1 字体颜色强制修正
检查所有 Input, Textarea, p, span。
确保在米色背景上，文字颜色是 #2B2B2B (墨黑) 或 #444 (深灰)。
严禁出现白字（White text），除非是在红色按钮或深色图片遮罩上。
3.2 滚动条美化
修改 Webkit 滚动条样式。
滚动条轨道：透明。
滑块 (Thumb)：深灰色/墨色，细条，圆角。
4. 开发步骤指令 (Step-by-Step)
请 AI 辅助按以下步骤执行：
Step 1: 全局去色 (De-Purpling)
修改 app/globals.css 和 tailwind.config.ts。
将默认背景色设为 #F7F5F0，默认文字设为 #2B2B2B。
扫描 /calculate 页面，手动移除所有硬编码的深色背景类 (如 bg-gray-900, bg-slate-950)。
Step 2: 历史页重写 (/dashboard)
找到 app/[locale]/dashboard/page.tsx。
重写列表渲染逻辑：
移除 <Card> 组件包裹。
使用 <div className="border-b border-stone-300 py-6 ..."> 结构。
引入 Noto Serif SC 字体。
根据 is_paid 状态渲染不同的“印章”组件。
Step 3: 视觉验收
检查输入框在米色背景下是否清晰（边框颜色需加深）。
检查按钮文字对比度。