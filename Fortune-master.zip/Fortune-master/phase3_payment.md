# Phase 3 PRD: Monetization & Payments (Stripe)

## 1. 阶段目标 (Objective)
接入 Stripe 支付网关，构建付费墙（Paywall）。
- **免费体验**：用户只能看到 AI 生成的 200 字运势摘要。
- **付费解锁**：支付 $9.90 后，解锁 2000 字深度解析（包含事业、爱情、财运详细建议）。

## 2. 准备工作 (Prerequisites)
**在开始写代码前，请确保已完成以下 Stripe 后台配置：**
1.  注册 Stripe 账号并激活 **Test Mode** (测试模式)。
2.  在 Stripe Dashboard -> **Products** 创建一个产品：
    -   Name: "深度运势解析 (Detailed Reading)"
    -   Price: $9.90 (One-time)
    -   **重要**: 获取该价格的 API ID (例如 `price_1Pxyz...`)。
3.  获取 API Keys (Developers -> API keys):
    -   Publishable Key (`pk_test_...`)
    -   Secret Key (`sk_test_...`)

## 3. 数据库更新 (Database Update)
虽然不需要建新表，但需要更新 `readings` 表以支持支付状态。

请 AI 帮我编写 SQL：
```sql
-- 添加支付相关字段
ALTER TABLE public.readings 
ADD COLUMN IF NOT EXISTS is_paid BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS stripe_session_id TEXT,
ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'unpaid'; -- 'unpaid', 'paid'
```

## 4. 核心业务流程 (Workflows)

### 4.1 两种 AI 模式 (Prompt Strategy)
我们需要拆分 AI 生成逻辑，以节省成本并区分服务：
-   **Mode A (Free)**: 
    -   Prompt: "你是命理大师。请根据八字给出一段 **200字以内** 的性格简评。语气神秘。"
    -   触发时机：用户点击“开始测算”。
-   **Mode B (Paid)**:
    -   Prompt: "你是命理大师。请根据八字给出 **3000字** 的深度解析。包含：1.性格详批 2.未来10年大运 3.今年流年运势 4.事业/感情/财运的具体建议。使用 Markdown 格式。"
    -   触发时机：**支付成功后**。

### 4.2 支付流程 (The Checkout Flow)
1.  **结果页 (`/result/[id]`)**: 
    -   检测到 `is_paid === false`。
    -   展示 Mode A 的短文本。
    -   文本下方显示模糊遮罩 (Blur Effect)。
    -   显示 CTA 按钮：“解锁完整报告 ($9.9)”。
2.  **创建订单 (API `/api/checkout`)**:
    -   用户点击按钮 -> 前端调用 API。
    -   后端调用 Stripe 创建 `Checkout Session`。
    -   **关键参数**: 
        -   `success_url`: `${origin}/result/[id]?success=true`
        -   `cancel_url`: `${origin}/result/[id]`
        -   `metadata`: `{ reading_id: "当前记录的UUID", user_id: "用户ID" }` (这很重要，用于回调识别)。
3.  **跳转支付**: 用户在 Stripe 托管页面完成付款。
4.  **回调处理 (Webhook `/api/webhooks/stripe`)**:
    -   Stripe 后台异步通知我们的服务器。
    -   验证签名 (Verify Signature)。
    -   读取 `metadata.reading_id`。
    -   更新数据库: `UPDATE readings SET is_paid = true WHERE id = ...`。
5.  **支付后生成 (Post-Payment Generation)**:
    -   前端轮询或用户刷新页面，发现 `is_paid === true`。
    -   (可选优化) 此时自动触发 Mode B (深度解析) 的生成，并更新到数据库覆盖旧结果或存入新字段。

## 5. 开发步骤指令 (Step-by-Step Instructions)

请 AI 辅助按以下步骤执行：

**Step 1: 环境配置**
-   安装依赖: `npm install stripe`
-   在 `.env.local` 添加:
    -   `STRIPE_SECRET_KEY=sk_test_...`
    -   `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...`
    -   `STRIPE_WEBHOOK_SECRET=...` (稍后通过 CLI 获取)
    -   `STRIPE_PRICE_ID=price_...`

**Step 2: 数据库迁移**
-   运行上面的 SQL 语句，更新 `readings` 表结构。

**Step 3: 创建支付 API**
-   创建 `app/api/checkout/route.ts`: 处理创建 Stripe Session 的逻辑。确保将 `reading_id` 放入 metadata。

**Step 4: 实现 Webhook (难点)**
-   创建 `app/api/webhooks/stripe/route.ts`。
-   **注意**: Next.js App Router 中，Webhook 需要处理 `raw body`。请 AI 务必注意 "Stripe verify signature with raw body in Next.js 15" 的写法。
-   逻辑: 收到 `checkout.session.completed` -> 更新数据库。

**Step 5: 前端 UI 改造**
-   修改结果页：区分免费/付费视图。
-   实现“解锁”按钮的点击事件（调用 `/api/checkout` 并跳转 `session.url`）。

**Step 6: 本地测试 Webhook**
-   (指导我) 如何使用 Stripe CLI 进行本地转发，获取 `whsec_...` 密钥。
```
